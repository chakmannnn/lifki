/* Lifki hosted widget.
 * This is a dependency-free access gate and a snapshot of the exact existing
 * calculator markup/CSS from index.html. It does not modify the host page.
 * Public configuration: window.MyChatWidgetConfig = { appId: "subscriptions.id" }
 * Replace only the public placeholders below. Never add private credentials.
 */
(function () {
  "use strict";
  var SUPABASE_URL = "https://YOUR_PROJECT_REF.supabase.co";
  var SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
  var config = window.MyChatWidgetConfig || {};
  var appId = typeof config.appId === "string" ? config.appId.trim() : "";
  if (!appId) return;
  var cacheKey = "widget_active_" + appId;
  var hostDocument = document;

  function cached() { try { return sessionStorage.getItem(cacheKey) === "true"; } catch (_error) { return false; } }
  function cacheActive() { try { sessionStorage.setItem(cacheKey, "true"); } catch (_error) {} }

  function mount() {
    var host = hostDocument.createElement("div");
    host.setAttribute("data-lifki-widget", appId);
    host.style.position = "fixed"; host.style.right = "0"; host.style.bottom = "0";
    host.style.zIndex = "999999"; host.style.width = "0"; host.style.height = "0";
    host.style.pointerEvents = "none";
    (hostDocument.body || hostDocument.documentElement).appendChild(host);
    var shadow = host.attachShadow({ mode: "closed" });
    var styleText = "\n    :host {\n      --ink: #10251f;\n      --ink-2: #29433b;\n      --muted: #6b7d76;\n      --paper: #fbfaf7;\n      --surface: #fff;\n      --line: #e3eae5;\n      --green: #0b654b;\n      --green-dark: #084b39;\n      --mint: #e7f3ee;\n      --lime: #b7ee74;\n      --amber: #efbd4f;\n      --danger: #b84d40;\n      --shadow: 0 24px 72px rgba(16, 37, 31, .2), 0 4px 14px rgba(16, 37, 31, .08);\n      --radius-xl: 27px;\n      --radius-lg: 20px;\n      --radius-md: 14px;\n      --radius-sm: 10px;\n      --ease: cubic-bezier(.22, .8, .22, 1);\n    }\n    * { box-sizing: border-box; }\n    html { scroll-behavior: smooth; }\n    body {\n      margin: 0; min-width: 320px; color: var(--ink);\n      background: radial-gradient(circle at 87% 7%, rgba(183,238,116,.23), transparent 28rem), linear-gradient(145deg, #f7faf8, #fbfaf7 55%, #eff8f2);\n      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif;\n      -webkit-font-smoothing: antialiased;\n    }\n    button, input, select, textarea { font: inherit; }\n    button { cursor: pointer; }\n    .hidden { display: none !important; }\n    .site-shell { min-height: 100vh; overflow: hidden; position: relative; }\n    .topbar, .hero, .owner-strip, .site-footer { width: min(1180px, calc(100% - 48px)); margin: 0 auto; }\n    .topbar { padding: 25px 0; display: flex; align-items: center; justify-content: space-between; gap: 24px; position: relative; z-index: 2; }\n    .brand { display: flex; align-items: center; gap: 10px; font-weight: 800; letter-spacing: -.035em; }\n    .brand-mark { width: 34px; height: 34px; border-radius: 10px 10px 10px 3px; display: grid; place-items: center; color: var(--ink); background: var(--lime); box-shadow: 0 4px 12px rgba(183,238,116,.35); }\n    .brand-mark svg { width: 21px; height: 21px; }\n    .brand-name { font-size: 15px; }\n    .brand-name span { color: var(--green); }\n    .nav { display: flex; align-items: center; gap: 26px; color: var(--muted); font-size: 13px; font-weight: 700; }\n    .nav a { color: inherit; text-decoration: none; }\n    .nav a:hover { color: var(--green); }\n    .topbar-cta { border: 0; background: var(--ink); color: #fff; border-radius: 999px; padding: 11px 17px; font-size: 12px; font-weight: 800; }\n    .owner-topbar-cta { border: 1px solid var(--green); background: transparent; color: var(--green); }\n    .owner-topbar-cta:hover { background: var(--mint); }\n\n    .hero { min-height: calc(100vh - 84px); padding: 38px 0 92px; display: grid; grid-template-columns: minmax(0, 1.05fr) minmax(370px, .95fr); align-items: center; gap: 70px; }\n    .hero-copy { max-width: 650px; position: relative; z-index: 1; }\n    .eyebrow { display: inline-flex; align-items: center; gap: 8px; color: var(--green); font-weight: 850; text-transform: uppercase; letter-spacing: .13em; font-size: 10px; }\n    .eyebrow:before { content: \"\"; width: 21px; height: 2px; background: var(--lime); border-radius: 99px; }\n    h1 { margin: 19px 0; max-width: 680px; font-size: clamp(42px, 6vw, 76px); line-height: .98; letter-spacing: -.075em; text-wrap: balance; }\n    h1 em { color: var(--green); font-style: normal; }\n    .hero-copy > p { margin: 0; max-width: 560px; color: var(--muted); font-size: 18px; line-height: 1.6; }\n    .hero-actions { display: flex; align-items: center; flex-wrap: wrap; gap: 16px; margin-top: 32px; }\n    .primary-btn, .secondary-btn { border: 0; border-radius: 999px; padding: 15px 21px; font-size: 13px; font-weight: 850; transition: transform .2s var(--ease), box-shadow .2s var(--ease), background .2s ease; }\n    .primary-btn { color: #fff; background: var(--green); box-shadow: 0 10px 25px rgba(12,101,75,.2); }\n    .primary-btn:hover { transform: translateY(-2px); background: var(--green-dark); box-shadow: 0 14px 30px rgba(12,101,75,.27); }\n    .secondary-btn { padding-left: 4px; padding-right: 4px; color: var(--ink); background: transparent; }\n    .secondary-btn:hover { color: var(--green); }\n    .trust-row { display: flex; align-items: center; flex-wrap: wrap; gap: 17px; margin-top: 42px; color: var(--muted); font-size: 12px; font-weight: 700; }\n    .trust-dot { color: var(--green); font-size: 16px; }\n    .trust-divider { width: 1px; height: 16px; background: var(--line); }\n\n    .visual { min-height: 500px; position: relative; display: grid; place-items: center; }\n    .visual:before { content: \"\"; position: absolute; width: 470px; height: 470px; border-radius: 50%; background: rgba(222,243,231,.75); }\n    .visual-card { width: min(100%, 430px); position: relative; transform: rotate(3deg); border: 1px solid rgba(255,255,255,.9); border-radius: 24px; background: rgba(255,255,255,.94); box-shadow: 0 25px 65px rgba(35,81,61,.12); }\n    .dashboard-card { padding: 20px 18px 34px; }\n    .dash-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }\n    .dash-label { display: block; margin-bottom: 6px; color: var(--green); font-size: 8px; font-weight: 900; letter-spacing: .13em; }\n    .dash-top strong { display: block; font-size: 18px; letter-spacing: -.05em; }\n    .live-dot { color: var(--green); background: var(--mint); border-radius: 999px; padding: 7px 9px; font-size: 10px; font-weight: 850; }\n    .dash-tabs { display: flex; gap: 17px; padding: 20px 0 10px; border-bottom: 1px solid var(--line); color: var(--muted); font-size: 10px; font-weight: 750; }\n    .dash-tabs .active { padding-bottom: 10px; margin-bottom: -12px; border-bottom: 2px solid var(--lime); color: var(--green); }\n    .dash-metric { margin-top: 15px; padding: 15px; border-radius: 13px; color: #fff; background: var(--ink); }\n    .dash-metric span, .dash-metric small, .dash-small span, .dash-small small, .dash-breakdown span, .dash-breakdown-foot small { display: block; color: #91afa2; font-size: 9px; }\n    .dash-metric strong { display: block; margin: 5px 0; font-size: 22px; letter-spacing: -.06em; }\n    .dash-metric small { color: #c5d7ce; }\n    .dash-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }\n    .dash-small { padding: 12px; border: 1px solid var(--line); border-radius: 12px; background: #fbfdfb; }\n    .dash-small strong { display: block; margin: 4px 0 2px; color: var(--ink); font-size: 17px; letter-spacing: -.05em; }\n    .dash-small small { color: var(--muted); }\n    .dash-breakdown { margin-top: 10px; padding: 12px; border: 1px solid var(--line); border-radius: 12px; }\n    .dash-breakdown strong { display: block; margin-top: 3px; font-size: 10px; }\n    .dash-line { height: 7px; margin: 13px 0 9px; overflow: hidden; border-radius: 99px; background: #e9f0eb; }\n    .dash-line i { display: block; height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--green), var(--lime)); }\n    .dash-breakdown-foot { display: flex; justify-content: space-between; gap: 5px; }\n    .dash-breakdown-foot small { color: var(--muted); font-size: 8px; }\n    .visual-badge { position: absolute; left: -31px; bottom: 40px; padding: 15px 18px; border-radius: 14px; color: #fff; background: var(--ink); box-shadow: 0 16px 30px rgba(16,37,31,.22); }\n    .visual-badge strong { display: block; font-size: 18px; letter-spacing: -.04em; }\n    .visual-badge span { display: block; margin-top: 3px; color: #a9c4b8; font-size: 10px; }\n\n    .owner-strip { padding: 0 0 90px; }\n    .owner-strip-head { max-width: 555px; }\n    .owner-strip h2 { margin: 17px 0 12px; font-size: clamp(30px,4vw,46px); line-height: 1; letter-spacing: -.06em; }\n    .owner-strip p { max-width: 560px; margin: 0; color: var(--muted); font-size: 15px; line-height: 1.6; }\n    .owner-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 28px; }\n    .owner-card { padding: 17px; border: 1px solid var(--line); border-radius: 15px; background: rgba(255,255,255,.68); }\n    .owner-card strong { display: block; margin-bottom: 6px; font-size: 13px; }\n    .owner-card span { color: var(--muted); font-size: 11px; line-height: 1.45; }\n    .owner-icon { width: 29px; height: 29px; display: grid; place-items: center; margin-bottom: 15px; border-radius: 9px; color: var(--green); background: var(--mint); }\n    .owner-icon svg { width: 16px; height: 16px; }\n    .site-footer { display: flex; justify-content: space-between; padding: 22px 0 35px; border-top: 1px solid var(--line); color: var(--muted); font-size: 11px; }\n    .pricing-section { width: min(1180px, calc(100% - 48px)); margin: 0 auto; padding: 0 0 90px; }\n    .pricing-section-head { max-width: 620px; }\n    .pricing-section h2 { margin: 16px 0 12px; font-size: clamp(30px, 4vw, 46px); line-height: 1; letter-spacing: -.06em; }\n    .pricing-section p { max-width: 560px; margin: 0; color: var(--muted); font-size: 15px; line-height: 1.6; }\n    .pricing-card { max-width: 440px; margin-top: 28px; padding: 26px; border: 1px solid #dcebe1; border-radius: 22px; background: #fff; box-shadow: 0 14px 35px rgba(16,37,31,.08); }\n    .pricing-card-label { color: var(--green); font-size: 10px; font-weight: 850; letter-spacing: .1em; text-transform: uppercase; }\n    .pricing-price { display: flex; align-items: baseline; gap: 5px; margin: 12px 0 4px; }\n    .pricing-price strong { color: var(--ink); font-size: 48px; line-height: 1; letter-spacing: -.07em; }\n    .pricing-price span { color: var(--muted); font-size: 13px; font-weight: 750; }\n    .pricing-card small { display: block; color: var(--muted); font-size: 11px; }\n    .pricing-list { display: grid; gap: 8px; margin: 20px 0; padding: 0; list-style: none; color: var(--ink-2); font-size: 12px; }\n    .pricing-list li:before { content: \"\u2713\"; margin-right: 7px; color: var(--green); font-weight: 900; }\n    .signup-cta { border: 0; background: var(--green); color: #fff; border-radius: 999px; padding: 11px 17px; font-size: 12px; font-weight: 800; }\n    .signin-cta { border: 1px solid var(--green); color: var(--green); background: transparent; border-radius: 999px; padding: 10px 15px; font-size: 12px; font-weight: 800; }\n    .signin-cta:hover { color: #fff; background: var(--green); }\n    .auth-modal { position: fixed; inset: 0; z-index: 45; display: grid; place-items: center; padding: 20px; background: rgba(16,37,31,.42); }\n    .auth-modal:not(.hidden) { animation: auth-fade-in .22s ease both; }\n    .auth-card { width: min(430px, 100%); padding: 26px; border-radius: 22px; background: #fff; box-shadow: var(--shadow); animation: auth-card-enter .28s var(--ease) both; transition: opacity .18s ease, transform .18s ease; }\n    .auth-card.auth-transitioning { opacity: 0; transform: translateY(8px) scale(.98); }\n    @keyframes auth-fade-in { from { opacity: 0; } to { opacity: 1; } }\n    @keyframes auth-card-enter { from { opacity: 0; transform: translateY(12px) scale(.98); } to { opacity: 1; transform: translateY(0) scale(1); } }\n    .auth-card .head-row { align-items: center; }\n    .auth-card h2 { margin: 18px 0 7px; font-size: 27px; letter-spacing: -.06em; }\n    .auth-card > p { margin: 0 0 20px; color: var(--muted); font-size: 12px; line-height: 1.5; }\n    .auth-form { display: grid; gap: 12px; }\n    .auth-form label { display: grid; gap: 5px; color: var(--ink-2); font-size: 10px; font-weight: 800; }\n    .auth-form input { width: 100%; padding: 11px 12px; border: 1px solid var(--line); border-radius: 10px; color: var(--ink); background: #fff; font-size: 12px; }\n    .auth-form input:focus { outline: 2px solid rgba(11,101,75,.18); border-color: var(--green); }\n    .auth-actions { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 5px; }\n    .auth-mode-toggle { display: block; width: 100%; margin-top: 16px; padding: 0; border: 0; color: var(--green); background: transparent; text-align: center; font-size: 11px; font-weight: 800; }\n    .auth-mode-toggle:hover { text-decoration: underline; }\n    .auth-cancel { border: 0; color: var(--muted); background: transparent; font-size: 11px; font-weight: 750; }\n    .followup-options { display: grid; gap: 8px; margin: 18px 0 12px; }\n    .followup-options button { padding: 11px 12px; border: 1px solid var(--line); border-radius: 10px; color: var(--ink-2); background: #fff; text-align: left; font-size: 11px; font-weight: 800; }\n    .followup-options button:hover { border-color: var(--green); color: var(--green); background: var(--mint); }\n    .auth-error { display: none; margin: 0; color: var(--danger); font-size: 10px; }\n    .auth-error.show { display: block; }\n    .app-shell { position: fixed; inset: 0; z-index: 40; display: grid; grid-template-columns: 238px minmax(0, 1fr); overflow: hidden; overflow-anchor: none; color: var(--ink); background: #f4f8f5; }\n    .app-shell:not(.hidden) { animation: app-shell-enter .34s var(--ease) both; }\n    @keyframes app-shell-enter { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }\n    .app-sidebar { display: flex; flex-direction: column; gap: 24px; padding: 24px 16px; border-right: 1px solid var(--line); background: var(--ink); }\n    .app-brand { display: flex; align-items: center; gap: 9px; color: #fff; font-size: 17px; font-weight: 850; letter-spacing: -.04em; }\n    .app-brand-mark { width: 29px; height: 29px; display: grid; place-items: center; border-radius: 9px 9px 9px 3px; color: var(--ink); background: var(--lime); font-size: 13px; font-weight: 950; }\n    .app-sidebar-label { margin: 5px 10px 0; color: #8fa99d; font-size: 9px; font-weight: 850; letter-spacing: .1em; text-transform: uppercase; }\n    .app-nav { display: grid; gap: 5px; scrollbar-width: none; -ms-overflow-style: none; }\n    .app-nav::-webkit-scrollbar { display: none; width: 0; height: 0; }\n    .app-nav button { width: 100%; padding: 11px 12px; border: 0; border-radius: 9px; color: #a9c1b6; background: transparent; text-align: left; font-size: 11px; font-weight: 750; }\n    .app-nav button:hover, .app-nav button.active { color: #fff; background: rgba(255,255,255,.1); }\n    .app-sidebar-foot { margin-top: auto; color: #8fa99d; font-size: 10px; line-height: 1.45; }\n    .app-main { --owner-space-1: 20px; --owner-space-2: 40px; min-width: 0; overflow-y: auto; overflow-anchor: none; padding: 30px clamp(20px, 4vw, 54px) 60px; }\n    .app-topline { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 30px; }\n    .app-topline small { color: var(--muted); font-size: 10px; }\n    .app-signout { padding: 8px 10px; border: 1px solid var(--line); border-radius: 999px; color: var(--ink-2); background: #fff; font-size: 10px; font-weight: 800; }\n    .app-page-head { margin-bottom: 24px; }\n    .app-page-head .eyebrow { font-size: 9px; }\n    .app-page-head h1 { max-width: 760px; margin: 12px 0 8px; font-size: clamp(30px, 4vw, 50px); }\n    .app-page-head p { max-width: 650px; margin: 0; color: var(--muted); font-size: 13px; line-height: 1.55; }\n    .app-metric-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }\n    .app-metric-card, .app-card { padding: 17px; border: 1px solid var(--line); border-radius: 15px; background: #fff; }\n    .app-metric-card span { display: block; color: var(--muted); font-size: 10px; }\n    .app-metric-label-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }\n    .app-metric-label-row select { max-width: 92px; padding: 3px 4px; border: 1px solid var(--line); border-radius: 6px; color: var(--green); background: #fff; font-size: 8px; }\n    .app-metric-card strong { display: block; margin: 7px 0 3px; color: var(--green); font-size: 25px; letter-spacing: -.06em; }\n    .app-metric-card small { color: var(--muted); font-size: 9px; }\n    .app-content-grid { display: grid; grid-template-columns: minmax(0, 1.25fr) minmax(270px, .75fr); gap: 14px; margin-top: 14px; }\n    .app-card h3 { margin: 0 0 4px; font-size: 14px; letter-spacing: -.03em; }\n    .app-card > p { margin: 0 0 14px; color: var(--muted); font-size: 10px; line-height: 1.45; }\n    .app-lead-list { display: grid; }\n    .app-lead-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; border-top: 1px solid var(--line); }\n    .app-lead-row:first-child { border-top: 0; }\n    .app-lead-row button { flex: 1; padding: 0; border: 0; color: var(--ink-2); background: transparent; text-align: left; }\n    .app-lead-row strong { display: block; margin-bottom: 3px; font-size: 11px; }\n    .app-lead-row small { color: var(--muted); font-size: 9px; }\n    .app-lead-value { color: var(--green); font-size: 11px; font-weight: 850; white-space: nowrap; }\n    .app-page-actions { display: flex; flex-wrap: wrap; gap: 9px; margin-top: 17px; }\n    .app-primary-btn, .app-secondary-btn { padding: 10px 13px; border-radius: 999px; font-size: 10px; font-weight: 850; }\n    .app-primary-btn { border: 0; color: #fff; background: var(--green); }\n    .app-secondary-btn { border: 1px solid var(--line); color: var(--ink-2); background: #fff; }\n    .app-table-wrap { overflow-x: auto; border: 1px solid var(--line); border-radius: 13px; background: #fff; }\n    .app-table { width: 100%; min-width: 680px; border-collapse: collapse; font-size: 10px; }\n    .app-table th, .app-table td { padding: 12px; border-top: 1px solid var(--line); text-align: left; }\n    .app-table thead th { border-top: 0; color: var(--green); background: #f3f8f4; font-size: 9px; text-transform: uppercase; letter-spacing: .05em; }\n    .app-table tbody td { color: var(--ink-2); }\n    .app-table button { border: 0; color: var(--green); background: transparent; font-size: 10px; font-weight: 850; }\n    .app-table .app-lead-name { padding: 0; color: var(--ink-2); text-align: left; font-weight: 500; }\n    .app-table .app-lead-name:hover { color: var(--green); }\n    .lead-status-select { width: 100%; padding: 5px 6px; border: 1px solid var(--line); border-radius: 7px; color: var(--ink-2); background: #fff; font: inherit; font-weight: 750; }\n    .lead-status-help { color: var(--muted); font-size: 9px; line-height: 1.45; }\n    .lead-detail-card { margin-top: 14px; }\n    .lead-explanation { margin-top: 14px; padding: 12px; border: 1px solid var(--line); border-radius: 11px; background: #fbfdfb; }\n    .lead-explanation-title { margin-bottom: 7px; color: var(--green); font-size: 10px; font-weight: 850; letter-spacing: .06em; text-transform: uppercase; }\n    .lead-explanation-list { display: grid; gap: 6px; margin: 0; padding-left: 17px; color: var(--ink-2); font-size: 10px; line-height: 1.45; }\n    .lead-explanation-list li::marker { color: var(--green); }\n    .lead-detail-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 9px; margin-top: 14px; }\n    .lead-detail-item { padding: 10px; border-radius: 10px; background: #f5f9f6; }\n    .lead-detail-item span { display: block; margin-bottom: 4px; color: var(--muted); font-size: 9px; }\n    .lead-detail-item strong { color: var(--ink-2); font-size: 11px; }\n    .app-settings-block { margin-top: 16px; padding: 18px; border: 1px solid var(--line); border-radius: 15px; background: #fff; }\n    .app-settings-block h2 { margin: 0 0 5px; font-size: 17px; letter-spacing: -.04em; }\n    .app-settings-block > p { margin: 0 0 15px; color: var(--muted); font-size: 10px; line-height: 1.45; }\n    .app-pricing-matrix { margin-top: 20px; }\n    .pricing-preview-shell { position: absolute; right: 24px; bottom: 24px; z-index: 45; width: min(430px, calc(100vw - 48px)); margin: 0; pointer-events: none; }\n    .pricing-preview-toggle { position: relative; z-index: 2; display: block; margin-left: auto; pointer-events: auto; padding: 8px 11px; border: 1px solid #cfe0d5; border-radius: 999px; color: var(--green); background: #fff; font-size: 10px; font-weight: 800; box-shadow: 0 7px 18px rgba(21,65,46,.12); }\n    .pricing-preview-toggle:hover { border-color: var(--green); background: var(--mint); }\n    .pricing-preview-bubble { position: absolute; right: 0; bottom: calc(100% + 8px); width: 100%; max-height: min(690px, calc(100vh - 92px)); overflow: auto; margin: 0; pointer-events: auto; padding: 15px; border: 1px solid #b9d8c5; border-radius: 17px; background: rgba(255,255,255,.96); box-shadow: 0 16px 38px rgba(21,65,46,.18); backdrop-filter: blur(10px); }\n    .pricing-preview-bubble.hidden { display: none; }\n    .account-pricing-preview { position: relative; right: auto; bottom: auto; width: auto; max-height: none; overflow: visible; margin-top: 16px; }\n    .pricing-preview-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 14px; }\n    .pricing-preview-head strong { display: block; color: var(--green); font-size: 12px; }\n    .pricing-preview-head small { display: block; margin-top: 3px; color: var(--muted); font-size: 9px; }\n    .pricing-preview-note { margin: 10px 0 12px; color: var(--muted); font-size: 10px; line-height: 1.4; }\n    .pricing-preview-cards { display: block; }\n    .pricing-preview-controls { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 8px; }\n    .pricing-preview-controls label { display: grid; gap: 4px; color: var(--muted); font-size: 9px; font-weight: 800; }\n    .pricing-preview-controls select { width: 100%; min-width: 0; padding: 7px 8px; border: 1px solid #d6e5db; border-radius: 8px; color: var(--ink-2); background: #fff; font-size: 10px; }\n    .pricing-preview-total { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 12px; padding: 11px 12px; border: 1px solid #cfe3d5; border-radius: 11px; background: #f4faf6; }\n    .pricing-preview-total span { display: block; color: var(--green); font-size: 10px; font-weight: 850; }\n    .pricing-preview-total small { display: block; margin-top: 3px; color: var(--muted); font-size: 9px; }\n    .pricing-preview-total strong { color: var(--ink); font-size: 18px; letter-spacing: -.04em; text-align: right; white-space: nowrap; }\n    .pricing-preview-breakdown { margin-top: 10px; max-height: 220px; overflow: auto; padding: 8px 10px; border: 1px solid #e4eee7; border-radius: 10px; background: #fff; }\n    .pricing-preview-breakdown-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding-bottom: 5px; color: var(--green); font-size: 10px; }\n    .pricing-preview-breakdown-head small { color: var(--muted); font-size: 8px; font-weight: 500; }\n    .pricing-preview-line { display: flex; justify-content: space-between; gap: 12px; padding: 6px 0; border-top: 1px solid #edf3ee; color: var(--ink-2); font-size: 9px; }\n    .pricing-preview-line span { min-width: 0; }\n    .pricing-preview-line span small { display: block; margin-top: 2px; color: var(--muted); font-size: 8px; line-height: 1.3; }\n    .pricing-preview-line > strong { color: var(--ink); font-size: 10px; white-space: nowrap; }\n    .pricing-preview-subtotal { color: var(--green); }\n    .pricing-preview-subtotal > strong { color: var(--green); }\n\n    /* Floating calculator */\n    .estimate-launcher { position: fixed; right: 24px; bottom: 24px; z-index: 20; display: flex; align-items: center; gap: 10px; padding: 11px 17px 11px 11px; border: 0; border-radius: 999px; color: var(--ink); background: var(--lime); box-shadow: 0 16px 35px rgba(21,65,46,.22), 0 2px 7px rgba(21,65,46,.12); font-size: 13px; font-weight: 850; transition: transform .25s var(--ease), box-shadow .25s ease; }\n    .estimate-launcher:hover { transform: translateY(-3px) scale(1.015); box-shadow: 0 22px 42px rgba(21,65,46,.27); }\n    .estimate-launcher .launcher-copy { line-height: 1.15; text-align: left; }\n    .estimate-launcher .launcher-copy strong { font-weight: inherit; }\n    .launcher-icon { width: 34px; height: 34px; display: grid; place-items: center; border-radius: 50%; color: var(--lime); background: var(--ink); }\n    .launcher-icon svg { width: 18px; height: 18px; }\n    .launcher-pulse { position: absolute; top: 1px; left: 8px; width: 8px; height: 8px; border-radius: 50%; background: #fb6251; box-shadow: 0 0 0 4px rgba(251,98,81,.17); }\n    .widget { position: fixed; right: 24px; bottom: 24px; z-index: 19; width: min(430px, calc(100vw - 28px)); max-height: min(760px, calc(100vh - 42px)); display: flex; flex-direction: column; overflow: hidden; border: 1px solid rgba(224,232,226,.95); border-radius: var(--radius-xl); background: var(--surface); box-shadow: var(--shadow); transform-origin: bottom right; animation: pop-in .34s var(--ease) both; }\n    @keyframes pop-in { from { opacity: 0; transform: scale(.9) translateY(16px); } to { opacity: 1; transform: scale(1) translateY(0); } }\n    .widget-head { flex: 0 0 auto; padding: 19px 20px 17px; color: #fff; background: var(--ink); }\n    .head-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 15px; }\n    .mini-brand { display: flex; align-items: center; gap: 8px; color: #c4d8ce; font-size: 10px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; }\n    .mini-brand i { display: block; width: 8px; height: 8px; border-radius: 50%; background: var(--lime); }\n    .close-widget { width: 29px; height: 29px; display: grid; place-items: center; border: 1px solid rgba(255,255,255,.18); border-radius: 50%; color: #fff; background: transparent; font-size: 18px; line-height: 1; }\n    .close-widget:hover { background: rgba(255,255,255,.12); }\n    .widget-head h2 { margin: 16px 0 5px; font-size: 23px; line-height: 1.1; letter-spacing: -.045em; }\n    .widget-head p { margin: 0; color: #a9c1b6; font-size: 12px; line-height: 1.45; }\n    .progress-track { height: 3px; margin-top: 18px; overflow: hidden; border-radius: 10px; background: rgba(255,255,255,.17); }\n    .progress-bar { width: 12.5%; height: 100%; border-radius: inherit; background: var(--lime); transition: width .35s var(--ease); }\n    .widget-body { min-height: 0; overflow-y: auto; overflow-anchor: none; padding: 21px 20px 18px; }\n    .owner-dashboard-body { --owner-space-1: 20px; --owner-space-2: 40px; min-height: 0; overflow-y: auto; overflow-anchor: none; padding: 21px 20px 20px; }\n    .owner-dashboard-kicker { margin-bottom: 6px; color: var(--green); font-size: 10px; font-weight: 850; letter-spacing: .1em; text-transform: uppercase; }\n    .owner-dashboard-body h3 { margin: 0; font-size: 22px; line-height: 1.15; letter-spacing: -.045em; }\n    .owner-dashboard-help { margin: 4px 0 var(--owner-space-1); color: var(--muted); font-size: 12px; line-height: 1.5; }\n    .owner-metric-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }\n    .owner-metric { padding: 13px; border: 1px solid var(--line); border-radius: 13px; background: #fbfdfb; }\n    .owner-metric:first-child { color: #fff; border-color: var(--ink); background: var(--ink); }\n    .owner-metric span, .owner-metric small { display: block; color: var(--muted); font-size: 9px; }\n    .owner-metric:first-child span, .owner-metric:first-child small { color: #a9c1b6; }\n    .owner-metric strong { display: block; margin: 5px 0 3px; color: var(--ink); font-size: 20px; letter-spacing: -.06em; }\n    .owner-metric:first-child strong { color: #fff; }\n    .owner-health { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: var(--owner-space-1); padding: 12px 13px; border: 1px solid #d9ebdf; border-radius: 13px; background: var(--mint); }\n    .owner-health strong { display: block; margin-bottom: 3px; font-size: 11px; }\n    .owner-health span { color: var(--muted); font-size: 9px; }\n    .owner-health-badge { padding: 6px 8px; border-radius: 999px; color: var(--green); background: #fff; font-size: 9px; font-weight: 850; white-space: nowrap; }\n    .owner-panel-section { margin-top: var(--owner-space-2); }\n    .owner-panel-section h4 { margin: 0 0 4px; color: var(--green); font-size: 10px; letter-spacing: .09em; text-transform: uppercase; }\n    .owner-section-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; }\n    .owner-section-heading h4 { margin-bottom: 0; }\n    .owner-small-btn { padding: 5px 8px; border: 1px solid var(--line); border-radius: 999px; color: var(--green); background: #fff; font-size: 9px; font-weight: 800; white-space: nowrap; }\n    .owner-small-btn:hover { border-color: var(--green); background: var(--mint); }\n    .owner-settings { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }\n    .owner-setting { padding: 10px; border: 1px solid var(--line); border-radius: 11px; background: #fbfdfb; }\n    .owner-setting span { display: block; margin-bottom: 4px; color: var(--muted); font-size: 9px; }\n    .owner-setting strong { display: block; color: var(--ink-2); font-size: 11px; }\n    .owner-setting small { display: block; margin-top: 3px; color: var(--muted); font-size: 8px; }\n    .owner-editor-note, .owner-save-note { margin: 0 0 8px; color: var(--muted); font-size: 9px; line-height: 1.45; }\n    .owner-save-note { margin: 8px 0 0; color: var(--green); }\n    .owner-save-btn { width: 100%; margin-top: 16px; padding: 11px 14px; border: 1px solid var(--green); border-radius: 999px; color: var(--green); background: #fff; font-size: 11px; font-weight: 850; }\n    .owner-save-btn:hover { color: #fff; background: var(--green); }\n    .kitchen-pricing-group { margin-top: var(--owner-space-1); padding-top: 8px; border-top: 1px solid var(--line); }\n    .kitchen-pricing-group:first-child { margin-top: 0; padding-top: 0; border-top: 0; }\n    .kitchen-pricing-group h5 { margin: 0 0 4px; color: var(--ink-2); font-size: 10px; }\n    .owner-pricing-row { margin-top: var(--owner-space-1); }\n    .owner-pricing-row > strong { display: block; margin-bottom: 4px; color: var(--muted); font-size: 9px; }\n    .owner-pricing-table-wrap { overflow-x: auto; border: 1px solid var(--line); border-radius: 11px; background: #fff; }\n    .owner-pricing-table { width: 100%; min-width: 330px; border-collapse: collapse; font-size: 9px; }\n    .owner-pricing-table th, .owner-pricing-table td { padding: 7px 8px; border-top: 1px solid var(--line); text-align: left; vertical-align: middle; }\n    .owner-pricing-table thead th { border-top: 0; color: var(--green); background: #f3f8f4; font-size: 8px; font-weight: 850; text-transform: uppercase; letter-spacing: .04em; }\n    .owner-pricing-table thead th small { display: block; margin-top: 3px; color: var(--muted); font-size: 7px; font-weight: 750; letter-spacing: 0; line-height: 1.2; text-transform: none; }\n    .owner-pricing-table tbody th { min-width: 130px; color: var(--ink-2); font-weight: 750; }\n    .owner-pricing-table tbody td { min-width: 86px; }\n    .owner-pricing-table.compact { min-width: 250px; }\n    .owner-pricing-table.add-on-table { min-width: 430px; }\n    .owner-pricing-table.add-on-table tbody td:last-child { color: var(--muted); font-size: 8px; line-height: 1.35; }\n    .owner-table-input { width: 100%; min-width: 66px; min-height: 29px; padding: 6px 7px; border: 1px solid var(--line); border-radius: 7px; color: var(--ink-2); background: #fff; font-size: 10px; }\n    .owner-table-input:focus { outline: 2px solid rgba(11,101,75,.18); border-color: var(--green); }\n    .kitchen-pricing-group p { margin: 0 0 8px; color: var(--muted); font-size: 9px; line-height: 1.4; }\n    .owner-service-list { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }\n    .owner-service-option { display: flex; align-items: center; gap: 8px; padding: 10px; border: 1px solid var(--line); border-radius: 11px; color: var(--ink-2); background: #fbfdfb; font-size: 11px; font-weight: 750; }\n    .owner-service-option input { accent-color: var(--green); }\n    .owner-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; }\n    .owner-field { display: block; }\n    .owner-field > span { display: block; margin: 0 0 5px; color: var(--muted); font-size: 9px; line-height: 1.2; }\n    .owner-field-note { display: block; margin-top: 3px; color: var(--muted); font-size: 8px; font-weight: 600; }\n    .range-adjustment-field.is-inactive { opacity: .48; }\n    .range-adjustment-field.is-inactive input { cursor: not-allowed; background: #f6f8f6; }\n    .owner-field input, .owner-field select { width: 100%; min-height: 34px; padding: 8px 9px; border: 1px solid var(--line); border-radius: 9px; color: var(--ink-2); background: #fff; font-size: 11px; }\n    .owner-field input:focus, .owner-field select:focus { outline: 2px solid rgba(11,101,75,.18); border-color: var(--green); }\n    .owner-activity { border: 1px solid var(--line); border-radius: 13px; overflow: hidden; }\n    .owner-activity-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 10px 12px; border-top: 1px solid var(--line); font-size: 10px; }\n    .owner-activity-row:first-child { border-top: 0; }\n    .owner-activity-row strong { display: block; margin-bottom: 2px; color: var(--ink-2); font-size: 10px; }\n    .owner-activity-row small { color: var(--muted); font-size: 9px; }\n    .owner-activity-row > strong { color: var(--green); white-space: nowrap; }\n    .owner-dashboard-action { width: 100%; margin-top: 18px; }\n    .step-kicker { margin-bottom: 8px; color: var(--green); font-size: 10px; font-weight: 850; letter-spacing: .1em; text-transform: uppercase; }\n    .step-title { margin: 0; font-size: 22px; line-height: 1.15; letter-spacing: -.045em; }\n    .step-help { margin: 7px 0 19px; color: var(--muted); font-size: 12px; line-height: 1.5; }\n    .choice { width: 100%; min-height: 74px; display: flex; align-items: flex-start; gap: 10px; padding: 13px 12px; border: 1px solid var(--line); border-radius: var(--radius-md); color: var(--ink); background: #fff; text-align: left; transition: border .18s ease, box-shadow .18s ease, transform .18s ease, background .18s ease; }\n    .choice:hover { border-color: #a8cdbb; box-shadow: 0 7px 15px rgba(16,37,31,.07); transform: translateY(-1px); }\n    .choice.selected { border-color: var(--green); background: var(--mint); box-shadow: 0 0 0 2px rgba(12,101,75,.09); }\n    .field { margin-top: 14px; }\n    .field:first-child { margin-top: 0; }\n    .field label { display: block; margin-bottom: 7px; font-size: 11px; font-weight: 800; }\n    .field input, .field textarea, .field select { width: 100%; padding: 12px 13px; border: 1px solid var(--line); border-radius: var(--radius-sm); outline: none; color: var(--ink); background: #fcfdfc; font-size: 13px; transition: border .18s ease, box-shadow .18s ease; }\n    .field input:focus, .field textarea:focus, .field select:focus { border-color: var(--green); box-shadow: 0 0 0 3px rgba(12,101,75,.1); }\n    .field textarea { min-height: 80px; resize: vertical; }\n    .helper-line { margin: 7px 0 0; color: var(--muted); font-size: 10px; line-height: 1.4; }\n    .error-line { display: none; margin: 12px 0 0; padding: 11px 12px; border: 1px solid rgba(190,54,43,.28); border-radius: 10px; color: var(--danger); background: #fff4f2; font-size: 11px; font-weight: 800; line-height: 1.4; box-shadow: 0 5px 14px rgba(190,54,43,.08); }\n    .error-line.show { display: block; position: sticky; top: 0; z-index: 6; animation: validation-error-in .22s ease both; }\n    .validation-missing { border: 1px solid rgba(190,54,43,.72) !important; box-shadow: none !important; }\n    .radio-list.validation-missing, .check-list.validation-missing { padding: 4px; border-radius: 10px; }\n    .radio-list.validation-missing .radio-item label, .check-list.validation-missing .check-item label { border-color: var(--line); background: transparent; }\n    @keyframes validation-error-in { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }\n    .check-list { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }\n    .check-item { position: relative; }\n    .check-item input { position: absolute; opacity: 0; pointer-events: none; }\n    .check-item label { min-height: 45px; display: flex; align-items: center; gap: 8px; padding: 10px 9px; border: 1px solid var(--line); border-radius: 10px; color: var(--ink-2); font-size: 11px; line-height: 1.25; cursor: pointer; transition: .18s ease; }\n    .check-item label:before { content: \"\"; width: 15px; height: 15px; flex: 0 0 15px; border: 1.5px solid #bdcac2; border-radius: 4px; background: #fff; }\n    .check-item input:checked + label { border-color: var(--green); color: var(--ink); background: var(--mint); }\n    .check-item input:checked + label:before { border-color: var(--green); background: var(--green); box-shadow: inset 0 0 0 3px var(--mint); }\n    .radio-list { display: grid; gap: 8px; }\n    .radio-item { position: relative; }\n    .radio-item input { position: absolute; opacity: 0; pointer-events: none; }\n    .radio-item label { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 12px 13px; border: 1px solid var(--line); border-radius: 11px; font-size: 12px; cursor: pointer; }\n    .radio-item label > span { flex: 1; }\n    .radio-description { display: block; margin-top: 4px; color: var(--muted); font-size: 10px; font-weight: 500; line-height: 1.35; }\n    .radio-item label:after { content: \"\"; width: 16px; height: 16px; min-width: 16px; min-height: 16px; flex: 0 0 16px; box-sizing: border-box; border: 1.5px solid #bdcac2; border-radius: 50%; }\n    .radio-item input:checked + label { border-color: var(--green); font-weight: 750; background: var(--mint); }\n    .radio-item input[name=\"propertyType\"] + label,\n    .radio-item input[name=\"propertyType\"]:checked + label { font-weight: 400; }\n    .radio-item input:checked + label:after { border: 4px solid var(--green); background: var(--mint); }\n    .sub-question { margin-top: 18px; padding-top: 18px; border-top: 1px solid var(--line); }\n    .sub-question:first-child { margin-top: 0; padding-top: 0; border-top: 0; }\n    .sub-question h3 { margin: 0 0 11px; font-size: 12px; }\n    .route-stack { display: grid; gap: 10px; }\n    .route-card { padding: 14px; border: 1px solid #d9e8de; border-radius: 12px; background: #fff; box-shadow: none; }\n    .interior-area-card { border-left: 1px solid #d9e8de; }\n    .area-card-step { margin-bottom: 4px; color: var(--green); font-size: 9px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; }\n    .route-card > h3 { margin: 0; color: var(--ink); font-size: 14px; line-height: 1.2; letter-spacing: -.02em; }\n    .route-card > .step-help { margin-bottom: 4px; }\n    .route-card .sub-question { margin-top: 15px; padding-top: 15px; }\n    .route-card .sub-question h3 { margin-bottom: 10px; color: var(--ink-2); font-size: 11px; }\n    .kitchen-touch-section { margin-top: 2px; }\n    .kitchen-details-title { margin-bottom: 7px; color: var(--ink-2); font-size: 11px; font-weight: 850; }\n    .automatic-scope-note { margin: 0 0 14px; padding: 11px 12px; border: 1px solid #cfe2d6; border-radius: 11px; color: var(--ink-2); background: var(--mint); font-size: 10px; line-height: 1.45; }\n    .automatic-scope-note strong { display: block; margin-bottom: 3px; color: var(--green); font-size: 10px; }\n    .automatic-scope-note span { display: block; color: var(--muted); }\n    .kitchen-touch-list { gap: 6px 8px; }\n    .kitchen-touch-list .check-item label { min-height: 40px; padding: 8px 9px; }\n    .kitchen-hidden-details { display: flex; flex-direction: column; margin-top: 14px; padding: 12px 0 0 12px; border-top: 1px solid var(--line); border-left: 2px solid #dfeae2; }\n    .kitchen-hidden-details .kitchen-option-group + .kitchen-option-group { margin-top: 10px; }\n    .kitchen-major-addons { margin-top: 16px; padding-top: 14px; border-top: 1px solid var(--line); }\n    .bathroom-size-followup { margin-top: 18px; padding-top: 18px; border-top: 1px solid var(--line); }\n    .bathroom-size-followup h3 { margin: 0 0 10px; color: var(--ink-2); font-size: 11px; }\n    .kitchen-option-groups { display: grid; gap: 8px; }\n    .kitchen-option-group > strong { display: block; margin-bottom: 2px; color: var(--ink-2); font-size: 11px; }\n    .kitchen-cabinet-followup { margin: 7px 0 0 10px; padding-left: 10px; border-left: 2px solid #dfeae2; }\n    .kitchen-cabinet-followup > strong { display: block; margin-bottom: 2px; color: var(--muted); font-size: 10px; }\n    .kitchen-option-group .radio-list { display: flex; flex-wrap: wrap; gap: 2px 16px; }\n    .kitchen-option-group .radio-item label { display: inline-flex; align-items: center; justify-content: flex-start; gap: 7px; padding: 4px 0; border-color: transparent; background: transparent; font-size: 11px; }\n    .kitchen-option-group .radio-item label:after { margin-top: 0; }\n    .kitchen-option-group .radio-item input:checked + label { border-color: transparent; background: transparent; color: var(--green); }\n    .kitchen-option-group .check-list { grid-template-columns: repeat(2, minmax(0,1fr)); gap: 4px 10px; }\n    .kitchen-option-group .check-item label { min-height: 32px; padding: 5px 0; border-color: transparent; background: transparent; font-size: 11px; }\n    .kitchen-option-group .check-item input:checked + label { border-color: transparent; background: transparent; }\n    /* Keep hidden details compact while preserving a clear parent/follow-up hierarchy. */\n    .kitchen-hidden-details { gap: 8px; margin-top: 10px; padding: 10px 0 2px 10px; }\n    .kitchen-hidden-details .kitchen-details-title { margin-bottom: 0; }\n    .kitchen-hidden-details .kitchen-option-group { display: flex; width: 100%; flex-direction: column; gap: 3px; }\n    .kitchen-hidden-details .kitchen-option-group + .kitchen-option-group { margin-top: 0; }\n    .kitchen-hidden-details > .kitchen-option-group { position: relative; padding: 2px 0; border-top: 0; }\n    .kitchen-hidden-details > .kitchen-option-group:before { content: \"\"; display: block; height: 1px; margin: 0 0 7px; background: var(--line); }\n    .hidden-detail-remove { position: absolute; top: 9px; right: 1px; z-index: 1; display: grid; place-items: center; width: 19px; height: 19px; padding: 0 0 1px; border: 1px solid transparent; border-radius: 6px; color: #789286; background: #f5f9f6; font-family: Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 1; text-align: center; transition: color .18s ease, border-color .18s ease, background .18s ease, transform .18s ease; }\n    .first-hidden-detail > .hidden-detail-remove { top: 1px; }\n    .hidden-detail-remove:hover, .hidden-detail-remove:focus-visible { border-color: #e5aaa3; color: var(--danger); background: #fff5f3; outline: none; transform: scale(1.04); }\n    .kitchen-hidden-details > .kitchen-details-title + .kitchen-option-group:before,\n    .kitchen-hidden-details > .first-hidden-detail:before { display: none; }\n    .kitchen-hidden-details .kitchen-option-group > strong { margin: 0; padding-right: 24px; color: var(--ink); font-weight: 700; line-height: 1.25; }\n    .kitchen-hidden-details .kitchen-option-group .radio-list { display: flex; flex-wrap: wrap; gap: 2px 12px; width: 100%; }\n    .kitchen-hidden-details .kitchen-option-group .radio-item { flex: 0 1 auto; }\n    .kitchen-hidden-details .kitchen-option-group .radio-item label { width: auto; min-height: 30px; padding: 4px 6px; border: 1px solid transparent; border-radius: 8px; background: transparent; }\n    .kitchen-hidden-details .kitchen-option-group .radio-item label,\n    .kitchen-hidden-details .kitchen-option-group .radio-item input:checked + label,\n    .kitchen-hidden-details .kitchen-option-group .check-item label { font-weight: 400; }\n    .kitchen-hidden-details > .kitchen-details-title + .kitchen-option-group { padding-top: 2px; border-top: 0; }\n    .kitchen-hidden-details .kitchen-option-group .radio-item input:checked + label { border-color: transparent; background: transparent; color: var(--green); }\n    .kitchen-hidden-details .kitchen-cabinet-followup { width: calc(100% - 8px); margin: 5px 0 0 8px; padding: 3px 0 0 10px; border: 0; }\n    .kitchen-hidden-details .kitchen-cabinet-followup > strong { margin: 0 0 3px; line-height: 1.2; }\n    .kitchen-hidden-details .kitchen-option-group .kitchen-cabinet-followup .radio-list,\n    .kitchen-hidden-details .kitchen-option-group .kitchen-cabinet-followup .check-list { display: flex; flex-wrap: wrap; gap: 1px 14px; }\n    .kitchen-hidden-details .kitchen-option-group .kitchen-cabinet-followup .radio-item label,\n    .kitchen-hidden-details .kitchen-option-group .kitchen-cabinet-followup .check-item label { width: auto; min-height: 23px; padding: 2px 0; border: 0; border-radius: 0; background: transparent; font-size: 11px; }\n    .kitchen-hidden-details .kitchen-option-group .kitchen-cabinet-followup .radio-item input:checked + label,\n    .kitchen-hidden-details .kitchen-option-group .kitchen-cabinet-followup .check-item input:checked + label { border: 0; background: transparent; color: var(--green); }\n    .kitchen-hidden-details .window-count-field { margin: 7px 0 0 8px; padding: 0 0 0 10px; border-top: 0; }\n    .kitchen-hidden-details .window-count-field label { margin: 0 0 4px; color: var(--muted); font-size: 10px; font-weight: 700; }\n    .kitchen-hidden-details .window-count-field input { width: min(100%, 180px); padding: 7px 9px; border-radius: 8px; font-size: 11px; }\n    .kitchen-hidden-details .kitchen-option-group .check-list { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 2px 8px; width: 100%; }\n    .kitchen-hidden-details .kitchen-option-group .check-item label { width: 100%; min-height: 30px; padding: 5px 6px; border: 1px solid transparent; border-radius: 8px; background: transparent; }\n    .kitchen-hidden-details .kitchen-option-group .check-item input:checked + label { border-color: transparent; background: transparent; color: var(--green); }\n    .water-move-options { display: grid; gap: 3px; }\n    .water-move-option { display: grid; gap: 1px; }\n    .water-move-parent .check-item label { min-height: 29px; padding: 5px 7px; }\n    .water-move-suboptions { margin-left: 18px; padding: 1px 0 3px; }\n    .kitchen-hidden-details .kitchen-option-group .water-move-suboptions .radio-list { display: flex; flex-wrap: wrap; gap: 1px 14px; }\n    .kitchen-hidden-details .kitchen-option-group .water-move-suboptions .radio-item label { width: auto; min-height: 23px; padding: 2px 0; border: 0; border-radius: 0; color: var(--ink-2); background: transparent; font-size: 11px; }\n    .kitchen-hidden-details .kitchen-option-group .water-move-suboptions .radio-item label:before { content: \"\"; width: 8px; height: 8px; flex: 0 0 8px; border: 1px solid #aebeb4; border-radius: 50%; }\n    .kitchen-hidden-details .kitchen-option-group .water-move-suboptions .radio-item input:checked + label { border: 0; color: var(--green); background: transparent; }\n    .kitchen-hidden-details .kitchen-option-group .water-move-suboptions .radio-item input:checked + label:before { border-color: var(--green); background: var(--green); box-shadow: inset 0 0 0 2px #f5f9f6; }\n    .range-readout { display: flex; justify-content: space-between; gap: 10px; margin-top: 7px; color: var(--muted); font-size: 10px; }\n    .range-readout output { color: var(--green); font-weight: 850; }\n    .route-card input[type=\"range\"] { width: 100%; accent-color: var(--green); }\n    .section-label { margin: 18px 0 9px; color: var(--green); font-size: 10px; font-weight: 850; letter-spacing: .09em; text-transform: uppercase; }\n    .summary-card { padding: 15px; border: 1px solid #e8f0eb; border-radius: 14px; background: #f7faf8; }\n    .summary-card + .summary-card { margin-top: 10px; }\n    .summary-card-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 9px; }\n    .summary-card-head strong { font-size: 12px; }\n    .edit-link { padding: 0; border: 0; color: var(--green); background: transparent; font-size: 10px; font-weight: 850; }\n    .summary-row { display: flex; justify-content: space-between; gap: 15px; padding: 6px 0; border-top: 1px solid #e7eee9; color: var(--muted); font-size: 10px; }\n    .summary-row:first-of-type { border-top: 0; }\n    .summary-row strong { color: var(--ink-2); font-size: 10px; text-align: right; }\n    .summary-note { margin: 12px 0 0; color: var(--muted); font-size: 10px; line-height: 1.45; }\n    .widget-foot { flex: 0 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 14px; padding: 14px 20px 17px; border-top: 1px solid #eff2ef; background: #fff; }\n    .back-btn { padding: 9px 0; border: 0; color: var(--muted); background: transparent; font-size: 12px; font-weight: 750; }\n    .back-btn:hover { color: var(--ink); }\n    .next-btn { padding: 12px 17px; border: 0; border-radius: 999px; color: #fff; background: var(--green); font-size: 12px; font-weight: 850; box-shadow: 0 8px 16px rgba(12,101,75,.2); transition: transform .2s var(--ease), background .2s ease; }\n    .next-btn:hover { background: var(--green-dark); transform: translateY(-1px); }\n    .secure-note { display: flex; align-items: center; gap: 5px; color: var(--muted); font-size: 9px; }\n    .secure-note svg { width: 12px; height: 12px; color: var(--green); }\n    .estimate-result { text-align: center; }\n    .result-icon { width: 48px; height: 48px; display: grid; place-items: center; margin: 0 auto 13px; border-radius: 50%; color: var(--green); background: var(--mint); }\n    .result-icon svg { width: 24px; height: 24px; }\n    .estimate-result h2 { margin: 0; font-size: 22px; letter-spacing: -.05em; }\n    .estimate-range { margin: 8px 0 6px; color: var(--green); font-size: 31px; line-height: 1.05; font-weight: 900; letter-spacing: -.06em; }\n    .estimate-note { max-width: 320px; margin: 0 auto; color: var(--muted); font-size: 10px; line-height: 1.45; }\n    .result-card { margin-top: 20px; padding: 15px; border: 1px solid #e8f0eb; border-radius: 14px; background: #f7faf8; text-align: left; }\n    .result-card h3 { margin: 0 0 10px; color: var(--green); font-size: 10px; letter-spacing: .08em; text-transform: uppercase; }\n    .based-on { display: flex; flex-wrap: wrap; gap: 6px; }\n    .pill { display: inline-flex; padding: 6px 8px; border: 1px solid #e0eae4; border-radius: 99px; color: var(--ink-2); background: #fff; font-size: 10px; }\n    .include-columns { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 16px; text-align: left; }\n    .include-columns h4 { margin: 0 0 8px; font-size: 10px; }\n    .include-columns ul { padding: 0; margin: 0; list-style: none; color: var(--muted); font-size: 10px; line-height: 1.6; }\n    .include-columns li:before { content: \"\u2713\"; margin-right: 5px; color: var(--green); font-weight: 900; }\n    .include-columns .not-included li:before { content: \"\u2013\"; color: #aa766d; }\n    .fine-print { margin: 17px 2px 0; color: var(--muted); font-size: 9px; line-height: 1.5; text-align: left; }\n    .review-result .result-icon { color: #9a6a13; background: #fff3d2; }\n    .review-result .estimate-range { color: #9a6a13; font-size: 25px; }\n    .review-result .result-card { border-color: #f4e5bc; background: #fffaf0; }\n    .calc-breakdown { margin-top: 16px; padding-top: 14px; border-top: 1px solid var(--line); text-align: left; }\n    .owner-only { display: none !important; }\n    .owner-preview-active .owner-only { display: block !important; }\n    .owner-preview-tools { margin-top: 14px; text-align: left; }\n    .owner-preview-toggle { border: 1px solid var(--line); background: var(--soft); color: var(--ink); border-radius: 8px; padding: 8px 10px; font-size: 11px; font-weight: 800; cursor: pointer; }\n    .calc-breakdown summary { color: var(--green); font-size: 10px; font-weight: 850; cursor: pointer; }\n    .calc-line { display: flex; justify-content: space-between; gap: 10px; padding: 6px 0; color: var(--muted); font-size: 10px; }\n    .calc-line strong { color: var(--ink-2); }\n\n    @media (max-width: 860px) {\n      .hero { grid-template-columns: 1fr; gap: 30px; padding-top: 44px; }\n      .hero-copy { margin: 0 auto; text-align: center; }\n      .hero-copy > p { margin-left: auto; margin-right: auto; }\n      .hero-actions, .trust-row { justify-content: center; }\n      .topbar { flex-wrap: wrap; }\n      .nav { display: flex !important; flex: 1 1 100%; flex-wrap: wrap; justify-content: center; }\n      .visual { min-height: 420px; }\n      .owner-grid { grid-template-columns: 1fr 1fr; }\n      .app-shell { grid-template-columns: 190px minmax(0, 1fr); }\n      .app-content-grid { grid-template-columns: 1fr; }\n    }\n    @media (max-width: 560px) {\n      .topbar, .hero, .owner-strip, .site-footer, .pricing-section { width: calc(100% - 32px); }\n      .topbar { flex-direction: column; flex-wrap: nowrap; align-items: stretch; gap: 8px; overflow: hidden; }\n      .brand { flex: 0 0 auto; justify-content: flex-start; }\n      .nav { display: flex !important; flex: 0 0 auto; min-width: 0; flex-wrap: nowrap; justify-content: flex-start; align-items: center; gap: 4px; width: 100%; overflow-x: auto; scrollbar-width: none; -ms-overflow-style: none; }\n      .nav::-webkit-scrollbar { display: none; width: 0; height: 0; }\n      .nav a, .nav button { display: inline-flex !important; flex: 0 0 auto; visibility: visible !important; opacity: 1 !important; align-items: center; justify-content: center; white-space: nowrap; }\n      .nav a { padding: 7px 6px; font-size: 10px; }\n      .nav .topbar-cta, .nav .signin-cta, .nav .signup-cta { padding: 8px 8px; font-size: 9px; }\n      .nav .signin-cta { margin-left: auto; }\n      .nav .signup-cta { margin-left: 0; }\n      .app-shell { display: block; overflow-y: auto; -webkit-overflow-scrolling: touch; }\n      .app-sidebar { position: sticky; top: 0; z-index: 30; flex-direction: column; align-items: stretch; min-width: 0; gap: 8px; padding: 12px 14px; }\n      .app-brand { flex: 0 0 auto; align-self: flex-start; }\n      .app-nav { flex: 0 0 auto; width: 100%; min-width: 0; justify-content: flex-start; gap: 6px; padding: 1px 0 5px; }\n      .app-sidebar-label, .app-sidebar-foot { display: none; }\n      .app-nav { display: flex; overflow-x: auto; scroll-snap-type: x proximity; scrollbar-width: thin; scrollbar-color: rgba(183,238,116,.7) transparent; -webkit-overflow-scrolling: touch; }\n      .app-nav::-webkit-scrollbar { display: block; width: 100%; height: 4px; }\n      .app-nav::-webkit-scrollbar-track { background: rgba(255,255,255,.08); border-radius: 99px; }\n      .app-nav::-webkit-scrollbar-thumb { background: rgba(183,238,116,.7); border-radius: 99px; }\n      .app-nav button { width: auto; flex: 0 0 auto; white-space: nowrap; scroll-snap-align: start; }\n      .app-main { min-height: calc(100vh - 70px); overflow: visible; padding: 22px 16px 40px; }\n      .app-metric-grid { grid-template-columns: 1fr; }\n      .lead-detail-grid { grid-template-columns: 1fr 1fr; }\n      .pricing-card { padding: 21px; }\n\n      .topbar { padding-top: 16px; }\n      h1 { font-size: 47px; }\n      .hero { min-height: auto; padding-top: 20px; padding-bottom: 38px; }\n      h1 { margin: 12px 0; font-size: 42px; }\n      .hero-copy > p { font-size: 15px; line-height: 1.45; }\n      .hero-actions { margin-top: 38px; gap: 8px; flex-wrap: nowrap; }\n      .hero-actions .primary-btn { padding: 12px 14px; font-size: 11px; white-space: nowrap; }\n      .hero-actions .secondary-btn { font-size: 11px; white-space: nowrap; }\n      .trust-row { display: none; }\n      .hero { padding-bottom: 24px; }\n      .visual { min-height: 280px; margin-top: 14px; }\n      .visual:before { width: 310px; height: 310px; }\n      .visual-card { max-width: 320px; }\n      .visual-badge { left: -14px; bottom: 28px; }\n      .estimate-launcher { right: 14px; bottom: 14px; }\n      .widget { right: 14px; bottom: 14px; width: calc(100vw - 28px); max-height: calc(100vh - 28px); border-radius: 21px; }\n      .widget-head { padding: 17px 17px 15px; }\n      .widget-body { padding: 18px 17px 14px; }\n      .widget-foot { padding: 12px 17px 14px; }\n      .step-title { font-size: 20px; }\n      .site-footer { display: block; line-height: 1.7; }\n      .pricing-preview-shell { right: 14px; bottom: 10px; width: calc(100vw - 28px); }\n      .pricing-preview-controls { grid-template-columns: 1fr 1fr; }\n      .account-pricing-preview { width: 100%; padding: 13px; }\n      .pricing-preview-total { align-items: flex-start; flex-direction: column; }\n      .pricing-preview-total strong { text-align: left; }\n    }\n  ";
    var markup = "<button class=\"estimate-launcher\" id=\"estimateLauncher\" aria-label=\"Answer a few questions to get an instant remodeling quote\"><span class=\"launcher-pulse\"></span><span class=\"launcher-icon\" aria-hidden=\"true\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H12l-4.7 4v-4H6.5A2.5 2.5 0 0 1 4 13.5z\"/><path d=\"M8 8h8M8 11.5h5\"/></svg></span><span class=\"launcher-copy\">Answer a few questions<br><strong>\u2192 Get an instant quote</strong></span></button>\n\n    <section class=\"widget hidden\" id=\"estimateWidget\" aria-label=\"Remodeling estimate calculator preview\" aria-live=\"polite\">\n      <header class=\"widget-head\"><div class=\"head-row\"><div class=\"mini-brand\"><i></i> Live quote bubble</div><button class=\"close-widget\" id=\"closeWidget\" aria-label=\"Close estimate\">\u00d7</button></div><h2 id=\"widgetHeadline\">Turn project answers into a quote</h2><p id=\"widgetSubhead\">Ask only what changes the price while your pricing stays in control.</p><div class=\"progress-track\" aria-hidden=\"true\"><div class=\"progress-bar\" id=\"progressBar\"></div></div></header>\n      <div class=\"widget-body\" id=\"widgetBody\"></div>\n      <footer class=\"widget-foot\" id=\"widgetFoot\"><button class=\"back-btn\" id=\"backButton\">\u2190 Back</button><span class=\"secure-note\"><svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><rect x=\"5\" y=\"10\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 10V7a4 4 0 0 1 8 0v3\"/></svg> Private & secure</span><button class=\"next-btn\" id=\"nextButton\">Continue \u2192</button></footer>\n    </section>\n\n    <section class=\"widget owner-dashboard hidden\" id=\"ownerPreviewPanel\" aria-label=\"Remodeler settings preview\" aria-live=\"polite\">\n      <header class=\"widget-head\"><div class=\"head-row\"><div class=\"mini-brand\"><i></i> Live remodeler settings preview</div><button class=\"close-widget\" id=\"closeOwnerPreview\" aria-label=\"Close remodeler settings preview\">\u00d7</button></div><h2>Remodeler metrics</h2><p>See how the owner dashboard tracks quote activity, response speed and pricing logic.</p></header>\n      <div class=\"owner-dashboard-body\">\n        <div class=\"owner-dashboard-kicker\">Overview \u00b7 Live workspace</div>\n        <h3>Know what every quote is doing.</h3>\n        <p class=\"owner-dashboard-help\">A live view for the remodeling team.</p>\n        <div class=\"owner-metric-grid\">\n          <div class=\"owner-metric\"><span>Quote value created</span><strong id=\"ownerQuoteValueMetric\">$0k</strong><small id=\"ownerQuoteValueMeta\">Live from lead records</small></div>\n          <div class=\"owner-metric\"><span>New quote requests</span><strong id=\"ownerQuoteRequestsMetric\">0</strong><small id=\"ownerQuoteRequestsMeta\">0 ready for follow-up</small></div>\n          <div class=\"owner-metric\"><span>Quote-to-lead rate</span><strong id=\"ownerQuoteLeadRateMetric\">0%</strong><small id=\"ownerQuoteLeadRateMeta\">0 of 0 leads have a quote</small></div>\n        </div>\n        <div class=\"owner-panel-section\"><div class=\"owner-section-heading\"><h4>Recent quote activity</h4><button type=\"button\" class=\"owner-small-btn\" id=\"showAllQuotesButton\">Show all quotes</button></div><div class=\"owner-activity\" id=\"ownerRecentQuotes\"><div class=\"owner-activity-row\"><div><strong>Kitchen + Bath remodel</strong><small>New lead \u00b7 2 minutes ago</small></div><strong>$42k\u2013$51k</strong></div><div class=\"owner-activity-row\"><div><strong>Kitchen \u00b7 Full Gut</strong><small>Follow-up needed \u00b7 Today</small></div><strong>$26k\u2013$31k</strong></div><div class=\"owner-activity-row\"><div><strong>Bath \u00b7 Cosmetic / Pull and Replace</strong><small>Quote viewed \u00b7 Today</small></div><strong>$14k\u2013$19k</strong></div><div class=\"owner-activity-row owner-extra-quote hidden\"><div><strong>Kitchen \u00b7 Hybrid Refresh</strong><small>Quote sent \u00b7 Yesterday</small></div><strong>$18k\u2013$24k</strong></div><div class=\"owner-activity-row owner-extra-quote hidden\"><div><strong>Bath \u00b7 Full Gut Remodel</strong><small>Quote viewed \u00b7 Yesterday</small></div><strong>$28k\u2013$36k</strong></div><div class=\"owner-activity-row owner-extra-quote hidden\"><div><strong>Kitchen \u00b7 Cosmetic / Pull and Replace</strong><small>New lead \u00b7 2 days ago</small></div><strong>$9k\u2013$13k</strong></div></div></div>\n        <div class=\"owner-panel-section\"><h4>Services offered in the calculator</h4><p class=\"owner-editor-note\">Choose which services homeowners can select.</p><div class=\"owner-service-list\"><label class=\"owner-service-option\"><input type=\"checkbox\" data-owner-service=\"kitchen\"><span>Kitchen</span></label><label class=\"owner-service-option\"><input type=\"checkbox\" data-owner-service=\"bathroom\"><span>Bath</span></label></div></div>\n        <div class=\"owner-panel-section\"><h4>Pricing logic settings</h4><p class=\"owner-editor-note\">Set the rules used to build the homeowner quote.</p><div class=\"owner-form-grid\"><label class=\"owner-field\"><span>Estimate format</span><select data-owner-path=\"estimateFormat\"><option value=\"range\">Low\u2013high range</option><option value=\"fixed\">Fixed estimate</option><option value=\"starting\">Starting at</option></select></label><label class=\"owner-field range-adjustment-field\" data-range-adjustment-field><span>Range adjustment % <small class=\"owner-field-note\">Used only with Low\u2013high range</small></span><input type=\"number\" min=\"0\" max=\"100\" step=\"1\" data-owner-path=\"rangeAdjustment\" data-owner-scale=\"percent\"></label><label class=\"owner-field\"><span>Contingency %</span><input type=\"number\" min=\"0\" max=\"100\" step=\"1\" data-owner-path=\"contingency\" data-owner-scale=\"percent\"></label></div></div>\n        <div class=\"owner-panel-section\"><h4>Kitchen pricing matrix</h4><p class=\"owner-editor-note\">Set the kitchen prices used by each scope, size, material grade and selected add-on in the customer calculator. The prefilled values are suggested installed-price defaults and can be edited.</p><div class=\"owner-form-grid owner-kitchen-starting\"><label class=\"owner-field\"><span>Kitchen starting price</span><input type=\"number\" min=\"0\" step=\"100\" data-owner-path=\"serviceMinimums.kitchen\"></label></div><div id=\"kitchenPricingMatrix\"></div><div class=\"owner-pricing-row\"><strong>Full Gut automatic utilities</strong><p class=\"owner-editor-note\">Full Gut automatically adds Flooring Replacement, Full Painting, and Kitchen Sink Replacement. Enter one combined price for water, electrical and gas line renewal based on Kitchen size.</p><div id=\"kitchenFullGutUtilitiesPricingMatrix\"></div></div></div>\n        <div class=\"owner-panel-section\"><h4>Bath pricing matrix</h4><p class=\"owner-editor-note\">Set the Bath prices used by each scope, size, material grade and selected add-on in the customer calculator. The prefilled values are suggested installed-price defaults and can be edited.</p><div class=\"owner-form-grid owner-kitchen-starting\"><label class=\"owner-field\"><span>Bath starting price</span><input type=\"number\" min=\"0\" step=\"100\" data-owner-path=\"serviceMinimums.bathroom\"></label></div><div id=\"bathroomPricingMatrix\"></div><div class=\"owner-pricing-row\"><strong>Full Gut automatic utilities</strong><p class=\"owner-editor-note\">Full Gut automatically adds Flooring Replacement and Full Painting. Enter one combined price for water, electrical and gas line renewal based on Bathroom size.</p><div id=\"bathroomFullGutUtilitiesPricingMatrix\"></div></div></div>\n        <button class=\"owner-save-btn\" id=\"ownerSaveButton\" type=\"button\">Save pricing settings</button><p class=\"owner-save-note\" id=\"ownerSaveNote\">Changes apply immediately to the next customer quote in this preview.</p>\n        <button class=\"next-btn owner-dashboard-action\" data-open-estimate>Open customer calculator \u2192</button>\n      </div>\n    </section>\n\n    <section class=\"auth-modal hidden\" id=\"authModal\" aria-label=\"Create Lifki account\">\n      <div class=\"auth-card\">\n        <div class=\"head-row\"><div class=\"mini-brand\"><i></i> Lifki account</div><button class=\"close-widget\" id=\"closeAuth\" aria-label=\"Close sign up\">\u00d7</button></div>\n        <h2 id=\"authTitle\">Create your Lifki account.</h2><p id=\"authSubhead\">Start with a front-end account now. Database and billing connections can be added later.</p>\n        <form class=\"auth-form\" id=\"signupForm\"><label>Email<input name=\"email\" type=\"email\" autocomplete=\"email\" required placeholder=\"you@company.com\"></label><label>Password<input name=\"password\" type=\"password\" autocomplete=\"new-password\" minlength=\"6\" required placeholder=\"At least 6 characters\"></label><p class=\"auth-error\" id=\"signupError\"></p><div class=\"auth-actions\"><button class=\"auth-cancel\" type=\"button\" id=\"cancelAuth\">Cancel</button><button class=\"primary-btn\" id=\"authSubmit\" type=\"submit\">Create account \u2192</button></div></form><button class=\"auth-mode-toggle\" id=\"authModeToggle\" type=\"button\">Already have an account? Sign in</button>\n      </div>\n    </section>\n\n    <section class=\"app-shell hidden\" id=\"appShell\" aria-label=\"Lifki remodeler workspace\">\n      <aside class=\"app-sidebar\"><div class=\"app-brand\"><div class=\"app-brand-mark\">L</div>Lifki</div><div class=\"app-sidebar-label\">Workspace</div><nav class=\"app-nav\"><button type=\"button\" class=\"active\" data-app-view=\"dashboard\">Dashboard</button><button type=\"button\" data-app-view=\"leads\">Lead Tracking System</button><button type=\"button\" data-app-view=\"pricing\">Pricing settings</button><button type=\"button\" data-app-view=\"cost-preview\">Cost preview</button></nav><div class=\"app-sidebar-foot\">Kitchen &amp; Bath tools<br>for American remodelers</div></aside>\n      <div class=\"app-main\" id=\"appMain\" role=\"main\"></div>\n      <section class=\"auth-modal hidden\" id=\"followupModal\" aria-label=\"Follow-up outcome\">\n        <div class=\"auth-card\"><div class=\"head-row\"><div class=\"mini-brand\"><i></i> Lead follow-up</div><button class=\"close-widget\" id=\"closeFollowup\" aria-label=\"Close follow-up outcome\">\u00d7</button></div><h2>What happened?</h2><p>Choose the next outcome for this lead.</p><div class=\"followup-options\"><button type=\"button\" data-followup-outcome=\"Won\">Won</button><button type=\"button\" data-followup-outcome=\"Lost\">Lost</button><button type=\"button\" data-followup-outcome=\"Follow-up needed\">Another follow-up needed</button></div><button class=\"auth-cancel\" type=\"button\" id=\"cancelFollowup\">Cancel</button></div>\n      </section>\n    </section>\n";
    shadow.innerHTML = "<style>" + styleText + "</style><div id=\"lifkiWidgetMount\">" + markup + "</div>";
    var root = shadow.querySelector("#lifkiWidgetMount");
    if (!root) return;
    root.style.pointerEvents = "auto";
    var launcher = root.querySelector("#estimateLauncher");
    if (launcher) launcher.style.zIndex = "999999";
    var panel = root.querySelector("#estimateWidget");
    if (panel) panel.style.zIndex = "999999";
    var scopedDocument = {
      body: root,
      getElementById: function (id) { return root.querySelector("#" + id); },
      querySelector: function (selector) { return root.querySelector(selector); },
      querySelectorAll: function (selector) { return root.querySelectorAll(selector); }
    };
    (function (window, document, root) {

    /*
      OWNER CONFIGURATION
      Pricing is deterministic and configuration-driven. The calculator does not require an
      LLM: selections map to explicit pricing rules and automatic add-ons.
      This is the source of truth for the demo calculator. In production, load it from
      the owner's Company / Pricing settings instead of hard-coding it in the browser.
    */
    const OWNER_CONFIG = {
      companyName: 'Your Remodeling Company',
      activeServices: { kitchen: true, bathroom: true },
      serviceAreaLabel: 'Service area checked by ZIP code',
      minimumProjectPrice: 0,
      serviceMinimums: { kitchen: 1000, bathroom: 3400 },
      fullGutUtilities: { kitchen: { small: 3000, medium: 4000, large: 5500 }, bathroom: { small: 1800, medium: 2600, large: 3800 } },
      kitchenBathPricingVersion: 7,
      kitchenPricing: {
        baseline: { small: { 'cosmetic-refresh': 800, 'hybrid-refresh': 2000, 'full-gut': 4800 }, medium: { 'cosmetic-refresh': 1400, 'hybrid-refresh': 3400, 'full-gut': 8800 }, large: { 'cosmetic-refresh': 2000, 'hybrid-refresh': 4800, 'full-gut': 12800 } },
        cabinetMaterialMultipliers: { standard: 1, 'semi-custom': 1.5, custom: 2.8 },
        materialGradeMultipliers: { standard: 1, 'semi-custom': 1.5, custom: 2.8 },
        cabinets: { refinish: { small: 1000, medium: 1800, large: 2600 }, 'change-doors-drawers': { small: 1800, medium: 3000, large: 4500 }, replace: { premade: { small: 1600, medium: 2400, large: 3200 }, 'semi-custom': { small: 3200, medium: 4800, large: 6400 }, custom: { small: 6000, medium: 8800, large: 12000 } } },
        countertops: { base: { small: 800, medium: 1400, large: 2000 }, 'remove-replace': { small: 800, medium: 1400, large: 2000 }, 'restore-polish': { small: 500, medium: 800, large: 1200 }, backsplash: { small: 200, medium: 500, large: 700 } },
        flooring: { base: { small: 500, medium: 900, large: 1300 }, overlay: { small: 400, medium: 800, large: 1200 }, repair: { superficial: { small: 400, medium: 400, large: 400 }, localized: { small: 600, medium: 800, large: 1000 }, subfloor: { small: 1200, medium: 1800, large: 2600 } } },
        windows: { resizePerWindow: 900, movePerWindow: 1200, replace: { 'glass-only': 650, retrofit: 950, 'full-frame': 1400 }, replacePerWindow: 650, addResizeMovePerWindow: 1200 },
        sink: { replace: 750 },
        wall: { 'non-load-bearing': 1400, 'load-bearing': 3800 },
        painting: { 'walls-ceiling': { small: 400, medium: 600, large: 900 }, 'trim-doors': { small: 500, medium: 800, large: 1200 }, full: { small: 600, medium: 1100, large: 1600 } },
        majorAddOns: { 'center-island-utilities': 1800, 'move-water': 1800, 'move-electricity': 600, 'upgrade-main-panel-200a': 1400, 'move-gas-appliances': 800 }
      },
      bathroomPricing: {
        baseline: { small: { 'cosmetic-refresh': 600, 'hybrid-refresh': 1400, 'full-gut': 3000 }, medium: { 'cosmetic-refresh': 1000, 'hybrid-refresh': 2400, 'full-gut': 5600 }, large: { 'cosmetic-refresh': 1600, 'hybrid-refresh': 4200, 'full-gut': 9600 } },
        cabinetMaterialMultipliers: { standard: 1, 'semi-custom': 1.6, custom: 2.5 },
        materialGradeMultipliers: { standard: 1, 'semi-custom': 1.6, custom: 2.5 },
        vanity: { refinish: { small: 300, medium: 500, large: 700 }, 'change-doors-drawers': { small: 600, medium: 900, large: 1300 }, replace: { premade: { small: 400, medium: 600, large: 900 }, 'semi-custom': { small: 1000, medium: 1600, large: 2200 }, custom: { small: 2000, medium: 3200, large: 4400 } } },
        countertops: { base: { small: 300, medium: 600, large: 800 }, 'remove-replace': { small: 300, medium: 600, large: 800 }, 'restore-polish': { small: 200, medium: 400, large: 600 }, backsplash: 100 },
        flooring: { base: { small: 400, medium: 700, large: 1100 }, overlay: { small: 400, medium: 700, large: 1000 }, repair: { superficial: { small: 400, medium: 400, large: 400 }, localized: { small: 500, medium: 700, large: 900 }, subfloor: { small: 1000, medium: 1500, large: 2200 } } },
        windows: { resizePerWindow: 800, movePerWindow: 1100, replace: { 'glass-only': 600, retrofit: 900, 'full-frame': 1300 }, replacePerWindow: 600, addResizeMovePerWindow: 1100 },
        sink: { replace: 700, move: 1200 },
        painting: { 'walls-ceiling': { small: 200, medium: 400, large: 600 }, 'trim-doors': { small: 300, medium: 500, large: 700 }, full: { small: 400, medium: 700, large: 1000 } },
        shower: { 'tub-to-shower': 1400, 'acrylic-insert': 800, 'custom-tiled-shower': 1800, 'frameless-glass': 700, 'tiled-niche': 200 },
        wall: { 'non-load-bearing': 1400, 'load-bearing': 3800 },
        waterMove: { sink: { 'same-wall': 700, 'new-wall': 1100 }, toilet: { 'short-nudge': 800, 'across-room': 1500 }, shower: { 'move-drain': 900, 'move-full-valve-drain': 1800 } },
        majorAddOns: { 'move-toilet-sink-shower': 1000, 'exhaust-fan': 300, 'move-electricity': 400 }
      },
      estimateFormat: 'range', // 'fixed' | 'range' | 'starting'
      rangeAdjustment: 0.15,
      contingency: 0.05,
      locationAdjustment: 0,
      pricingMethod: 'installed', // 'installed' | 'cost-plus'
      markupPercent: 0.25,
      included: ['Standard installation', 'Basic cleanup', 'Normal site conditions'],
      excluded: ['Appliances unless contractor supplied', 'Hidden damage', 'Permit fees unless configured'],
    };
    const OWNER_STORAGE_KEY = 'lifkiOwnerConfig';
    function mergeOwnerConfig(target, source) {
      Object.keys(source || {}).forEach(key => {
        if (!(key in target)) return;
        if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key]) && target[key] && typeof target[key] === 'object') mergeOwnerConfig(target[key], source[key]);
        else target[key] = source[key];
      });
    }
    let savedOwnerConfig = null;
    try {
      savedOwnerConfig = JSON.parse(localStorage.getItem(OWNER_STORAGE_KEY) || 'null');
      if (savedOwnerConfig) {
      [['kitchenPricing', 'flooring'], ['bathroomPricing', 'flooring']].forEach(([serviceKey, flooringKey]) => {
        const repair = savedOwnerConfig[serviceKey]?.[flooringKey]?.repair;
        if (repair && typeof repair.small === 'number') savedOwnerConfig[serviceKey][flooringKey].repair = { superficial: repair };
      });
      mergeOwnerConfig(OWNER_CONFIG, savedOwnerConfig);
    }
    } catch (error) { /* Storage is optional in preview mode. */ }
    function migrateCountertopPricing() {
      ['kitchen', 'bathroom'].forEach(service => {
        const savedCountertops = savedOwnerConfig?.[`${service}Pricing`]?.countertops;
        const currentCountertops = OWNER_CONFIG[`${service}Pricing`].countertops;
        if (!savedCountertops?.['remove-replace'] && savedCountertops?.base) currentCountertops['remove-replace'] = { ...currentCountertops.base };
      });
    }
    migrateCountertopPricing();
    function migrateWindowPricing() {
      ['kitchen', 'bathroom'].forEach(service => {
        const savedWindows = savedOwnerConfig?.[`${service}Pricing`]?.windows;
        const currentWindows = OWNER_CONFIG[`${service}Pricing`].windows;
        if (!savedWindows) return;
        if (!savedWindows.resizePerWindow && savedWindows.addResizeMovePerWindow) currentWindows.resizePerWindow = savedWindows.addResizeMovePerWindow;
        if (!savedWindows.movePerWindow && savedWindows.addResizeMovePerWindow) currentWindows.movePerWindow = savedWindows.addResizeMovePerWindow;
        if (!savedWindows.replace && savedWindows.replacePerWindow) currentWindows.replace['glass-only'] = savedWindows.replacePerWindow;
      });
    }
    function reducePricingNumbers(target, source) {
      Object.keys(source || {}).forEach(key => {
        if (typeof source[key] === 'number' && typeof target[key] === 'number') target[key] = Math.round((source[key] * .4) / 100) * 100;
        else if (source[key] && typeof source[key] === 'object' && target[key] && typeof target[key] === 'object') reducePricingNumbers(target[key], source[key]);
      });
    }
    if (savedOwnerConfig && Number(savedOwnerConfig.kitchenBathPricingVersion || 0) < 1) {
      ['kitchen', 'bathroom'].forEach(service => {
        if (typeof savedOwnerConfig.serviceMinimums?.[service] === 'number') OWNER_CONFIG.serviceMinimums[service] = Math.round((savedOwnerConfig.serviceMinimums[service] * .4) / 100) * 100;
      });
      ['baseline', 'cabinets', 'countertops', 'flooring', 'wall', 'painting', 'majorAddOns', 'windows', 'sink'].forEach(group => {
        reducePricingNumbers(OWNER_CONFIG.kitchenPricing[group], savedOwnerConfig.kitchenPricing?.[group]);
        reducePricingNumbers(OWNER_CONFIG.bathroomPricing[group], savedOwnerConfig.bathroomPricing?.[group]);
      });
      OWNER_CONFIG.kitchenBathPricingVersion = 1;
      try { localStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(OWNER_CONFIG)); } catch (error) {}
    }
    migrateWindowPricing();

    function applySuggestedZeroPricing() {
      const fill = (object, key, value) => { if (object && Number(object[key]) === 0) object[key] = value; };
      if (Number(savedOwnerConfig?.kitchenBathPricingVersion || 0) < 6) {
        OWNER_CONFIG.rangeAdjustment = 0.15;
        OWNER_CONFIG.contingency = 0.05;
      }
      if (Number(savedOwnerConfig?.kitchenBathPricingVersion || 0) < 7) {
        fill(OWNER_CONFIG.kitchenPricing.cabinets['change-doors-drawers'], 'small', 1800);
        fill(OWNER_CONFIG.kitchenPricing.cabinets['change-doors-drawers'], 'medium', 3000);
        fill(OWNER_CONFIG.kitchenPricing.cabinets['change-doors-drawers'], 'large', 4500);
      }
      if (Number(savedOwnerConfig?.kitchenBathPricingVersion || 0) < 3) OWNER_CONFIG.serviceMinimums.kitchen = 1000;
      fill(OWNER_CONFIG.serviceMinimums, 'kitchen', 1000);
      [['kitchen', { small: 3000, medium: 4000, large: 5500 }], ['bathroom', { small: 1800, medium: 2600, large: 3800 }]].forEach(([service, values]) => {
        Object.keys(values).forEach(size => fill(OWNER_CONFIG.fullGutUtilities[service], size, values[size]));
      });
      const kitchen = OWNER_CONFIG.kitchenPricing;
      [['localized', { small: 600, medium: 800, large: 1000 }], ['subfloor', { small: 1200, medium: 1800, large: 2600 }]].forEach(([kind, values]) => Object.keys(values).forEach(size => fill(kitchen.flooring.repair[kind], size, values[size])));
      fill(kitchen.windows, 'resizePerWindow', 900); fill(kitchen.windows, 'movePerWindow', 1200); fill(kitchen.windows.replace, 'glass-only', 650); fill(kitchen.windows.replace, 'retrofit', 950); fill(kitchen.windows.replace, 'full-frame', 1400);
      fill(kitchen.sink, 'replace', 750); fill(kitchen.majorAddOns, 'move-water', 1800);
      Object.entries({ small: 500, medium: 800, large: 1200 }).forEach(([size, value]) => fill(kitchen.painting['trim-doors'], size, value));
      const bathroom = OWNER_CONFIG.bathroomPricing;
      [['localized', { small: 500, medium: 700, large: 900 }], ['subfloor', { small: 1000, medium: 1500, large: 2200 }]].forEach(([kind, values]) => Object.keys(values).forEach(size => fill(bathroom.flooring.repair[kind], size, values[size])));
      fill(bathroom.windows, 'resizePerWindow', 800); fill(bathroom.windows, 'movePerWindow', 1100); fill(bathroom.windows.replace, 'glass-only', 600); fill(bathroom.windows.replace, 'retrofit', 900); fill(bathroom.windows.replace, 'full-frame', 1300);
      fill(bathroom.sink, 'replace', 700); fill(bathroom.sink, 'move', 1200);
      fill(bathroom.waterMove.sink, 'same-wall', 700); fill(bathroom.waterMove.sink, 'new-wall', 1100);
      fill(bathroom.waterMove.toilet, 'short-nudge', 800); fill(bathroom.waterMove.toilet, 'across-room', 1500);
      fill(bathroom.waterMove.shower, 'move-drain', 900); fill(bathroom.waterMove.shower, 'move-full-valve-drain', 1800);
      Object.entries({ small: 300, medium: 500, large: 700 }).forEach(([size, value]) => fill(bathroom.painting['trim-doors'], size, value));
      OWNER_CONFIG.kitchenBathPricingVersion = 7;
    }
    applySuggestedZeroPricing();
    try { localStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(OWNER_CONFIG)); } catch (error) {}

    const ICONS = {
      kitchen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V6.5A1.5 1.5 0 0 1 5.5 5h13A1.5 1.5 0 0 1 20 6.5V19"/><path d="M3 19h18M7 9h2M15 9h2M6 13h12v6H6z"/></svg>',
      bathroom: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h16v3.5A3.5 3.5 0 0 1 16.5 19h-9A3.5 3.5 0 0 1 4 15.5zM6 12V6a2 2 0 0 1 4 0v1M4 20l1.5-1M20 20l-1.5-1"/></svg>',
      check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg>',
      warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.7 2.9 17a2 2 0 0 0 1.7 3h14.8a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>'
    };

    
    const widget = document.getElementById('estimateWidget');
    const ownerPreviewPanel = document.getElementById('ownerPreviewPanel');
    const authModal = document.getElementById('authModal');
    const followupModal = document.getElementById('followupModal');
    let followupLeadId = '';
    const appShell = document.getElementById('appShell');
    const appMain = document.getElementById('appMain');
    const launcher = document.getElementById('estimateLauncher');
    const body = document.getElementById('widgetBody');
    const foot = document.getElementById('widgetFoot');
    const nextButton = document.getElementById('nextButton');
    const backButton = document.getElementById('backButton');
    const progressBar = document.getElementById('progressBar');
    const widgetHeadline = document.getElementById('widgetHeadline');
    const widgetSubhead = document.getElementById('widgetSubhead');
    const FLOW = ['property', 'project', 'route', 'contact', 'quote'];
    let ownerPreviewInitialized = false;
    let ownerPreviewRequested = false;

    function activeFlow() {
      if (state.interiorProjects.includes('kitchen') || state.interiorProjects.includes('bathroom')) return ['property', 'project', 'route', ...(state.interiorProjects.includes('kitchen') ? ['kitchen-details'] : []), ...(state.interiorProjects.includes('kitchen') && state.interiorProjects.includes('bathroom') ? ['bathroom-scope'] : []), ...(state.interiorProjects.includes('bathroom') ? ['bathroom-details'] : []), 'contact', 'quote'];
      return FLOW;
    }
    function preQuoteSteps() { return activeFlow().length - 1; }

    function freshState() {
      return {
        step: 'property', project: '', interiorProjects: [], propertyType: '', zip: '',
        kitchenSize: '', kitchenMaterialGrade: '', kitchenScope: '', kitchenScopeTouches: [], kitchenCabinetAction: '', kitchenCabinetKeepType: '', kitchenCabinetReplaceType: '', kitchenPaintType: '', kitchenWallRemovalType: '', kitchenCountertopAction: '', kitchenHiddenDetails: [], kitchenMajorAddOns: [], kitchenFlooringAction: '', kitchenFlooringRepairType: '', kitchenWindowAction: '', kitchenWindowReplacementType: '', kitchenWindowCount: '', kitchenSinkAction: '',
        bathroomSize: '', bathroomMaterialGrade: '', bathroomScope: '', bathroomScopeTouches: [], bathroomWallRemovalType: '', bathroomCountertopAction: '', bathroomVanityAction: '', bathroomVanityKeepType: '', bathroomVanityReplaceType: '', bathroomSinkAction: '', bathroomWaterMoveDetails: [], bathroomWaterMoveSinkType: '', bathroomWaterMoveToiletType: '', bathroomWaterMoveShowerType: '', bathroomHiddenDetails: [], bathroomShowerBase: '', bathroomShowerDetails: [], bathroomPaintType: '', bathroomMajorAddOns: [], bathroomFlooringAction: '', bathroomFlooringRepairType: '', bathroomWindowAction: '', bathroomWindowReplacementType: '', bathroomWindowCount: '',
        kitchenScopeDetails: {}, bathroomScopeDetails: {}, firstName: '', phone: '', result: null, leadCreated: false
      };
    }
    let state = freshState();

    // Each scope owns its own detail form so switching scopes never carries selections across.
    const SCOPE_FIELDS = {
      kitchen: ['kitchenSize', 'kitchenMaterialGrade', 'kitchenScopeTouches', 'kitchenCountertopAction', 'kitchenCabinetAction', 'kitchenCabinetKeepType', 'kitchenCabinetReplaceType', 'kitchenPaintType', 'kitchenWallRemovalType', 'kitchenHiddenDetails', 'kitchenMajorAddOns', 'kitchenFlooringAction', 'kitchenFlooringRepairType', 'kitchenWindowAction', 'kitchenWindowReplacementType', 'kitchenWindowCount', 'kitchenSinkAction'],
      bathroom: ['bathroomSize', 'bathroomMaterialGrade', 'bathroomScopeTouches', 'bathroomWallRemovalType', 'bathroomCountertopAction', 'bathroomVanityAction', 'bathroomVanityKeepType', 'bathroomVanityReplaceType', 'bathroomSinkAction', 'bathroomWaterMoveDetails', 'bathroomWaterMoveSinkType', 'bathroomWaterMoveToiletType', 'bathroomWaterMoveShowerType', 'bathroomHiddenDetails', 'bathroomShowerBase', 'bathroomShowerDetails', 'bathroomPaintType', 'bathroomMajorAddOns', 'bathroomFlooringAction', 'bathroomFlooringRepairType', 'bathroomWindowAction', 'bathroomWindowReplacementType', 'bathroomWindowCount']
    };
    const SCOPE_ARRAY_FIELDS = new Set(['kitchenScopeTouches', 'kitchenHiddenDetails', 'kitchenMajorAddOns', 'bathroomScopeTouches', 'bathroomHiddenDetails', 'bathroomShowerDetails', 'bathroomWaterMoveDetails', 'bathroomMajorAddOns']);
    function copyScopeValue(value) { return Array.isArray(value) ? [...value] : value; }
    function saveScopeDetails(service, scope) {
      if (!scope) return;
      const mapKey = `${service}ScopeDetails`;
      state[mapKey][scope] = Object.fromEntries(SCOPE_FIELDS[service].map(field => [field, copyScopeValue(state[field])]));
    }
    function restoreScopeDetails(service, scope) {
      const saved = state[`${service}ScopeDetails`][scope];
      SCOPE_FIELDS[service].forEach(field => {
        state[field] = saved && Object.prototype.hasOwnProperty.call(saved, field) ? copyScopeValue(saved[field]) : SCOPE_ARRAY_FIELDS.has(field) ? [] : '';
      });
      return !!saved;
    }

    const projectNames = { kitchen: 'Kitchen', bathroom: 'Bathroom', kitchenbath: 'Kitchen + bath remodeling' };

    function ownerPreviewAccess() { return ownerPreviewRequested || new URLSearchParams(window.location.search).get('owner') === '1'; }
    function ownerPreviewActive() { return body.classList.contains('owner-preview-active'); }
    function toggleOwnerPreview() {
      if (!ownerPreviewAccess()) return;
      const active = body.classList.toggle('owner-preview-active');
      const panel = body.querySelector('.owner-only');
      const button = body.querySelector('#ownerPreviewToggle');
      if (panel) panel.open = active;
      if (button) button.textContent = active ? 'Hide remodeler calculation' : 'Show remodeler calculation';
    }
    
    function openWidget() {
      ownerPreviewRequested = false;
      ownerPreviewInitialized = false;
      body.classList.remove('owner-preview-active');
      ownerPreviewPanel.classList.add('hidden');
      launcher.classList.add('hidden'); widget.classList.remove('hidden'); render();
      setTimeout(() => body.querySelector('button, input, select, textarea')?.focus(), 80);
    }
    function kitchenMatrixInput(path, step = '50') { return `<input class="owner-table-input" type="number" min="0" step="${step}" data-owner-path="${path}">`; }
    function renderFullGutUtilitiesPricingMatrix(service = 'kitchen', targetId = 'kitchenFullGutUtilitiesPricingMatrix') {
      const matrix = document.getElementById(targetId);
      if (!matrix) return;
      const kitchen = service === 'kitchen';
      const sizes = kitchen ? [['small', 'Small<br><small>&lt; 200 sq ft</small>'], ['medium', 'Medium<br><small>200–300 sq ft</small>'], ['large', 'Large<br><small>&gt; 300 sq ft</small>']] : [['small', 'Small<br><small>&lt; 50 sq ft</small>'], ['medium', 'Medium<br><small>50–100 sq ft</small>'], ['large', 'Large<br><small>&gt; 100 sq ft</small>']];
      const sizeHeader = sizes.map(([, label]) => `<th scope="col">${label}</th>`).join('');
      const sizeInputs = prefix => sizes.map(([key]) => `<td>${kitchenMatrixInput(`${prefix}.${key}`)}</td>`).join('');
      const roomLabel = kitchen ? 'Kitchen · bundled water + electrical + gas renewal' : 'Bathroom · bundled water + electrical + gas renewal';
      matrix.innerHTML = `<div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Room</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">${roomLabel}</th>${sizeInputs(`fullGutUtilities.${service}`)}</tr></tbody></table></div>`;
    }

    function renderKitchenPricingMatrix(targetId = 'kitchenPricingMatrix') {
      const matrix = document.getElementById(targetId);
      if (!matrix) return;
      const sizes = [['small', 'Small<br><small>&lt; 200 sq ft</small>'], ['medium', 'Medium<br><small>200–300 sq ft</small>'], ['large', 'Large<br><small>&gt; 300 sq ft</small>']];
      const scopes = [['cosmetic-refresh', 'Cosmetic / Pull and Replace'], ['hybrid-refresh', 'Hybrid Refresh'], ['full-gut', 'Full Gut Remodel']];
      const sizeHeader = sizes.map(([, label]) => `<th scope="col">${label}</th>`).join('');
      const sizeInputs = prefix => sizes.map(([key]) => `<td>${kitchenMatrixInput(`${prefix}.${key}`)}</td>`).join('');
      matrix.innerHTML = `<div class="kitchen-pricing-group"><h5>1. Baseline &amp; site prep</h5><p>Basic labor, site protection and waste hauling. Prices are based on kitchen size and Step 1 scope.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Scope</th>${sizeHeader}</tr></thead><tbody>${scopes.map(([scope, label]) => `<tr><th scope="row">${label}</th>${sizes.map(([size]) => `<td>${kitchenMatrixInput(`kitchenPricing.baseline.${size}.${scope}`)}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div><div class="kitchen-pricing-group"><h5>2A. Cabinet replacement multiplier</h5><p>Applied to cabinet replacement, refinishing/painting, and refacing prices.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table compact"><thead><tr><th scope="col">Material grade</th><th scope="col">Multiplier</th></tr></thead><tbody><tr><th scope="row">Standard</th><td>${kitchenMatrixInput('kitchenPricing.cabinetMaterialMultipliers.standard', '0.1')}</td></tr><tr><th scope="row">Semi-Custom</th><td>${kitchenMatrixInput('kitchenPricing.cabinetMaterialMultipliers.semi-custom', '0.1')}</td></tr><tr><th scope="row">Custom</th><td>${kitchenMatrixInput('kitchenPricing.cabinetMaterialMultipliers.custom', '0.1')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>2B. Other material grade multiplier</h5><p>Applied to countertops and flooring. Backsplash, painting, wall removal and add-ons remain flat fees.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table compact"><thead><tr><th scope="col">Material grade</th><th scope="col">Multiplier</th></tr></thead><tbody><tr><th scope="row">Builder</th><td>${kitchenMatrixInput('kitchenPricing.materialGradeMultipliers.standard', '0.1')}</td></tr><tr><th scope="row">Mid-Range</th><td>${kitchenMatrixInput('kitchenPricing.materialGradeMultipliers.semi-custom', '0.1')}</td></tr><tr><th scope="row">Luxury</th><td>${kitchenMatrixInput('kitchenPricing.materialGradeMultipliers.custom', '0.1')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>3. Cabinets</h5><p>Refinishing/Painting and refacing use the cabinet multiplier. Replacement prices use the cabinet multiplier.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Cabinet selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Keep · Refinishing/Painting</th>${sizeInputs('kitchenPricing.cabinets.refinish')}</tr><tr><th scope="row">Keep · Refacing</th>${sizeInputs('kitchenPricing.cabinets.change-doors-drawers')}</tr>${['premade','semi-custom','custom'].map(type => `<tr><th scope="row">Replace · ${pretty(type)}</th>${sizeInputs(`kitchenPricing.cabinets.replace.${type}`)}</tr>`).join('')}</tbody></table></div></div><div class="kitchen-pricing-group"><h5>4. Countertops &amp; backsplash</h5><p>Choose Remove &amp; Replace or Restore &amp; Polish. Countertop actions use the material multiplier; matching backsplash is optional.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Remove &amp; Replace</th>${sizeInputs('kitchenPricing.countertops.remove-replace')}</tr><tr><th scope="row">Restore &amp; Polish</th>${sizeInputs('kitchenPricing.countertops.restore-polish')}</tr><tr><th scope="row">Optional matching backsplash add-on</th>${sizeInputs('kitchenPricing.countertops.backsplash')}</tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>5. Flooring</h5><p>Full Gut automatically includes Flooring Replacement. Replacement includes demolition and disposal; overlay include disposal only. Repair uses the material grade multiplier.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Replacement base cost</th>${sizeInputs('kitchenPricing.flooring.base')}</tr><tr><th scope="row">Overlay installation</th>${sizeInputs('kitchenPricing.flooring.overlay')}</tr><tr><th scope="row">Superficial repair · Grout / Refinish</th>${sizeInputs('kitchenPricing.flooring.repair.superficial')}</tr><tr><th scope="row">Localized repair · Cracked / Missing Tiles</th>${sizeInputs('kitchenPricing.flooring.repair.localized')}</tr><tr><th scope="row">Subfloor repair · Required due to Water Damage</th>${sizeInputs('kitchenPricing.flooring.repair.subfloor')}</tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>6. Remove a wall</h5><p>Load-bearing includes temporary shoring and structural LVL beam installation.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table compact"><thead><tr><th scope="col">Wall type</th><th scope="col">Flat fee</th></tr></thead><tbody><tr><th scope="row">Non-load-bearing</th><td>${kitchenMatrixInput('kitchenPricing.wall.non-load-bearing')}</td></tr><tr><th scope="row">Load-bearing</th><td>${kitchenMatrixInput('kitchenPricing.wall.load-bearing')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>7. Painting</h5><p>Full Gut automatically includes Full Painting. Choose Walls &amp; Ceiling, Trim &amp; Doors, or Full for non-Full-Gut scopes.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Painting selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Walls &amp; ceiling</th>${sizeInputs('kitchenPricing.painting.walls-ceiling')}</tr><tr><th scope="row">Trim &amp; Doors</th>${sizeInputs('kitchenPricing.painting.trim-doors')}</tr><tr><th scope="row">Full painting</th>${sizeInputs('kitchenPricing.painting.full')}</tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>8. Windows</h5><p>Set pricing per window for Resize, Move, and each replacement option.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Window action</th><th scope="col">Price per window</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Resize</th><td>${kitchenMatrixInput('kitchenPricing.windows.resizePerWindow')}</td><td>Resize the opening</td></tr><tr><th scope="row">Move</th><td>${kitchenMatrixInput('kitchenPricing.windows.movePerWindow')}</td><td>Relocate the window opening</td></tr><tr><th scope="row">Replace · Glass-Only</th><td>${kitchenMatrixInput('kitchenPricing.windows.replace.glass-only')}</td><td>Glass replacement only</td></tr><tr><th scope="row">Replace · Retrofit</th><td>${kitchenMatrixInput('kitchenPricing.windows.replace.retrofit')}</td><td>Replacement within the existing frame</td></tr><tr><th scope="row">Replace · Full-Frame</th><td>${kitchenMatrixInput('kitchenPricing.windows.replace.full-frame')}</td><td>Full-frame replacement</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>9. Sink</h5><p>Set the price for sink replacement. Water line moves are priced under Major add-ons.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Sink action</th><th scope="col">Price</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Replace</th><td>${kitchenMatrixInput('kitchenPricing.sink.replace')}</td><td>Cosmetic, selected replacement, or Full Gut automatic replacement</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>10. Major add-ons</h5><p>Sink / Dishwasher Move is priced here as a water supply and drain relocation add-on.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Add-on</th><th scope="col">Flat fee</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Center island with utilities</th><td>${kitchenMatrixInput('kitchenPricing.majorAddOns.center-island-utilities')}</td><td>Plumbing extension + floor trenching</td></tr><tr><th scope="row">Moving electricity</th><td>${kitchenMatrixInput('kitchenPricing.majorAddOns.move-electricity')}</td><td>Rewiring + fishing lines through studs</td></tr><tr><th scope="row">Upgrade main panel to 200 amps</th><td>${kitchenMatrixInput('kitchenPricing.majorAddOns.upgrade-main-panel-200a')}</td><td>Smart / high-draw appliance capacity</td></tr><tr><th scope="row">Moving gas appliances</th><td>${kitchenMatrixInput('kitchenPricing.majorAddOns.move-gas-appliances')}</td><td>Licensed plumber extension + pressure test</td></tr><tr><th scope="row">Sink / Dishwasher Move</th><td>${kitchenMatrixInput('kitchenPricing.majorAddOns.move-water')}</td><td>Sink and dishwasher water supply and drain relocation</td></tr></tbody></table></div></div>`;
    }

    function renderBathroomPricingMatrix(targetId = 'bathroomPricingMatrix') {
      const matrix = document.getElementById(targetId);
      if (!matrix) return;
      const sizes = [['small', 'Small<br><small>&lt; 50 sq ft</small>'], ['medium', 'Medium<br><small>50–100 sq ft</small>'], ['large', 'Large<br><small>&gt; 100 sq ft</small>']];
      const scopes = [['cosmetic-refresh', 'Cosmetic / Pull and Replace'], ['hybrid-refresh', 'Hybrid Refresh'], ['full-gut', 'Full Gut Remodel']];
      const sizeHeader = sizes.map(([, label]) => `<th scope="col">${label}</th>`).join('');
      const sizeInputs = prefix => sizes.map(([key]) => `<td>${kitchenMatrixInput(`${prefix}.${key}`)}</td>`).join('');
      matrix.innerHTML = `<div class="kitchen-pricing-group"><h5>1. Baseline &amp; site prep</h5><p>Basic labor, surface protection and bathroom debris hauling.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Scope</th>${sizeHeader}</tr></thead><tbody>${scopes.map(([scope, label]) => `<tr><th scope="row">${label}</th>${sizes.map(([size]) => `<td>${kitchenMatrixInput(`bathroomPricing.baseline.${size}.${scope}`)}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div><div class="kitchen-pricing-group"><h5>2A. Vanity replacement multiplier</h5><p>Applied to vanity replacement, refinishing/painting, and refacing prices.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table compact"><thead><tr><th scope="col">Material grade</th><th scope="col">Multiplier</th></tr></thead><tbody><tr><th scope="row">Standard</th><td>${kitchenMatrixInput('bathroomPricing.cabinetMaterialMultipliers.standard', '0.1')}</td></tr><tr><th scope="row">Semi-Custom</th><td>${kitchenMatrixInput('bathroomPricing.cabinetMaterialMultipliers.semi-custom', '0.1')}</td></tr><tr><th scope="row">Custom</th><td>${kitchenMatrixInput('bathroomPricing.cabinetMaterialMultipliers.custom', '0.1')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>2B. Other material grade multiplier</h5><p>Applied to countertops, flooring and Custom Tiled Shower + Waterproofing. Other shower options, painting, backsplash and add-ons remain flat fees.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table compact"><thead><tr><th scope="col">Material grade</th><th scope="col">Multiplier</th></tr></thead><tbody><tr><th scope="row">Builder</th><td>${kitchenMatrixInput('bathroomPricing.materialGradeMultipliers.standard', '0.1')}</td></tr><tr><th scope="row">Mid-Range</th><td>${kitchenMatrixInput('bathroomPricing.materialGradeMultipliers.semi-custom', '0.1')}</td></tr><tr><th scope="row">Luxury</th><td>${kitchenMatrixInput('bathroomPricing.materialGradeMultipliers.custom', '0.1')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>3. Vanity &amp; cabinets</h5><p>Refinishing and door/drawer changes use the vanity multiplier. Replacement prices use the vanity multiplier.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Keep · Refinishing/Painting</th>${sizeInputs('bathroomPricing.vanity.refinish')}</tr><tr><th scope="row">Keep · Refacing</th>${sizeInputs('bathroomPricing.vanity.change-doors-drawers')}</tr>${['premade','semi-custom','custom'].map(type => `<tr><th scope="row">Replace · ${pretty(type)}</th>${sizeInputs(`bathroomPricing.vanity.replace.${type}`)}</tr>`).join('')}</tbody></table></div></div><div class="kitchen-pricing-group"><h5>4. Countertops &amp; backsplash</h5><p>Choose Remove &amp; Replace or Restore &amp; Polish. Countertop actions use the material multiplier; matching backsplash is an optional flat fee.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Remove &amp; Replace</th>${sizeInputs('bathroomPricing.countertops.remove-replace')}</tr><tr><th scope="row">Restore &amp; Polish</th>${sizeInputs('bathroomPricing.countertops.restore-polish')}</tr><tr><th scope="row">Optional matching backsplash add-on</th><td colspan="3">${kitchenMatrixInput('bathroomPricing.countertops.backsplash')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>5. Flooring</h5><p>Full Gut automatically includes Flooring Replacement. Replacement includes demolition and disposal; overlay include disposal only. Repair uses the material grade multiplier.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Replacement base cost</th>${sizeInputs('bathroomPricing.flooring.base')}</tr><tr><th scope="row">Overlay installation</th>${sizeInputs('bathroomPricing.flooring.overlay')}</tr><tr><th scope="row">Superficial repair · Grout / Refinish</th>${sizeInputs('bathroomPricing.flooring.repair.superficial')}</tr><tr><th scope="row">Localized repair · Cracked / Missing Tiles</th>${sizeInputs('bathroomPricing.flooring.repair.localized')}</tr><tr><th scope="row">Subfloor repair · Required due to Water Damage</th>${sizeInputs('bathroomPricing.flooring.repair.subfloor')}</tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>6. Remove a wall</h5><p>Load-bearing includes temporary shoring and structural LVL beam installation.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table compact"><thead><tr><th scope="col">Wall type</th><th scope="col">Flat fee</th></tr></thead><tbody><tr><th scope="row">Non-load-bearing</th><td>${kitchenMatrixInput('bathroomPricing.wall.non-load-bearing')}</td></tr><tr><th scope="row">Load-bearing</th><td>${kitchenMatrixInput('bathroomPricing.wall.load-bearing')}</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>7. Painting</h5><p>Full Gut automatically includes Full Painting. Choose Walls &amp; Ceiling, Trim &amp; Doors, or Full for non-Full-Gut scopes.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table"><thead><tr><th scope="col">Painting selection</th>${sizeHeader}</tr></thead><tbody><tr><th scope="row">Walls &amp; ceiling</th>${sizeInputs('bathroomPricing.painting.walls-ceiling')}</tr><tr><th scope="row">Trim &amp; Doors</th>${sizeInputs('bathroomPricing.painting.trim-doors')}</tr><tr><th scope="row">Full painting</th>${sizeInputs('bathroomPricing.painting.full')}</tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>8. Windows</h5><p>Set pricing per window for Resize, Move, and each replacement option.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Window action</th><th scope="col">Price per window</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Resize</th><td>${kitchenMatrixInput('bathroomPricing.windows.resizePerWindow')}</td><td>Resize the opening</td></tr><tr><th scope="row">Move</th><td>${kitchenMatrixInput('bathroomPricing.windows.movePerWindow')}</td><td>Relocate the window opening</td></tr><tr><th scope="row">Replace · Glass-Only</th><td>${kitchenMatrixInput('bathroomPricing.windows.replace.glass-only')}</td><td>Glass replacement only</td></tr><tr><th scope="row">Replace · Retrofit</th><td>${kitchenMatrixInput('bathroomPricing.windows.replace.retrofit')}</td><td>Replacement within the existing frame</td></tr><tr><th scope="row">Replace · Full-Frame</th><td>${kitchenMatrixInput('bathroomPricing.windows.replace.full-frame')}</td><td>Full-frame replacement</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>9. Sink</h5><p>Set the price for sink replacement and move.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Sink action</th><th scope="col">Price</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Replace</th><td>${kitchenMatrixInput('bathroomPricing.sink.replace')}</td><td>Selected sink replacement</td></tr><tr><th scope="row">Move</th><td>${kitchenMatrixInput('bathroomPricing.sink.move')}</td><td>Sink supply and drain relocation</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>10. Shower / tub area</h5><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Selection</th><th scope="col">Flat fee</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Tub-to-shower conversion</th><td>${kitchenMatrixInput('bathroomPricing.shower.tub-to-shower')}</td><td>Demo + drain conversion labor</td></tr><tr><th scope="row">Standard acrylic tub/shower insert</th><td>${kitchenMatrixInput('bathroomPricing.shower.acrylic-insert')}</td><td>Material + installation</td></tr><tr><th scope="row">Custom tiled shower + waterproofing</th><td>${kitchenMatrixInput('bathroomPricing.shower.custom-tiled-shower')}</td><td>Multiplied by material grade</td></tr><tr><th scope="row">Frameless glass enclosure</th><td>${kitchenMatrixInput('bathroomPricing.shower.frameless-glass')}</td><td>Installation</td></tr><tr><th scope="row">Built-in tiled niche</th><td>${kitchenMatrixInput('bathroomPricing.shower.tiled-niche')}</td><td>Per niche</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>11. Water moves</h5><p>Water Move is available for Hybrid Refresh and Full Gut. Price each selected fixture move by its selected detail.</p><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Water move detail</th><th scope="col">Flat fee</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Move Sink · Same Wall</th><td>${kitchenMatrixInput('bathroomPricing.waterMove.sink.same-wall')}</td><td>Sink relocation on the same wall</td></tr><tr><th scope="row">Move Sink · New Wall</th><td>${kitchenMatrixInput('bathroomPricing.waterMove.sink.new-wall')}</td><td>Sink relocation to a new wall</td></tr><tr><th scope="row">Move Toilet · Short Nudge</th><td>${kitchenMatrixInput('bathroomPricing.waterMove.toilet.short-nudge')}</td><td>Short toilet relocation</td></tr><tr><th scope="row">Move Toilet · Across Room</th><td>${kitchenMatrixInput('bathroomPricing.waterMove.toilet.across-room')}</td><td>Toilet relocation across the room</td></tr><tr><th scope="row">Move Shower · Valve Only</th><td>${kitchenMatrixInput('bathroomPricing.waterMove.shower.move-drain')}</td><td>Drain relocation</td></tr><tr><th scope="row">Move Shower · Full</th><td>${kitchenMatrixInput('bathroomPricing.waterMove.shower.move-full-valve-drain')}</td><td>Valve and drain relocation</td></tr></tbody></table></div></div><div class="kitchen-pricing-group"><h5>12. Major add-ons</h5><div class="owner-pricing-table-wrap"><table class="owner-pricing-table add-on-table"><thead><tr><th scope="col">Add-on</th><th scope="col">Flat fee</th><th scope="col">Pricing note</th></tr></thead><tbody><tr><th scope="row">Exhaust fan</th><td>${kitchenMatrixInput('bathroomPricing.majorAddOns.exhaust-fan')}</td><td>Vent directly outside</td></tr><tr><th scope="row">Move electricity</th><td>${kitchenMatrixInput('bathroomPricing.majorAddOns.move-electricity')}</td><td>Dedicated runs</td></tr></tbody></table></div></div>`;
    }
    function ownerPathValue(path) { return path.split('.').reduce((value, key) => value?.[key], OWNER_CONFIG); }
    function setOwnerPathValue(path, value) {
      const keys = path.split('.');
      const last = keys.pop();
      const target = keys.reduce((value, key) => value[key], OWNER_CONFIG);
      target[last] = value;
    }
    function syncPricingEditor(root) {
      root.querySelectorAll('[data-owner-path]').forEach(input => {
        const value = ownerPathValue(input.dataset.ownerPath);
        input.value = input.dataset.ownerScale === 'percent' ? Math.round(Number(value || 0) * 100) : value ?? '';
      });
      root.querySelectorAll('[data-range-adjustment-field]').forEach(field => {
        const active = OWNER_CONFIG.estimateFormat === 'range';
        field.classList.toggle('is-inactive', !active);
        field.setAttribute('aria-disabled', String(!active));
        const input = field.querySelector('input');
        if (input) input.disabled = !active;
      });
      root.querySelectorAll('[data-owner-service]').forEach(input => { input.checked = !!OWNER_CONFIG.activeServices[input.dataset.ownerService]; });
    }
    function syncOwnerEditor() { syncPricingEditor(ownerPreviewPanel); }
    function updateOwnerField(input, noteRoot = ownerPreviewPanel) {
      let value = input.value;
      if (input.type === 'number') value = Number(value || 0);
      if (input.dataset.ownerScale === 'percent') value = value / 100;
      setOwnerPathValue(input.dataset.ownerPath, value);
      const note = noteRoot.querySelector('#ownerSaveNote, #appSaveNote');
      if (note) note.textContent = noteRoot === appMain ? 'Example preview updated. No quote or lead was saved.' : 'Saved in this preview. Changes apply immediately to the next customer quote.';
    }
    function bindOwnerEditor() {
      ownerPreviewPanel.addEventListener('input', event => {
        if (event.target.matches('[data-owner-path]')) updateOwnerField(event.target);
      });
      ownerPreviewPanel.addEventListener('change', event => {
        if (event.target.matches('[data-owner-path]')) { updateOwnerField(event.target); syncOwnerEditor(); }
        if (event.target.matches('[data-owner-service]')) {
          const selected = [...ownerPreviewPanel.querySelectorAll('[data-owner-service]')].filter(service => service.checked);
          if (!selected.length) { event.target.checked = true; return; }
          OWNER_CONFIG.activeServices[event.target.dataset.ownerService] = event.target.checked;
          const note = ownerPreviewPanel.querySelector('#ownerSaveNote');
          if (note) note.textContent = 'Saved in this preview. Only selected services appear in the customer calculator.';
        }
      });
    }
    function renderOwnerPricingSettings() { renderFullGutUtilitiesPricingMatrix('kitchen', 'kitchenFullGutUtilitiesPricingMatrix'); renderFullGutUtilitiesPricingMatrix('bathroom', 'bathroomFullGutUtilitiesPricingMatrix'); renderKitchenPricingMatrix(); renderBathroomPricingMatrix(); syncOwnerEditor(); }
    function saveOwnerConfig(noteRoot = ownerPreviewPanel, message = 'Pricing settings saved for this browser and applied to the customer calculator.', noteSelector = '#ownerSaveNote, #appSaveNote') {
      try {
        localStorage.setItem(OWNER_STORAGE_KEY, JSON.stringify(OWNER_CONFIG));
        const note = noteRoot.querySelector(noteSelector);
        if (note) note.textContent = message;
      } catch (error) {
        const note = noteRoot.querySelector(noteSelector);
        if (note) note.textContent = 'Preview changes are active for this session.';
      }
    }
    function openOwnerPreview() {
      ownerPreviewRequested = true;
      renderOwnerPricingSettings();
      syncOwnerDashboardMetrics();
      widget.classList.add('hidden');
      ownerPreviewPanel.classList.remove('hidden');
      launcher.classList.add('hidden');
      setTimeout(() => ownerPreviewPanel.querySelector('button')?.focus(), 80);
    }
    function closeWidget() { widget.classList.add('hidden'); ownerPreviewPanel.classList.add('hidden'); launcher.classList.remove('hidden'); }
    document.querySelectorAll('[data-open-estimate]').forEach(btn => btn.addEventListener('click', openWidget));
    document.querySelectorAll('[data-open-owner-preview]').forEach(btn => btn.addEventListener('click', openOwnerPreview));
    launcher.addEventListener('click', openWidget);
    document.getElementById('closeWidget').addEventListener('click', closeWidget);
    document.getElementById('closeOwnerPreview').addEventListener('click', closeWidget);
    document.getElementById('ownerSaveButton').addEventListener('click', saveOwnerConfig);
    document.getElementById('showAllQuotesButton').addEventListener('click', event => {
      const button = event.currentTarget;
      const expanded = button.dataset.expanded !== 'true';
      ownerPreviewPanel.querySelectorAll('.owner-extra-quote').forEach(row => row.classList.toggle('hidden', !expanded));
      button.dataset.expanded = String(expanded);
      button.textContent = expanded ? 'Hide quotes' : 'Show all quotes';
    });
    document.querySelectorAll('[data-open-signup]').forEach(button => button.addEventListener('click', openSignup));
    document.querySelectorAll('[data-open-signin]').forEach(button => button.addEventListener('click', openSignin));
    document.getElementById('authModeToggle').addEventListener('click', () => setAuthMode(authMode === 'signup' ? 'signin' : 'signup'));
    document.getElementById('closeAuth').addEventListener('click', closeSignup);
    document.getElementById('cancelAuth').addEventListener('click', closeSignup);
    document.getElementById('signupForm').addEventListener('submit', handleSignup);
    document.getElementById('closeFollowup').addEventListener('click', closeFollowupOutcome);
    document.getElementById('cancelFollowup').addEventListener('click', closeFollowupOutcome);
    followupModal.querySelectorAll('[data-followup-outcome]').forEach(button => button.addEventListener('click', () => applyFollowupOutcome(button.dataset.followupOutcome)));
    bindOwnerEditor();
    bindAppPricingEditor();
    function money(value) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Math.round(value || 0)); }
    function esc(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }
    function pretty(value) { return String(value || '').replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()); }
    function cabinetKeepLabel(value) { return ({ refinish: 'Refinishing/Painting', 'change-doors-drawers': 'Refacing' })[value] || pretty(value); }
    function paintingLabel(value) { return ({ 'walls-ceiling': 'Walls & Ceiling', 'trim-doors': 'Trim & Doors', full: 'Full' })[value] || pretty(value); }
    function countertopLabel(value) { return ({ 'remove-replace': 'Remove & Replace', 'restore-polish': 'Restore & Polish' })[value] || pretty(value); }
    function windowActionLabel(value) { return ({ resize: 'Resize', move: 'Move', replace: 'Replace' })[value] || pretty(value); }
    function windowReplacementLabel(value) { return ({ 'glass-only': 'Glass-Only', retrofit: 'Retrofit', 'full-frame': 'Full-Frame' })[value] || pretty(value); }
    function windowSelectionLabel(action, replacement) { return action === 'replace' ? `${windowActionLabel(action)} · ${windowReplacementLabel(replacement || 'retrofit')}` : windowActionLabel(action); }
    function otherMaterialGradeLabel(value) { return ({ standard: 'Builder', 'semi-custom': 'Mid-Range', custom: 'Luxury' })[value] || pretty(value); }
    const APP_ACCOUNT_KEY = 'lifkiAccount';
    let sessionAccount = null;
    let sessionAccountPassword = '';
    let authMode = 'signup';
    let appView = 'dashboard';
    let pricingPreviewScenario = { service: 'kitchen', scope: 'hybrid-refresh', size: 'medium', grade: 'semi-custom' };
    let selectedLeadId = 'lead-001';
    const DEMO_LEADS = [
      { id: 'lead-001', name: 'Sarah Johnson', project: 'Kitchen + Bath remodel', status: 'New lead', range: '$42k–$51k', zip: '90210', created: '2 minutes ago', createdAt: Date.now() - 2 * 60 * 1000, phone: '(555) 018-2011', basedOn: ['Services: Kitchen and Bathroom'], notes: 'Based on: Kitchen + Bath remodeling · Kitchen and Bathroom services selected.' },
      { id: 'lead-002', name: 'Michael Chen', project: 'Kitchen · Full Gut', status: 'Follow-up needed', range: '$26k–$31k', zip: '90211', created: '2 days ago', createdAt: Date.now() - 2 * 24 * 60 * 60 * 1000, phone: '(555) 018-2044', basedOn: ['Kitchen scope: Full Gut · Cabinets, Countertops', 'Kitchen actions: Cabinets replaced — Semi-Custom; Countertops — Remove & Replace; Matching backsplash; Flooring — Replacement; Painting — Full; Sink — Replace (automatic); Utilities — Water, electrical and gas line renewal (automatic)'], notes: 'Based on: Kitchen · Full Gut Remodel · Cabinets · Countertops · Matching backsplash.' },
      { id: 'lead-003', name: 'Alicia Brown', project: 'Bath · Cosmetic / Pull and Replace', status: 'Quote viewed', range: '$14k–$19k', zip: '90212', created: '7 days ago', createdAt: Date.now() - 7 * 24 * 60 * 60 * 1000, phone: '(555) 018-2078', basedOn: ['Bathroom scope: Cosmetic / Pull and Replace · Vanity & Cabinets, Countertops, Shower / Tub Area', 'Bathroom actions: Vanity replaced — Premade; Countertops — Remove & Replace; Tile work; Exhaust Fan'], notes: 'Based on: Bathroom · Cosmetic / Pull and Replace · Vanity & Cabinets · Countertops · Shower / Tub Area · Exhaust Fan.' },
      { id: 'lead-004', name: 'David Wilson', project: 'Kitchen · Hybrid Refresh', status: 'Quote sent', range: '$18k–$24k', zip: '90213', created: '16 days ago', createdAt: Date.now() - 16 * 24 * 60 * 60 * 1000, phone: '(555) 018-2090', basedOn: ['Kitchen scope: Hybrid Refresh · Cabinets, Countertops, Painting', 'Kitchen actions: Cabinets replaced — Semi-Custom; Countertops — Remove & Replace; Matching backsplash; Painting — Full'], notes: 'Based on: Kitchen · Hybrid Refresh · Cabinets · Countertops · Matching backsplash · Painting.' },
      { id: 'lead-005', name: 'Emma Davis', project: 'Bath · Full Gut Remodel', status: 'Quote viewed', range: '$28k–$36k', zip: '90214', created: '38 days ago', createdAt: Date.now() - 38 * 24 * 60 * 60 * 1000, phone: '(555) 018-2122', basedOn: ['Bathroom scope: Full Gut Remodel · Shower / Tub Area, Vanity & Cabinets, Wall removal', 'Bathroom actions: Shower conversion; Vanity replaced — Premade; Wall removal; Flooring — Replacement; Painting — Full; Sink — Replace (automatic); Utilities — Water, electrical and gas line renewal (automatic)'], notes: 'Based on: Bathroom · Full Gut Remodel · Shower / Tub Area · Vanity & Cabinets · Wall removal.' },
      { id: 'lead-006', name: 'James Miller', project: 'Kitchen · Cosmetic / Pull and Replace', status: 'New lead', range: '$9k–$13k', zip: '90215', created: '50 days ago', createdAt: Date.now() - 50 * 24 * 60 * 60 * 1000, phone: '(555) 018-2165', basedOn: ['Kitchen scope: Cosmetic / Pull and Replace · Cabinets, Countertops, Painting', 'Kitchen actions: Cabinets kept — Refinishing/Painting; Countertops — Remove & Replace; Matching backsplash; Painting — Walls & Ceiling'], notes: 'Based on: Kitchen · Cosmetic / Pull and Replace · Cabinets kept · Countertops · Matching backsplash · Painting.' }
    ];
    function currentAccount() { if (sessionAccount) return sessionAccount; try { return JSON.parse(localStorage.getItem(APP_ACCOUNT_KEY) || 'null'); } catch (error) { return null; } }
    function syncAuthMode() {
      const signIn = authMode === 'signin';
      document.getElementById('authTitle').textContent = signIn ? 'Welcome back to Lifki.' : 'Create your Lifki account.';
      document.getElementById('authSubhead').textContent = signIn ? 'Sign in to continue to your remodeler workspace.' : 'Start with a front-end account now. Database and billing connections can be added later.';
      document.getElementById('authSubmit').textContent = signIn ? 'Sign in →' : 'Create account →';
      document.getElementById('authModeToggle').textContent = signIn ? 'Need an account? Create one' : 'Already have an account? Sign in';
    }
    function setAuthMode(mode) {
      if (mode === authMode) return;
      const card = authModal.querySelector('.auth-card');
      card.classList.add('auth-transitioning');
      setTimeout(() => {
        authMode = mode;
        syncAuthMode();
        document.getElementById('signupError').classList.remove('show');
        card.classList.remove('auth-transitioning');
        authModal.querySelector('input')?.focus();
      }, 170);
    }
    function openAuth(mode) {
      authMode = mode;
      syncAuthMode();
      authModal.classList.remove('hidden');
      setTimeout(() => authModal.querySelector('input')?.focus(), 80);
    }
    function openSignup() { openAuth('signup'); }
    function openSignin() { openAuth('signin'); }
    function closeSignup() { authModal.classList.add('hidden'); }
    function openFollowupOutcome(leadId) {
      followupLeadId = leadId;
      if (followupModal.parentElement !== document.body) document.body.appendChild(followupModal);
      followupModal.classList.remove('hidden');
    }
    function closeFollowupOutcome() {
      followupLeadId = '';
      followupModal.classList.add('hidden');
      if (followupModal.parentElement === document.body) appShell.appendChild(followupModal);
    }
    function applyFollowupOutcome(status) { const lead = leadById(followupLeadId); if (!lead) return; lead.status = status; persistLeadState(); selectedLeadId = lead.id; closeFollowupOutcome(); renderAppView('leads', { resetScroll: false }); }
    function signOut() { sessionAccount = null; sessionAccountPassword = ''; appShell.classList.add('hidden'); launcher.classList.remove('hidden'); closeSignup(); }
    const LEADS_STORAGE_KEY = 'lifkiLeadState';
    const LEADS_DATA_STORAGE_KEY = 'lifkiLeads';
    DEMO_LEADS.forEach(lead => { lead.isDemo = true; });
    try {
      const savedLeads = JSON.parse(localStorage.getItem(LEADS_DATA_STORAGE_KEY) || '[]');
      if (Array.isArray(savedLeads)) DEMO_LEADS.push(...savedLeads.map(({ email, ...lead }) => ({ ...lead, isDemo: false })));
    } catch (error) {}
    try {
      const savedLeadState = JSON.parse(localStorage.getItem(LEADS_STORAGE_KEY) || '{}');
      DEMO_LEADS.forEach(lead => { if (savedLeadState[lead.id]) Object.assign(lead, savedLeadState[lead.id]); });
    } catch (error) {}
    const LEAD_STATUSES = ['Follow-up needed', 'Won', 'Lost'];
    DEMO_LEADS.forEach(lead => {
      if (!Number.isFinite(Number(lead.createdAt))) lead.createdAt = Date.now();
      if (!LEAD_STATUSES.includes(lead.status)) lead.status = 'Follow-up needed';
    });
    function persistLeadState() {
      try {
        localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(Object.fromEntries(DEMO_LEADS.map(lead => [lead.id, { status: lead.status, notes: lead.notes }]))));
        localStorage.setItem(LEADS_DATA_STORAGE_KEY, JSON.stringify(DEMO_LEADS.filter(lead => !lead.isDemo)));
      } catch (error) {}
    }
    function leadQuoteValue(lead) {
      if (Number.isFinite(Number(lead.quoteLow)) && Number.isFinite(Number(lead.quoteHigh))) return (Number(lead.quoteLow) + Number(lead.quoteHigh)) / 2;
      const values = (String(lead.range || '').match(/\$?\s*[\d,.]+\s*[km]?/gi) || []).map(token => {
        const normalized = token.toLowerCase().replace(/[\$,\s]/g, '');
        const multiplier = normalized.endsWith('m') ? 1000000 : normalized.endsWith('k') ? 1000 : 1;
        return Number.parseFloat(normalized.replace(/[km]$/, '')) * multiplier;
      }).filter(value => Number.isFinite(value) && value > 0);
      return values.length > 1 ? values.reduce((sum, value) => sum + value, 0) / values.length : values[0] || 0;
    }
    const leadMetricWindows = { day: 1, week: 7, month: 30 };
    let leadMetricWindow = 'month';
    function compactMoney(value) { return value >= 1000000 ? `$${(value / 1000000).toFixed(1).replace('.0', '')}m` : `$${Math.round(value / 1000)}k`; }
    function leadWithinDays(lead, days, now = Date.now()) { return now - Number(lead.createdAt || 0) <= days * 24 * 60 * 60 * 1000; }
    function quoteTrendLabel(currentValue, previousValue) {
      if (!previousValue) return currentValue ? 'New activity vs previous 30 days' : 'No quote activity in the last 60 days';
      const change = Math.round(((currentValue - previousValue) / previousValue) * 100);
      return `${change >= 0 ? '+' : ''}${change}% vs previous 30 days`;
    }
    function dashboardMetrics(windowKey = leadMetricWindow) {
      const now = Date.now();
      const currentStart = now - 30 * 24 * 60 * 60 * 1000;
      const previousStart = now - 60 * 24 * 60 * 60 * 1000;
      const currentQuoteValue = DEMO_LEADS.filter(lead => Number(lead.createdAt) >= currentStart && Number(lead.createdAt) <= now).reduce((sum, lead) => sum + leadQuoteValue(lead), 0);
      const previousQuoteValue = DEMO_LEADS.filter(lead => Number(lead.createdAt) >= previousStart && Number(lead.createdAt) < currentStart).reduce((sum, lead) => sum + leadQuoteValue(lead), 0);
      const requestDays = leadMetricWindows[windowKey] || leadMetricWindows.month;
      const requestLeads = DEMO_LEADS.filter(lead => leadWithinDays(lead, requestDays, now));
      const totalLeads = DEMO_LEADS.length;
      const leadsWithQuotes = DEMO_LEADS.filter(lead => leadQuoteValue(lead) > 0).length;
      const followupCount = DEMO_LEADS.filter(lead => lead.status === 'Follow-up needed').length;
      const requestFollowupCount = requestLeads.filter(lead => lead.status === 'Follow-up needed').length;
      return { quoteValue: compactMoney(currentQuoteValue), quoteValueTrend: quoteTrendLabel(currentQuoteValue, previousQuoteValue), totalLeads, leadsWithQuotes, followupCount, requestCount: requestLeads.length, requestFollowupCount, requestWindowLabel: windowKey === 'day' ? 'last day' : windowKey === 'week' ? 'last week' : 'last month', quoteToLeadRate: totalLeads ? Math.round((leadsWithQuotes / totalLeads) * 100) : 0 };
    }
    function syncOwnerDashboardMetrics() {
      const metrics = dashboardMetrics();
      const quoteValue = document.getElementById('ownerQuoteValueMetric');
      const quoteValueMeta = document.getElementById('ownerQuoteValueMeta');
      const quoteRequests = document.getElementById('ownerQuoteRequestsMetric');
      const quoteRequestsMeta = document.getElementById('ownerQuoteRequestsMeta');
      const quoteLeadRate = document.getElementById('ownerQuoteLeadRateMetric');
      const quoteLeadRateMeta = document.getElementById('ownerQuoteLeadRateMeta');
      if (quoteValue) quoteValue.textContent = metrics.quoteValue;
      if (quoteValueMeta) quoteValueMeta.textContent = metrics.quoteValueTrend;
      if (quoteRequests) quoteRequests.textContent = metrics.requestCount;
      if (quoteRequestsMeta) quoteRequestsMeta.textContent = `${metrics.requestFollowupCount} ready for follow-up · ${metrics.requestWindowLabel}`;
      if (quoteLeadRate) quoteLeadRate.textContent = `${metrics.quoteToLeadRate}%`;
      if (quoteLeadRateMeta) quoteLeadRateMeta.textContent = `${metrics.leadsWithQuotes} of ${metrics.totalLeads} leads have a quote`;
    }
    function leadProjectLabel() {
      if (state.project === 'kitchenbath') return 'Kitchen + Bath remodeling';
      return projectNames[state.project] || pretty(state.project || 'Remodeling project');
    }
    function addCalculatorLead(result) {
      const lead = { id: `lead-live-${Date.now()}`, name: state.firstName.trim(), project: leadProjectLabel(), status: 'Follow-up needed', range: result.display, quoteLow: result.low, quoteHigh: result.high, zip: state.zip, created: 'Just now', createdAt: Date.now(), phone: state.phone, notes: formatLeadBasedOn(result.basedOn), basedOn: result.basedOn, isDemo: false };
      DEMO_LEADS.unshift(lead);
      persistLeadState();
      syncOwnerDashboardMetrics();
      return lead;
    }
    function relativeLeadTime(lead) {
      const createdAt = Number(lead.createdAt);
      if (!Number.isFinite(createdAt)) return lead.created || 'Just now';
      const elapsedMinutes = Math.floor(Math.max(0, Date.now() - createdAt) / 60000);
      if (elapsedMinutes < 1) return 'Just now';
      if (elapsedMinutes < 60) return `${elapsedMinutes} minute${elapsedMinutes === 1 ? '' : 's'} ago`;
      const elapsedHours = Math.floor(elapsedMinutes / 60);
      if (elapsedHours < 24) return `${elapsedHours} hour${elapsedHours === 1 ? '' : 's'} ago`;
      const elapsedDays = Math.floor(elapsedHours / 24);
      return `${elapsedDays} day${elapsedDays === 1 ? '' : 's'} ago`;
    }
    function refreshLeadCreatedTimes() {
      document.querySelectorAll('[data-relative-created]').forEach(element => {
        const lead = leadById(element.dataset.relativeCreated);
        if (lead) element.textContent = relativeLeadTime(lead);
      });
    }
    function leadById(id) { return DEMO_LEADS.find(lead => lead.id === id) || DEMO_LEADS[0]; }
    function appLeadRow(lead, compact = false) { return `<div class="app-lead-row"><button type="button" data-lead-id="${lead.id}"><strong>${esc(lead.name)}</strong><small>${esc(lead.project)} · ${esc(lead.status)} · <span data-relative-created="${esc(lead.id)}">${esc(relativeLeadTime(lead))}</span></small></button><span class="app-lead-value">${esc(lead.range)}</span></div>`; }
    function formatLeadBasedOn(details) { return `Based on: ${(details || []).filter(Boolean).join(' · ')}`; }
    function leadExplanationEntries(lead) {
      const details = Array.isArray(lead.basedOn) && lead.basedOn.length ? lead.basedOn : String(lead.notes || '').replace(/^Based on:\s*/, '').split(' · ').filter(Boolean);
      return lead.isDemo ? [`Project: ${lead.project}`, `ZIP: ${lead.zip}`, ...details] : details;
    }
    function leadExplanationHtml(lead) {
      const entries = leadExplanationEntries(lead);
      return `<div class="lead-explanation"><div class="lead-explanation-title">Based on</div><ul class="lead-explanation-list">${entries.map(entry => `<li>${esc(entry)}</li>`).join('')}</ul></div>`;
    }
    function appLeadDetail(lead) {
      return `<div class="app-card lead-detail-card"><h3>${esc(lead.name)}</h3><p>${esc(lead.project)} · ${esc(lead.status)}</p><div class="lead-detail-grid"><div class="lead-detail-item"><span>Phone</span><strong>${esc(lead.phone)}</strong></div><div class="lead-detail-item"><span>ZIP</span><strong>${esc(lead.zip)}</strong></div><div class="lead-detail-item"><span>Quote range</span><strong>${esc(lead.range)}</strong></div><div class="lead-detail-item"><span>Created</span><strong data-relative-created="${esc(lead.id)}">${esc(relativeLeadTime(lead))}</strong></div><div class="lead-detail-item"><span>Status</span><strong>${esc(lead.status)}</strong></div></div>${leadExplanationHtml(lead)}<p class="lead-status-help">Choose whether this follow-up is Won, Lost, or needs another follow-up.</p><div class="app-page-actions"><button class="app-primary-btn" type="button" data-mark-followup data-lead-id="${lead.id}">Update follow-up outcome</button></div></div>`;
    }
    function renderAppView(view = appView, options = {}) {
      const resetScroll = options.resetScroll !== false;
      const previousAppShellScrollTop = appShell.scrollTop;
      const previousAppMainScrollTop = appMain.scrollTop;
      appView = view;
      const savedAccount = currentAccount() || {};
      const account = { firstName: savedAccount.firstName || 'Remodeler', companyName: savedAccount.companyName || 'Your company', email: savedAccount.email || '' };
      appShell.classList.remove('hidden');
      appShell.querySelectorAll('[data-app-view]').forEach(button => button.classList.toggle('active', button.dataset.appView === appView));
      const selectedAppNavButton = appShell.querySelector(`.app-sidebar [data-app-view="${appView}"]`);
      if (selectedAppNavButton && window.innerWidth <= 560) selectedAppNavButton.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
      const selectedLead = leadById(selectedLeadId);
      const metrics = dashboardMetrics();
      if (view === 'dashboard') {
        appMain.innerHTML = `<div class="app-topline"><small>${esc(account.companyName)} · Lifki workspace</small><button class="app-signout" type="button" data-app-signout>Sign out</button></div><div class="app-page-head"><div class="eyebrow">Lead Tracking System</div><h1>Good morning, ${esc(account.firstName)}.</h1><p>Track every homeowner conversation, quote range and follow-up from one remodeler workspace.</p></div><div class="app-metric-grid"><div class="app-metric-card"><span>Quote value created</span><strong>${metrics.quoteValue}</strong><small>${metrics.quoteValueTrend}</small></div><div class="app-metric-card app-filter-metric"><div class="app-metric-label-row"><span>New quote requests</span><select id="leadRequestWindow" aria-label="New quote request period"><option value="day" ${leadMetricWindow === 'day' ? 'selected' : ''}>Last day</option><option value="week" ${leadMetricWindow === 'week' ? 'selected' : ''}>Last week</option><option value="month" ${leadMetricWindow === 'month' ? 'selected' : ''}>Last month</option></select></div><strong>${metrics.requestCount}</strong><small>${metrics.requestFollowupCount} ready for follow-up</small></div></div><div class="app-content-grid"><div class="app-card"><h3>Recent leads</h3><p>Open a lead to see contact details, quote range and notes.</p><div class="app-lead-list">${DEMO_LEADS.slice(0, 4).map(lead => appLeadRow(lead, true)).join('')}</div><div class="app-page-actions"><button class="app-secondary-btn" type="button" data-app-view="leads">View all leads →</button></div></div><div class="app-card"><h3>Pricing settings</h3><p>Edit what homeowners see and how Kitchen and Bath quotes are calculated.</p><div class="summary-row"><span>Monthly plan</span><strong>$19 / month</strong></div><div class="summary-row"><span>Kitchen matrix</span><strong>Editable</strong></div><div class="summary-row"><span>Bath matrix</span><strong>Editable</strong></div><div class="app-page-actions"><button class="app-primary-btn" type="button" data-app-view="pricing">Open pricing settings →</button><button class="app-secondary-btn" type="button" data-app-view="cost-preview">Try cost preview →</button></div></div></div>`;
      } else if (view === 'leads') {
        appMain.innerHTML = `<div class="app-topline"><small>${esc(account.companyName)} · Lifki workspace</small><button class="app-signout" type="button" data-app-signout>Sign out</button></div><div class="app-page-head"><div class="eyebrow">Lead Tracking System</div><h1>Leads and details.</h1><p>See every lead created through the calculator and open the full details when it is time to follow up.</p></div><div class="app-table-wrap"><table class="app-table"><thead><tr><th>Lead</th><th>Project</th><th>Status</th><th>Quote range</th><th>Created</th><th></th></tr></thead><tbody>${DEMO_LEADS.map(lead => `<tr><td><button type="button" class="app-lead-name" data-lead-id="${lead.id}"><strong>${esc(lead.name)}</strong></button></td><td>${esc(lead.project)}</td><td>${esc(lead.status)}</td><td>${esc(lead.range)}</td><td><span data-relative-created="${esc(lead.id)}">${esc(relativeLeadTime(lead))}</span></td><td><button type="button" data-lead-id="${lead.id}">View details</button></td></tr>`).join('')}</tbody></table></div>${appLeadDetail(selectedLead)}`;
      } else if (view === 'pricing') {
        appMain.innerHTML = `<div class="app-topline"><small>${esc(account.companyName)} · Lifki workspace</small><button class="app-signout" type="button" data-app-signout>Sign out</button></div><div class="app-page-head"><div class="eyebrow">Separate settings page</div><h1>Pricing settings.</h1><p>Edit the Kitchen and Bath pricing rules, then open Cost preview in the workspace to test a representative scenario. Preview results are examples only and are never saved as leads or quotes.</p></div><div class="app-settings-block"><h2>General quote rules</h2><p>These controls shape how the calculator presents the result.</p><div class="owner-form-grid"><label class="owner-field"><span>Estimate format</span><select data-owner-path="estimateFormat"><option value="range">Low–high range</option><option value="fixed">Fixed estimate</option><option value="starting">Starting at</option></select></label><label class="owner-field range-adjustment-field" data-range-adjustment-field><span>Range adjustment % <small class="owner-field-note">Used only with Low–high range</small></span><input type="number" min="0" max="100" step="1" data-owner-path="rangeAdjustment" data-owner-scale="percent"></label><label class="owner-field"><span>Contingency %</span><input type="number" min="0" max="100" step="1" data-owner-path="contingency" data-owner-scale="percent"></label></div></div><div class="app-settings-block"><h2>Kitchen pricing</h2><p>Kitchen starting price and the complete Kitchen pricing matrix.</p><div class="owner-form-grid"><label class="owner-field"><span>Kitchen starting price</span><input type="number" min="0" step="100" data-owner-path="serviceMinimums.kitchen"></label></div><div class="app-pricing-matrix" id="appKitchenPricingMatrix"></div><div class="owner-pricing-row"><strong>Full Gut automatic utilities</strong><p class="owner-editor-note">Full Gut automatically adds Flooring Replacement, Full Painting, and Kitchen Sink Replacement. Enter one combined price for water, electrical and gas line renewal based on Kitchen size.</p><div class="app-pricing-matrix" id="appKitchenFullGutUtilitiesPricingMatrix"></div><div class="app-page-actions"><button class="app-primary-btn" type="button" id="appSaveKitchenPricing">Save Kitchen pricing</button><span class="owner-save-note" id="appKitchenSaveNote">Kitchen pricing changes are ready to save.</span></div></div></div><div class="app-settings-block"><h2>Bath pricing</h2><p>Bath starting price and the complete Bath pricing matrix.</p><div class="owner-form-grid"><label class="owner-field"><span>Bath starting price</span><input type="number" min="0" step="100" data-owner-path="serviceMinimums.bathroom"></label></div><div class="app-pricing-matrix" id="appBathroomPricingMatrix"></div><div class="owner-pricing-row"><strong>Full Gut automatic utilities</strong><p class="owner-editor-note">Full Gut automatically adds Flooring Replacement and Full Painting. Enter one combined price for water, electrical and gas line renewal based on Bathroom size.</p><div class="app-pricing-matrix" id="appBathroomFullGutUtilitiesPricingMatrix"></div><div class="app-page-actions"><button class="app-primary-btn" type="button" id="appSaveBathroomPricing">Save Bath pricing</button><span class="owner-save-note" id="appBathroomSaveNote">Bath pricing changes are ready to save.</span></div></div></div><div class="app-page-actions"><button class="app-primary-btn" type="button" id="appSavePricing">Save general pricing rules</button><span class="owner-save-note" id="appSaveNote">General quote rules are stored in this browser.</span></div>`;
        renderFullGutUtilitiesPricingMatrix('kitchen', 'appKitchenFullGutUtilitiesPricingMatrix');
        renderFullGutUtilitiesPricingMatrix('bathroom', 'appBathroomFullGutUtilitiesPricingMatrix');
        renderKitchenPricingMatrix('appKitchenPricingMatrix');
        renderBathroomPricingMatrix('appBathroomPricingMatrix');
        syncPricingEditor(appMain);
      } else if (view === 'cost-preview') {
        appMain.innerHTML = `<div class="app-topline"><small>${esc(account.companyName)} · Lifki workspace</small><button class="app-signout" type="button" data-app-signout>Sign out</button></div><div class="app-page-head"><div class="eyebrow">Workspace tool</div><h1>Cost preview.</h1><p>Try representative Kitchen and Bath scenarios using your current pricing settings. These examples update live and never create leads, quotes, or customer records.</p></div><div class="app-settings-block"><h2>Test a customer quote</h2><p>Change the scenario below to see how your saved pricing logic would present an estimate.</p><div class="pricing-preview-bubble account-pricing-preview"><div class="pricing-preview-head"><div><strong>Example cost preview</strong><small>Live from the pricing editor · not a saved quote</small></div></div><p class="pricing-preview-note">These examples are illustrative only. They do not create or save a lead, quote, or customer result.</p><div class="pricing-preview-cards" id="pricingPreviewCards"></div></div></div>`;
        renderPricingPreview(appMain);
      }
      if (resetScroll) {
        appShell.scrollTop = 0;
        appMain.scrollTop = 0;
      } else {
        appShell.scrollTop = previousAppShellScrollTop;
        appMain.scrollTop = previousAppMainScrollTop;
      }
      bindAppView();
    }
    function bindAppView() {
      appShell.querySelectorAll('[data-app-view]').forEach(button => { button.onclick = () => renderAppView(button.dataset.appView); });
      const leadRequestWindow = appMain.querySelector('#leadRequestWindow');
      if (leadRequestWindow) leadRequestWindow.onchange = event => { leadMetricWindow = event.target.value; renderAppView('dashboard', { resetScroll: false }); };
      appMain.querySelectorAll('button[data-lead-id]').forEach(button => { button.onclick = () => { selectedLeadId = button.dataset.leadId; renderAppView('leads', { resetScroll: false }); }; });
      appMain.querySelectorAll('[data-mark-followup]').forEach(button => { button.onclick = () => openFollowupOutcome(button.dataset.leadId); });
      appMain.querySelectorAll('[data-app-signout]').forEach(button => { button.onclick = signOut; });
      const saveButton = appMain.querySelector('#appSavePricing');
      if (saveButton) saveButton.onclick = () => saveOwnerConfig(appMain, 'General quote rules saved for this browser.', '#appSaveNote');
      const saveKitchenButton = appMain.querySelector('#appSaveKitchenPricing');
      if (saveKitchenButton) saveKitchenButton.onclick = () => saveOwnerConfig(appMain, 'Kitchen pricing saved for this browser and applied to Kitchen quotes.', '#appKitchenSaveNote');
      const saveBathroomButton = appMain.querySelector('#appSaveBathroomPricing');
      if (saveBathroomButton) saveBathroomButton.onclick = () => saveOwnerConfig(appMain, 'Bath pricing saved for this browser and applied to Bath quotes.', '#appBathroomSaveNote');
      
    }
    function showApp() { closeSignup(); widget.classList.add('hidden'); ownerPreviewPanel.classList.add('hidden'); launcher.classList.add('hidden'); renderAppView('dashboard'); }
    async function hashPassword(value) {
      if (!window.crypto?.subtle) return value;
      const bytes = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
      return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, '0')).join('');
    }
    async function handleSignup(event) {
      event.preventDefault();
      const form = event.currentTarget;
      const data = new FormData(form);
      const email = String(data.get('email') || '').trim();
      const password = String(data.get('password') || '');
      const error = document.getElementById('signupError');
      if (!email || !email.includes('@') || password.length < 6) { error.textContent = 'Enter a valid email and a password of at least 6 characters.'; error.classList.add('show'); return; }
      const passwordHash = await hashPassword(password);
      if (authMode === 'signin') {
        const savedAccount = currentAccount();
        if (!savedAccount || String(savedAccount.email || '').toLowerCase() !== email.toLowerCase()) { error.textContent = 'No account was found for that email in this preview.'; error.classList.add('show'); return; }
        if (savedAccount.passwordHash && savedAccount.passwordHash !== passwordHash) { error.textContent = 'That password does not match this preview account.'; error.classList.add('show'); return; }
        sessionAccount = savedAccount;
        sessionAccountPassword = password;
      } else {
        sessionAccount = { email, passwordHash };
        sessionAccountPassword = password;
        try { localStorage.setItem(APP_ACCOUNT_KEY, JSON.stringify(sessionAccount)); } catch (storageError) {}
      }
      form.reset();
      error.classList.remove('show');
      showApp();
    }
    function previewOwnerQuote(service, sample) {
      const previousState = state;
      const previewState = freshState();
      Object.assign(previewState, sample);
      state = previewState;
      try {
        const items = [];
        const rawBase = service === 'kitchen' ? calculateKitchenMatrix(items) : calculateBathroomMatrix(items);
        let base = rawBase;
        if (OWNER_CONFIG.locationAdjustment) base += rawBase * Number(OWNER_CONFIG.locationAdjustment);
        const costPlus = OWNER_CONFIG.pricingMethod === 'cost-plus' ? base * Number(OWNER_CONFIG.markupPercent) : 0;
        const minimum = Math.max(0, Number(OWNER_CONFIG.serviceMinimums[service] || 0));
        const preContingency = Math.max(base + costPlus, minimum);
        const contingency = preContingency * Number(OWNER_CONFIG.contingency || 0);
        const finalBase = Math.max(preContingency + contingency, minimum);
        const low = finalBase;
        const high = finalBase * (1 + Number(OWNER_CONFIG.rangeAdjustment || 0));
        const display = OWNER_CONFIG.estimateFormat === 'fixed' ? money(finalBase) : OWNER_CONFIG.estimateFormat === 'starting' ? `Starting at ${money(finalBase)}` : `${money(low)} – ${money(high)}`;
        return { display, items, rawBase, contingency, finalBase };
      } finally {
        state = previousState;
      }
    }
    function previewScenarioState(scenario) {
      const sample = freshState();
      const cabinetType = scenario.grade === 'standard' ? 'premade' : scenario.grade;
      sample.project = scenario.service;
      if (scenario.service === 'kitchen') {
        const fullGut = scenario.scope === 'full-gut';
        Object.assign(sample, { kitchenScope: scenario.scope, kitchenSize: scenario.size, kitchenMaterialGrade: scenario.grade, kitchenScopeTouches: fullGut ? ['cabinets', 'countertops', 'windows'] : scenario.scope === 'cosmetic-refresh' ? ['cabinets', 'countertops', 'windows'] : ['cabinets', 'countertops', 'flooring', 'painting', 'windows'], kitchenCabinetAction: 'replace', kitchenCabinetReplaceType: cabinetType, kitchenCountertopAction: 'remove-replace', kitchenFlooringAction: fullGut ? '' : 'replace', kitchenPaintType: fullGut ? '' : 'full', kitchenWindowAction: 'replace', kitchenWindowReplacementType: 'retrofit', kitchenWindowCount: 2 });
      } else {
        const fullGut = scenario.scope === 'full-gut';
        Object.assign(sample, { bathroomScope: scenario.scope, bathroomSize: scenario.size, bathroomMaterialGrade: scenario.grade, bathroomScopeTouches: fullGut ? ['vanity-cabinets', 'countertops', 'shower-tub', 'water-move'] : scenario.scope === 'cosmetic-refresh' ? ['vanity-cabinets', 'countertops', 'shower-tub'] : ['vanity-cabinets', 'countertops', 'flooring', 'painting', 'shower-tub', 'water-move'], bathroomVanityAction: 'replace', bathroomVanityReplaceType: cabinetType, bathroomCountertopAction: 'remove-replace', bathroomFlooringAction: fullGut ? '' : 'replace', bathroomPaintType: fullGut ? '' : 'full', bathroomShowerBase: scenario.scope === 'cosmetic-refresh' ? 'acrylic-insert' : 'tub-to-shower', bathroomShowerDetails: scenario.scope === 'cosmetic-refresh' ? [] : ['frameless-glass'], bathroomWaterMoveDetails: fullGut ? ['move-toilet'] : scenario.scope === 'hybrid-refresh' ? ['move-sink'] : [], bathroomWaterMoveSinkType: 'same-wall', bathroomWaterMoveToiletType: 'short-nudge' });
      }
      return sample;
    }
    function renderPricingPreview(root = appMain) {
      const host = root.querySelector('#pricingPreviewCards');
      if (!host) return;
      const scopeLabels = { 'cosmetic-refresh': 'Cosmetic / Pull and Replace', 'hybrid-refresh': 'Hybrid Refresh', 'full-gut': 'Full Gut Remodel' };
      const sizeLabels = { small: 'Small', medium: 'Medium', large: 'Large' };
      const gradeLabels = { standard: 'Builder', 'semi-custom': 'Mid-Range', custom: 'Luxury' };
      const serviceLabels = { kitchen: 'Kitchen', bathroom: 'Bath' };
      const quote = previewOwnerQuote(pricingPreviewScenario.service, previewScenarioState(pricingPreviewScenario));
      const sampleLabel = `${serviceLabels[pricingPreviewScenario.service]} · ${scopeLabels[pricingPreviewScenario.scope]} · ${sizeLabels[pricingPreviewScenario.size]} · ${gradeLabels[pricingPreviewScenario.grade]}`;
      host.innerHTML = `<div class="pricing-preview-controls"><label><span>Service</span><select data-pricing-preview="service"><option value="kitchen" ${pricingPreviewScenario.service === 'kitchen' ? 'selected' : ''}>Kitchen</option><option value="bathroom" ${pricingPreviewScenario.service === 'bathroom' ? 'selected' : ''}>Bath</option></select></label><label><span>Scope</span><select data-pricing-preview="scope"><option value="cosmetic-refresh" ${pricingPreviewScenario.scope === 'cosmetic-refresh' ? 'selected' : ''}>Cosmetic / Pull and Replace</option><option value="hybrid-refresh" ${pricingPreviewScenario.scope === 'hybrid-refresh' ? 'selected' : ''}>Hybrid Refresh</option><option value="full-gut" ${pricingPreviewScenario.scope === 'full-gut' ? 'selected' : ''}>Full Gut Remodel</option></select></label><label><span>Size</span><select data-pricing-preview="size"><option value="small" ${pricingPreviewScenario.size === 'small' ? 'selected' : ''}>Small</option><option value="medium" ${pricingPreviewScenario.size === 'medium' ? 'selected' : ''}>Medium</option><option value="large" ${pricingPreviewScenario.size === 'large' ? 'selected' : ''}>Large</option></select></label><label><span>Material grade</span><select data-pricing-preview="grade"><option value="standard" ${pricingPreviewScenario.grade === 'standard' ? 'selected' : ''}>Builder</option><option value="semi-custom" ${pricingPreviewScenario.grade === 'semi-custom' ? 'selected' : ''}>Mid-Range</option><option value="custom" ${pricingPreviewScenario.grade === 'custom' ? 'selected' : ''}>Luxury</option></select></label></div><div class="pricing-preview-total"><div><span>Example estimate</span><small>${esc(sampleLabel)}</small></div><strong>${esc(quote.display)}</strong></div><div class="pricing-preview-breakdown"><div class="pricing-preview-breakdown-head"><strong>Calculation preview</strong><small>Current editor values · not saved</small></div>${quote.items.map(item => `<div class="pricing-preview-line"><span>${esc(item.name)}<small>${esc(item.qty)} ${esc(item.unit)} · ${esc(item.source)}</small></span><strong>${money(item.value)}</strong></div>`).join('')}<div class="pricing-preview-line pricing-preview-subtotal"><span>Contingency and quote rules<small>Contingency: ${Math.round(Number(OWNER_CONFIG.contingency || 0) * 100)}% · minimums and format applied</small></span><strong>${money(quote.contingency)}</strong></div></div>`;
      host.querySelectorAll('[data-pricing-preview]').forEach(control => control.addEventListener('change', event => {
        const field = event.currentTarget.dataset.pricingPreview;
        pricingPreviewScenario[field] = event.currentTarget.value;
        if (field === 'service') pricingPreviewScenario.scope = 'hybrid-refresh';
        renderPricingPreview(root);
      }));
    }
    function bindAppPricingEditor() {
      appMain.addEventListener('input', event => { if (event.target.matches('[data-owner-path]')) { updateOwnerField(event.target, appMain); renderPricingPreview(appShell); } });
      appMain.addEventListener('change', event => { if (event.target.matches('[data-owner-path]')) { updateOwnerField(event.target, appMain); syncPricingEditor(appMain); renderPricingPreview(appShell); } });
    }
    function radio(group, value, text, current, stateKey = group, idSuffix = '') { const id = `${group}-${value}-${idSuffix}`.replace(/[^a-z0-9-]/gi, ''); return `<div class="radio-item"><input type="radio" id="${id}" name="${group}" data-state="${stateKey}" value="${value}" ${current === value ? 'checked' : ''}><label for="${id}">${text}</label></div>`; }
    function check(group, value, text, checked, stateKey = group) { const id = `${group}-${value}`.replace(/[^a-z0-9-]/gi, ''); return `<div class="check-item"><input type="checkbox" id="${id}" data-array="${stateKey}" value="${value}" ${checked ? 'checked' : ''}><label for="${id}">${text}</label></div>`; }
    function hiddenDetailRemove(touch, label) { return `<button type="button" class="hidden-detail-remove" data-remove-detail="${touch}" aria-label="Remove ${esc(label)} section" title="Remove ${esc(label)} section">×</button>`; }
    function selectedValues(arrayName) { return [...body.querySelectorAll(`input[data-array="${arrayName}"]:checked`)].map(input => input.value); }
    function val(id, key) { const el = body.querySelector(`#${id}`); if (el) el.addEventListener('input', e => state[key] = e.target.value); }

    function stepNumber() { const index = activeFlow().indexOf(state.step); return index >= 0 ? index + 1 : 1; }
    function render() {
      if (!ownerPreviewInitialized) {
        if (ownerPreviewAccess()) body.classList.add('owner-preview-active');
        ownerPreviewInitialized = true;
      }
      const previousStep = body.dataset.renderedStep;
      const previousScrollTop = body.scrollTop;
      const number = stepNumber();
      progressBar.style.width = `${Math.min(100, (Math.min(number, preQuoteSteps()) / preQuoteSteps()) * 100)}%`;
      widgetHeadline.textContent = state.step === 'quote' ? 'Your quote is ready' : 'Turn project answers into a quote';
      widgetSubhead.textContent = state.step === 'quote' ? 'A starting point based on the scope you provided.' : 'Ask only what changes the price while your pricing stays in control.';
      foot.style.display = state.step === 'quote' ? 'none' : 'flex';
      backButton.style.visibility = number > 1 && state.step !== 'quote' ? 'visible' : 'hidden';
      nextButton.textContent = state.step === 'contact' ? 'See my quote →' : 'Continue →';
      const views = { property: renderProperty, project: renderProject, route: renderRoute, contact: renderContact, quote: renderQuote };
      body.innerHTML = state.step === 'kitchen-details' ? renderKitchenDetailsStep() : state.step === 'bathroom-scope' ? renderBathroomScopeStep() : state.step === 'bathroom-details' ? renderBathroomDetailsStep() : views[state.step]();
      bindStep();
      body.dataset.renderedStep = state.step;
      body.scrollTop = previousStep === state.step ? previousScrollTop : 0;
    }

    function kicker(label) { return `<div class="step-kicker">Step ${stepNumber()} of ${preQuoteSteps()}</div><h3 class="step-title">${label}</h3>`; }
    function renderProperty() {
      return `${kicker('Property and location')}<p class="step-help">Start with the property details that can affect access, staging and disposal requirements.</p><div class="field"><label>Property type</label><div class="radio-list">${radio('propertyType','single-family','Single-Family',state.propertyType,'propertyType')}${radio('propertyType','townhouse','Townhouse',state.propertyType,'propertyType')}${radio('propertyType','condo','Condo / Apartment',state.propertyType,'propertyType')}</div></div><div class="field"><label for="zip">Project ZIP code</label><input id="zip" inputmode="numeric" maxlength="5" placeholder="e.g. 90210" value="${esc(state.zip)}"><p class="helper-line">Used for service area and location adjustments.</p></div><p class="error-line" id="stepError">Choose a property type and enter a valid 5-digit ZIP code.</p>`;
    }
    function renderProject() {
      const available = `${OWNER_CONFIG.activeServices.kitchen ? check('interiorProjects','kitchen','Kitchen',state.interiorProjects.includes('kitchen'),'interiorProjects') : ''}${OWNER_CONFIG.activeServices.bathroom ? check('interiorProjects','bathroom','Bath',state.interiorProjects.includes('bathroom'),'interiorProjects') : ''}`;
      return `${kicker('What are you remodeling?')}<p class="step-help">Choose Kitchen, Bath, or both.</p><div class="sub-question" style="margin-top:0;padding-top:0;border-top:0"><div class="check-list">${available}</div></div><p class="error-line" id="stepError">Select an available service to continue.</p>`;
    }

    function renderKitchenScopeContent() {
      return `<div class="kitchen-scope-section"><div class="kitchen-details-title">Step 1: Scope</div><div class="radio-list">${radio('kitchenScope','cosmetic-refresh','Cosmetic / Pull and Replace <small class="radio-description">No Layout Changes, Keep the current footprint</small>',state.kitchenScope,'kitchenScope')}${radio('kitchenScope','hybrid-refresh','Hybrid Refresh <small class="radio-description">Cosmetic + some Layout Changes</small>',state.kitchenScope,'kitchenScope')}${radio('kitchenScope','full-gut','Full Gut Remodel <small class="radio-description">Total Space Re-design</small>',state.kitchenScope,'kitchenScope')}</div></div>`;
    }
    function renderKitchenDetailsContent() {
      const touches = state.kitchenScopeTouches;
      const fullGut = state.kitchenScope === 'full-gut';
      const firstHiddenDetail = touches.find(touch => ['cabinets','countertops','flooring','windows','painting','wall'].includes(touch));
      const hiddenDetailClass = touch => touch === firstHiddenDetail ? ' first-hidden-detail' : '';
      const hiddenDetails = touches.some(touch => ['cabinets','countertops','flooring','windows','painting','wall'].includes(touch)) ? `<div class="kitchen-hidden-details"><div class="kitchen-details-title">Hidden Details</div>${touches.includes('cabinets') ? `<div class="kitchen-option-group${hiddenDetailClass('cabinets')}" style="order:${touches.indexOf('cabinets') + 1};">${hiddenDetailRemove('cabinets','Cabinets')}<strong>Cabinets:</strong><div class="radio-list">${radio('kitchenCabinetAction','keep','Keep &gt;',state.kitchenCabinetAction,'kitchenCabinetAction')}${radio('kitchenCabinetAction','replace','Replace &gt;',state.kitchenCabinetAction,'kitchenCabinetAction')}</div>${state.kitchenCabinetAction === 'keep' ? `<div class="kitchen-cabinet-followup"><div class="radio-list">${radio('kitchenCabinetKeepType','refinish','Refinishing/Painting',state.kitchenCabinetKeepType,'kitchenCabinetKeepType')}${radio('kitchenCabinetKeepType','change-doors-drawers','Refacing',state.kitchenCabinetKeepType,'kitchenCabinetKeepType')}</div></div>` : state.kitchenCabinetAction === 'replace' ? `<div class="kitchen-cabinet-followup"><div class="radio-list">${radio('kitchenCabinetReplaceType','premade','Premade',state.kitchenCabinetReplaceType,'kitchenCabinetReplaceType')}${radio('kitchenCabinetReplaceType','semi-custom','Semi-Custom',state.kitchenCabinetReplaceType,'kitchenCabinetReplaceType')}${radio('kitchenCabinetReplaceType','custom','Custom',state.kitchenCabinetReplaceType,'kitchenCabinetReplaceType')}</div></div>` : ''}</div>` : ''}${touches.includes('flooring') ? `<div class="kitchen-option-group${hiddenDetailClass('flooring')}" style="order:${touches.indexOf('flooring') + 1};">${hiddenDetailRemove('flooring','Flooring')}<strong>Flooring:</strong><div class="radio-list">${radio('kitchenFlooringAction','repair','Repair &gt;',state.kitchenFlooringAction,'kitchenFlooringAction')}${radio('kitchenFlooringAction','replace','Replacement',state.kitchenFlooringAction,'kitchenFlooringAction')}${radio('kitchenFlooringAction','overlay','Overlay',state.kitchenFlooringAction,'kitchenFlooringAction')}</div>${state.kitchenFlooringAction === 'repair' ? `<div class="kitchen-cabinet-followup"><strong>Repair options:</strong><div class="radio-list">${radio('kitchenFlooringRepairType','superficial','Superficial Repair (Grout, Refinish)',state.kitchenFlooringRepairType,'kitchenFlooringRepairType')}${radio('kitchenFlooringRepairType','localized','Localized Repair (Cracked/Missing Tiles)',state.kitchenFlooringRepairType,'kitchenFlooringRepairType')}${radio('kitchenFlooringRepairType','subfloor','Subfloor Repair (Required due to Water Damage)',state.kitchenFlooringRepairType,'kitchenFlooringRepairType')}</div></div>` : ''}</div>` : ''}${touches.includes('windows') ? `<div class="kitchen-option-group${hiddenDetailClass('windows')}" style="order:${touches.indexOf('windows') + 1};">${hiddenDetailRemove('windows','Windows')}<strong>Windows:</strong><div class="radio-list">${radio('kitchenWindowAction','replace','Replace &gt;',state.kitchenWindowAction,'kitchenWindowAction')}${radio('kitchenWindowAction','resize','Resize',state.kitchenWindowAction,'kitchenWindowAction')}${radio('kitchenWindowAction','move','Move',state.kitchenWindowAction,'kitchenWindowAction')}</div>${state.kitchenWindowAction === 'replace' ? `<div class="kitchen-cabinet-followup"><strong>Replacement option:</strong><div class="radio-list">${radio('kitchenWindowReplacementType','glass-only','Glass-Only',state.kitchenWindowReplacementType,'kitchenWindowReplacementType')}${radio('kitchenWindowReplacementType','retrofit','Retrofit',state.kitchenWindowReplacementType,'kitchenWindowReplacementType')}${radio('kitchenWindowReplacementType','full-frame','Full-Frame',state.kitchenWindowReplacementType,'kitchenWindowReplacementType')}</div></div>` : ''}<div class="field window-count-field"><label for="kitchenWindowCount">Number of windows</label><input id="kitchenWindowCount" type="number" min="1" step="1" placeholder="e.g. 4" value="${esc(state.kitchenWindowCount)}"></div></div>` : ''}${touches.includes('countertops') ? `<div class="kitchen-option-group${hiddenDetailClass('countertops')}" style="order:${touches.indexOf('countertops') + 1};">${hiddenDetailRemove('countertops','Countertops')}<strong>Countertops:</strong><div class="radio-list">${radio('kitchenCountertopAction','remove-replace','Remove &amp; Replace',state.kitchenCountertopAction,'kitchenCountertopAction')}${radio('kitchenCountertopAction','restore-polish','Restore &amp; Polish',state.kitchenCountertopAction,'kitchenCountertopAction')}</div><div class="check-list kitchen-hidden-options">${check('kitchenHiddenDetails','matching-backsplash','Add Matching Backsplash',state.kitchenHiddenDetails.includes('matching-backsplash'),'kitchenHiddenDetails')}</div></div>` : ''}${touches.includes('painting') && !fullGut ? `<div class="kitchen-option-group${hiddenDetailClass('painting')}" style="order:${touches.indexOf('painting') + 1};">${hiddenDetailRemove('painting','Painting')}<strong>Painting:</strong><div class="radio-list">${radio('kitchenPaintType','walls-ceiling','1- Walls &amp; Ceiling',state.kitchenPaintType,'kitchenPaintType')}${radio('kitchenPaintType','trim-doors','2- Trim &amp; Doors',state.kitchenPaintType,'kitchenPaintType')}${radio('kitchenPaintType','full','3- Full',state.kitchenPaintType,'kitchenPaintType')}</div></div>` : ''}${touches.includes('wall') ? `<div class="kitchen-option-group${hiddenDetailClass('wall')}" style="order:${touches.indexOf('wall') + 1};">${hiddenDetailRemove('wall','Remove a Wall')}<strong>Remove a Wall:</strong><div class="radio-list">${radio('kitchenWallRemovalType','load-bearing','Load-Bearing',state.kitchenWallRemovalType,'kitchenWallRemovalType')}${radio('kitchenWallRemovalType','non-load-bearing','Non-Load-Bearing',state.kitchenWallRemovalType,'kitchenWallRemovalType')}</div></div>` : ''}</div>` : '';
      const majorAddOns = `<div class="kitchen-major-addons"><div class="kitchen-details-title">Major Add-ons (optional)</div><div class="check-list kitchen-touch-list">${check('kitchenMajorAddOns','center-island-utilities','Adding a Center Island with Utilities',state.kitchenMajorAddOns.includes('center-island-utilities'),'kitchenMajorAddOns')}${state.kitchenScope !== 'cosmetic-refresh' ? check('kitchenMajorAddOns','move-water','Sink / Dishwasher Move',state.kitchenMajorAddOns.includes('move-water'),'kitchenMajorAddOns') : ''}${state.kitchenScope !== 'cosmetic-refresh' ? `${check('kitchenMajorAddOns','move-electricity','Moving electricity',state.kitchenMajorAddOns.includes('move-electricity'),'kitchenMajorAddOns')}${check('kitchenMajorAddOns','move-gas-appliances','Moving gas appliances',state.kitchenMajorAddOns.includes('move-gas-appliances'),'kitchenMajorAddOns')}` : ''}${check('kitchenMajorAddOns','upgrade-main-panel-200a','Upgrade main electrical panel to 200 amps',state.kitchenMajorAddOns.includes('upgrade-main-panel-200a'),'kitchenMajorAddOns')}</div></div>`;
      const automaticScopeNote = state.kitchenScope === 'full-gut' ? `<div class="automatic-scope-note"><strong>Automatically included in Full Gut:</strong><span>Flooring Replacement, Full Painting, Kitchen Sink Replacement, and bundled water, electrical and gas line renewal based on Kitchen size.</span></div>` : '';
      return `${automaticScopeNote}<div class="kitchen-touch-section"><div class="kitchen-details-title">Step 2: What are we actually touching?</div><div class="check-list kitchen-touch-list">${check('kitchenScopeTouches','cabinets','Cabinets',touches.includes('cabinets'),'kitchenScopeTouches')}${check('kitchenScopeTouches','countertops','Countertops',touches.includes('countertops'),'kitchenScopeTouches')}${!fullGut ? check('kitchenScopeTouches','flooring','Flooring',touches.includes('flooring'),'kitchenScopeTouches') : ''}${check('kitchenScopeTouches','windows','Windows',touches.includes('windows'),'kitchenScopeTouches')}${!fullGut ? check('kitchenScopeTouches','painting','Painting',touches.includes('painting'),'kitchenScopeTouches') : ''}${state.kitchenScope !== 'cosmetic-refresh' ? check('kitchenScopeTouches','wall','Remove a Wall',touches.includes('wall'),'kitchenScopeTouches') : ''}${state.kitchenScope !== 'full-gut' ? check('kitchenScopeTouches','sink',state.kitchenScope === 'cosmetic-refresh' ? 'Replace Sink' : state.kitchenScope === 'hybrid-refresh' ? 'Sink Replace' : 'Sink',touches.includes('sink'),'kitchenScopeTouches') : ''}</div></div>${hiddenDetails}${majorAddOns}`;
    }
    function renderBathroomScopeContent() {
      return `<div class="kitchen-scope-section"><div class="kitchen-details-title">Step 1: Scope</div><div class="radio-list">${radio('bathroomScope','cosmetic-refresh','Cosmetic / Pull and Replace <small class="radio-description">No Layout Changes, Keep the current footprint</small>',state.bathroomScope,'bathroomScope')}${radio('bathroomScope','hybrid-refresh','Hybrid Refresh <small class="radio-description">Cosmetic + some Layout Changes</small>',state.bathroomScope,'bathroomScope')}${radio('bathroomScope','full-gut','Full Gut Remodel <small class="radio-description">Total Space Re-design</small>',state.bathroomScope,'bathroomScope')}</div></div>`;
    }
    function renderBathroomWaterMoveOptions() {
      const options = [
        { key: 'move-sink', label: 'Move Sink &gt;', stateKey: 'bathroomWaterMoveSinkType', choices: [['same-wall', 'Same Wall'], ['new-wall', 'New Wall']] },
        { key: 'move-shower', label: 'Move Shower &gt;', stateKey: 'bathroomWaterMoveShowerType', choices: [['move-drain', 'Valve Only'], ['move-full-valve-drain', 'Full']] },
        { key: 'move-toilet', label: 'Move Toilet &gt;', stateKey: 'bathroomWaterMoveToiletType', choices: [['short-nudge', 'Short Nudge'], ['across-room', 'Across Room']] }
      ];
      const selected = state.bathroomWaterMoveDetails.filter(detail => options.some(option => option.key === detail));
      const order = [...selected, ...options.map(option => option.key).filter(key => !selected.includes(key))];
      return `<div class="water-move-options">${order.map(key => {
        const option = options.find(item => item.key === key);
        const isSelected = selected.includes(option.key);
        const followup = isSelected ? `<div class="water-move-suboptions"><div class="radio-list">${option.choices.map(([value, label]) => radio(option.stateKey, value, label, state[option.stateKey], option.stateKey)).join('')}</div></div>` : '';
        return `<div class="water-move-option"><div class="water-move-parent">${check('bathroomWaterMoveDetails', option.key, option.label, isSelected, 'bathroomWaterMoveDetails')}</div>${followup}</div>`;
      }).join('')}</div>`;
    }
    function renderBathroomDetailsContent(includeSize = true) {
      state.bathroomScopeTouches = state.bathroomScopeTouches.filter(touch => touch !== 'sink');
      const touches = state.bathroomScopeTouches;
      const fullGut = state.bathroomScope === 'full-gut';
      const firstHiddenDetail = touches.find(touch => ['vanity-cabinets','countertops','flooring','windows','shower-tub','water-move','painting','wall'].includes(touch) || (!fullGut && touch === 'sink'));
      const hiddenDetailClass = touch => touch === firstHiddenDetail ? ' first-hidden-detail' : '';
      const hiddenDetails = touches.some(touch => ['vanity-cabinets','countertops','flooring','windows','shower-tub','water-move','painting','wall'].includes(touch) || (!fullGut && touch === 'sink')) ? `<div class="kitchen-hidden-details bathroom-hidden-details"><div class="kitchen-details-title">Hidden Details</div>${touches.includes('vanity-cabinets') ? `<div class="kitchen-option-group${hiddenDetailClass('vanity-cabinets')}" style="order:${touches.indexOf('vanity-cabinets') + 1};">${hiddenDetailRemove('vanity-cabinets','Vanity & Cabinets')}<strong>Vanity &amp; Cabinets:</strong><div class="radio-list">${radio('bathroomVanityAction','keep','Keep &gt;',state.bathroomVanityAction,'bathroomVanityAction')}${radio('bathroomVanityAction','replace','Replace &gt;',state.bathroomVanityAction,'bathroomVanityAction')}</div>${state.bathroomVanityAction === 'keep' ? `<div class="kitchen-cabinet-followup"><div class="radio-list">${radio('bathroomVanityKeepType','refinish','Refinishing/Painting',state.bathroomVanityKeepType,'bathroomVanityKeepType')}${radio('bathroomVanityKeepType','change-doors-drawers','Refacing',state.bathroomVanityKeepType,'bathroomVanityKeepType')}</div></div>` : state.bathroomVanityAction === 'replace' ? `<div class="kitchen-cabinet-followup"><div class="radio-list">${radio('bathroomVanityReplaceType','premade','Premade',state.bathroomVanityReplaceType,'bathroomVanityReplaceType')}${radio('bathroomVanityReplaceType','semi-custom','Semi-Custom',state.bathroomVanityReplaceType,'bathroomVanityReplaceType')}${radio('bathroomVanityReplaceType','custom','Custom',state.bathroomVanityReplaceType,'bathroomVanityReplaceType')}</div></div>` : ''}</div>` : ''}${touches.includes('flooring') ? `<div class="kitchen-option-group${hiddenDetailClass('flooring')}" style="order:${touches.indexOf('flooring') + 1};">${hiddenDetailRemove('flooring','Flooring')}<strong>Flooring:</strong><div class="radio-list">${radio('bathroomFlooringAction','repair','Repair &gt;',state.bathroomFlooringAction,'bathroomFlooringAction')}${radio('bathroomFlooringAction','replace','Replacement',state.bathroomFlooringAction,'bathroomFlooringAction')}${radio('bathroomFlooringAction','overlay','Overlay',state.bathroomFlooringAction,'bathroomFlooringAction')}</div>${state.bathroomFlooringAction === 'repair' ? `<div class="kitchen-cabinet-followup"><strong>Repair options:</strong><div class="radio-list">${radio('bathroomFlooringRepairType','superficial','Superficial Repair (Grout, Refinish)',state.bathroomFlooringRepairType,'bathroomFlooringRepairType')}${radio('bathroomFlooringRepairType','localized','Localized Repair (Cracked/Missing Tiles)',state.bathroomFlooringRepairType,'bathroomFlooringRepairType')}${radio('bathroomFlooringRepairType','subfloor','Subfloor Repair (Required due to Water Damage)',state.bathroomFlooringRepairType,'bathroomFlooringRepairType')}</div></div>` : ''}</div>` : ''}${touches.includes('windows') ? `<div class="kitchen-option-group${hiddenDetailClass('windows')}" style="order:${touches.indexOf('windows') + 1};">${hiddenDetailRemove('windows','Windows')}<strong>Windows:</strong><div class="radio-list">${radio('bathroomWindowAction','replace','Replace &gt;',state.bathroomWindowAction,'bathroomWindowAction')}${radio('bathroomWindowAction','resize','Resize',state.bathroomWindowAction,'bathroomWindowAction')}${radio('bathroomWindowAction','move','Move',state.bathroomWindowAction,'bathroomWindowAction')}</div>${state.bathroomWindowAction === 'replace' ? `<div class="kitchen-cabinet-followup"><strong>Replacement option:</strong><div class="radio-list">${radio('bathroomWindowReplacementType','glass-only','Glass-Only',state.bathroomWindowReplacementType,'bathroomWindowReplacementType')}${radio('bathroomWindowReplacementType','retrofit','Retrofit',state.bathroomWindowReplacementType,'bathroomWindowReplacementType')}${radio('bathroomWindowReplacementType','full-frame','Full-Frame',state.bathroomWindowReplacementType,'bathroomWindowReplacementType')}</div></div>` : ''}<div class="field window-count-field"><label for="bathroomWindowCount">Number of windows</label><input id="bathroomWindowCount" type="number" min="1" step="1" placeholder="e.g. 2" value="${esc(state.bathroomWindowCount)}"></div></div>` : ''}${touches.includes('countertops') ? `<div class="kitchen-option-group${hiddenDetailClass('countertops')}" style="order:${touches.indexOf('countertops') + 1};">${hiddenDetailRemove('countertops','Countertops')}<strong>Countertops:</strong><div class="radio-list">${radio('bathroomCountertopAction','remove-replace','Remove &amp; Replace',state.bathroomCountertopAction,'bathroomCountertopAction')}${radio('bathroomCountertopAction','restore-polish','Restore &amp; Polish',state.bathroomCountertopAction,'bathroomCountertopAction')}</div><div class="check-list kitchen-hidden-options">${check('bathroomHiddenDetails','matching-backsplash','Add Matching Backsplash',state.bathroomHiddenDetails.includes('matching-backsplash'),'bathroomHiddenDetails')}</div></div>` : ''}${touches.includes('shower-tub') ? `<div class="kitchen-option-group${hiddenDetailClass('shower-tub')}" style="order:${touches.indexOf('shower-tub') + 1};">${hiddenDetailRemove('shower-tub','Shower & Tub Area')}<strong>Shower &amp; Tub Area:</strong><div class="radio-list">${radio('bathroomShowerBase','tub-to-shower','Tub-to-Shower Conversion &gt;',state.bathroomShowerBase,'bathroomShowerBase')}${radio('bathroomShowerBase','acrylic-insert','Standard Acrylic Tub/Shower Insert &gt;',state.bathroomShowerBase,'bathroomShowerBase')}</div>${state.bathroomShowerBase === 'acrylic-insert' ? `<div class="kitchen-cabinet-followup"><strong>Add-on:</strong><div class="check-list kitchen-hidden-options">${check('bathroomShowerDetails','frameless-glass','Install Frameless Glass Enclosure',state.bathroomShowerDetails.includes('frameless-glass'),'bathroomShowerDetails')}</div></div>` : ''}${state.bathroomShowerBase === 'tub-to-shower' ? `<div class="kitchen-cabinet-followup"><strong>Add-ons:</strong><div class="check-list kitchen-hidden-options">${check('bathroomShowerDetails','custom-tiled-shower','Custom Tiled Shower with Waterproofing System',state.bathroomShowerDetails.includes('custom-tiled-shower'),'bathroomShowerDetails')}${check('bathroomShowerDetails','frameless-glass','Install Frameless Glass Enclosure',state.bathroomShowerDetails.includes('frameless-glass'),'bathroomShowerDetails')}${check('bathroomShowerDetails','tiled-niche','Add Built-In Tiled Niche',state.bathroomShowerDetails.includes('tiled-niche'),'bathroomShowerDetails')}</div></div>` : ''}</div>` : ''}${touches.includes('water-move') ? `<div class="kitchen-option-group${hiddenDetailClass('water-move')}" style="order:${touches.indexOf('water-move') + 1};">${hiddenDetailRemove('water-move','Water Move')}<strong>Water Move:</strong>${renderBathroomWaterMoveOptions()}</div>` : ''}${!fullGut && touches.includes('sink') ? `<div class="kitchen-option-group${hiddenDetailClass('sink')}" style="order:${touches.indexOf('sink') + 1};">${hiddenDetailRemove('sink','Sink')}<strong>Sink:</strong><div class="radio-list">${radio('bathroomSinkAction','replace','Replace',state.bathroomSinkAction,'bathroomSinkAction')}${radio('bathroomSinkAction','move','Move',state.bathroomSinkAction,'bathroomSinkAction')}</div></div>` : ''}${touches.includes('painting') && !fullGut ? `<div class="kitchen-option-group${hiddenDetailClass('painting')}" style="order:${touches.indexOf('painting') + 1};">${hiddenDetailRemove('painting','Painting')}<strong>Painting:</strong><div class="radio-list">${radio('bathroomPaintType','walls-ceiling','1- Walls &amp; Ceiling',state.bathroomPaintType,'bathroomPaintType')}${radio('bathroomPaintType','trim-doors','2- Trim &amp; Doors',state.bathroomPaintType,'bathroomPaintType')}${radio('bathroomPaintType','full','3- Full',state.bathroomPaintType,'bathroomPaintType')}</div></div>` : ''}${touches.includes('wall') ? `<div class="kitchen-option-group${hiddenDetailClass('wall')}" style="order:${touches.indexOf('wall') + 1};">${hiddenDetailRemove('wall','Remove a Wall')}<strong>Remove a Wall:</strong><div class="radio-list">${radio('bathroomWallRemovalType','load-bearing','Load-Bearing',state.bathroomWallRemovalType,'bathroomWallRemovalType')}${radio('bathroomWallRemovalType','non-load-bearing','Non-Load-Bearing',state.bathroomWallRemovalType,'bathroomWallRemovalType')}</div></div>` : ''}</div>` : '';
      const majorAddOns = `<div class="kitchen-major-addons bathroom-major-addons"><div class="kitchen-details-title">Major Add-ons (optional)</div><div class="check-list kitchen-touch-list">${state.bathroomScope !== 'cosmetic-refresh' ? check('bathroomMajorAddOns','move-electricity','Move Electricity',state.bathroomMajorAddOns.includes('move-electricity'),'bathroomMajorAddOns') : ''}${check('bathroomMajorAddOns','exhaust-fan','Exhaust Fan',state.bathroomMajorAddOns.includes('exhaust-fan'),'bathroomMajorAddOns')}</div></div>`;
      const automaticScopeNote = state.bathroomScope === 'full-gut' ? `<div class="automatic-scope-note"><strong>Automatically included in Full Gut:</strong><span>Flooring Replacement, Full Painting, Bathroom Sink Replacement, and bundled water, electrical and gas line renewal based on Bathroom size.</span></div>` : '';
      return `${automaticScopeNote}<div class="kitchen-touch-section"><div class="kitchen-details-title">Step 2: What are you actually touching?</div><div class="check-list kitchen-touch-list bathroom-touch-list">${check('bathroomScopeTouches','vanity-cabinets','Vanity &amp; Cabinets',touches.includes('vanity-cabinets'),'bathroomScopeTouches')}${check('bathroomScopeTouches','countertops','Countertops',touches.includes('countertops'),'bathroomScopeTouches')}${!fullGut ? check('bathroomScopeTouches','flooring','Flooring',touches.includes('flooring'),'bathroomScopeTouches') : ''}${check('bathroomScopeTouches','windows','Windows',touches.includes('windows'),'bathroomScopeTouches')}${check('bathroomScopeTouches','shower-tub','Shower / Tub Area',touches.includes('shower-tub'),'bathroomScopeTouches')}${state.bathroomScope !== 'cosmetic-refresh' ? check('bathroomScopeTouches','water-move','Water Move',touches.includes('water-move'),'bathroomScopeTouches') : ''}${!fullGut ? check('bathroomScopeTouches','painting','Painting',touches.includes('painting'),'bathroomScopeTouches') : ''}${state.bathroomScope !== 'cosmetic-refresh' ? check('bathroomScopeTouches','wall','Remove a Wall',touches.includes('wall'),'bathroomScopeTouches') : ''}</div></div>${hiddenDetails}${majorAddOns}${includeSize ? `<div class="bathroom-size-followup"><h3>Bath Size</h3>${sizeRadios('bathroomSize',state.bathroomSize,'bathroomSize')}</div>` : ''}`;
    }


    function renderKitchenScopeStep() {
      return `${kicker('Kitchen scope')}${renderKitchenScopeContent()}<p class="error-line" id="stepError">Choose a Kitchen scope to continue.</p>`;
    }
    function renderKitchenDetailsStep() {
      const areaCard = (number, title, content) => `<div class="route-card interior-area-card"><div class="area-card-step">Interior area ${number}</div><h3>${title}</h3>${content}</div>`;
      const finishContent = `<div class="sub-question"><h3>Kitchen Material Grade</h3><div class="radio-list">${radio('kitchenMaterialGrade','standard','Builder',state.kitchenMaterialGrade,'kitchenMaterialGrade')}${radio('kitchenMaterialGrade','semi-custom','Mid-Range',state.kitchenMaterialGrade,'kitchenMaterialGrade')}${radio('kitchenMaterialGrade','custom','Luxury',state.kitchenMaterialGrade,'kitchenMaterialGrade')}</div></div>`;
      const cards = [];
      if (state.interiorProjects.includes('kitchen')) cards.push(areaCard(1, 'Kitchen', `${renderKitchenDetailsContent()}${finishContent}<div class="sub-question"><h3>Kitchen size</h3>${sizeRadios('kitchenSize',state.kitchenSize,'kitchenSize')}</div>`));
      return `${kicker('Kitchen details')}<div class="route-stack">${cards.join('')}</div><p class="error-line" id="stepError">Please provide all required project details.</p>`;
    }
    function renderBathroomScopeStep() {
      return `${kicker('Bath scope')}${renderBathroomScopeContent()}<p class="error-line" id="stepError">Choose a Bath scope to continue.</p>`;
    }
    function renderBathroomDetailsStep() {
      const finishContent = `<div class="sub-question"><h3>Bath Material Grade</h3><div class="radio-list">${radio('bathroomMaterialGrade','standard','Builder',state.bathroomMaterialGrade,'bathroomMaterialGrade')}${radio('bathroomMaterialGrade','semi-custom','Mid-Range',state.bathroomMaterialGrade,'bathroomMaterialGrade')}${radio('bathroomMaterialGrade','custom','Luxury',state.bathroomMaterialGrade,'bathroomMaterialGrade')}</div></div>`;
      return `${kicker('Bath details')}<div class="route-stack"><div class="route-card interior-area-card"><div class="area-card-step">Interior area 1</div><h3>Bath</h3>${renderBathroomDetailsContent(false)}${finishContent}<div class="bathroom-size-followup"><h3>Bath Size</h3>${sizeRadios('bathroomSize',state.bathroomSize,'bathroomSize')}</div></div></div><p class="error-line" id="stepError">Please provide all required project details.</p>`;
    }



    function renderRoute() {
      if (state.interiorProjects.includes('kitchen')) return renderKitchenScopeStep();
      if (state.interiorProjects.includes('bathroom')) return renderBathroomScopeStep();
      return `${kicker('Choose Kitchen or Bath')}<p class="step-help">Select Kitchen or Bath to continue.</p><p class="error-line" id="stepError">Choose Kitchen or Bath to continue.</p>`;
    }

    function kitchenTouchesComplete() {
      const touches = state.kitchenScopeTouches;
      const allowedWindowActions = ['resize', 'move', 'replace'];
      const windowReplacementComplete = !touches.includes('windows') || state.kitchenWindowAction !== 'replace' || ['glass-only', 'retrofit', 'full-frame'].includes(state.kitchenWindowReplacementType);
      const windowsComplete = !touches.includes('windows') || allowedWindowActions.includes(state.kitchenWindowAction) && Number(state.kitchenWindowCount) > 0 && windowReplacementComplete;
      const countertopComplete = !touches.includes('countertops') || ['remove-replace', 'restore-polish'].includes(state.kitchenCountertopAction);
      const sinkComplete = !touches.includes('sink') || ['cosmetic-refresh', 'hybrid-refresh', 'full-gut'].includes(state.kitchenScope);
      const cabinetComplete = !touches.includes('cabinets') || state.kitchenCabinetAction === 'keep' && !!state.kitchenCabinetKeepType || state.kitchenCabinetAction === 'replace' && !!state.kitchenCabinetReplaceType;
      return !!state.kitchenScope && touches.length > 0 && cabinetComplete && countertopComplete && (!touches.includes('painting') || !!state.kitchenPaintType) && (!touches.includes('flooring') || !!state.kitchenFlooringAction && (state.kitchenFlooringAction !== 'repair' || !!state.kitchenFlooringRepairType)) && sinkComplete && windowsComplete && (!touches.includes('wall') || !!state.kitchenWallRemovalType);
    }
    function bathroomTouchesComplete() {
      const touches = state.bathroomScopeTouches;
      const vanityComplete = state.bathroomVanityAction === 'keep' && !!state.bathroomVanityKeepType || state.bathroomVanityAction === 'replace' && !!state.bathroomVanityReplaceType;
      const allowedWindowActions = ['resize', 'move', 'replace'];
      const windowReplacementComplete = !touches.includes('windows') || state.bathroomWindowAction !== 'replace' || ['glass-only', 'retrofit', 'full-frame'].includes(state.bathroomWindowReplacementType);
      const windowsComplete = !touches.includes('windows') || allowedWindowActions.includes(state.bathroomWindowAction) && Number(state.bathroomWindowCount) > 0 && windowReplacementComplete;
      const countertopComplete = !touches.includes('countertops') || ['remove-replace', 'restore-polish'].includes(state.bathroomCountertopAction);
      const sinkComplete = state.bathroomScope === 'full-gut' || !touches.includes('sink') || ['replace', 'move'].includes(state.bathroomSinkAction);
      const waterMoveComplete = !touches.includes('water-move') || state.bathroomWaterMoveDetails.length > 0 && (!state.bathroomWaterMoveDetails.includes('move-sink') || !!state.bathroomWaterMoveSinkType) && (!state.bathroomWaterMoveDetails.includes('move-toilet') || !!state.bathroomWaterMoveToiletType) && (!state.bathroomWaterMoveDetails.includes('move-shower') || !!state.bathroomWaterMoveShowerType);
      return !!state.bathroomScope && touches.length > 0 && countertopComplete && (!touches.includes('vanity-cabinets') || vanityComplete) && sinkComplete && waterMoveComplete && (!touches.includes('painting') || !!state.bathroomPaintType) && (!touches.includes('flooring') || !!state.bathroomFlooringAction && (state.bathroomFlooringAction !== 'repair' || !!state.bathroomFlooringRepairType)) && windowsComplete && (!touches.includes('wall') || !!state.bathroomWallRemovalType);
    }
    function kitchenDetailsStepValid() { return !!state.kitchenSize && !!state.kitchenMaterialGrade && kitchenTouchesComplete(); }
    function bathroomDetailsStepValid() { return !!state.bathroomSize && !!state.bathroomMaterialGrade && bathroomTouchesComplete(); }





    function syncProjectSelection() {
      state.interiorProjects = state.interiorProjects.filter(project => ['kitchen', 'bathroom'].includes(project));
      state.project = state.interiorProjects.length === 2 ? 'kitchenbath' : state.interiorProjects[0] || '';
    }



    function sizeRadios(group, current, key, suffix='') { const kitchen = key === 'kitchenSize'; const bathroom = key === 'bathroomSize'; const labels = kitchen ? ['Small — less than 200 sq ft','Medium — 200–300 sq ft','Large — more than 300 sq ft'] : bathroom ? ['Small — less than 50 sq ft','Medium — 50-100 sq ft','Large — more than 100 sq ft'] : ['Small — less than 50 sq ft','Medium — 50–100 sq ft','Large — more than 100 sq ft']; return `<div class="radio-list">${radio(group,'small',labels[0],current,key,suffix)}${radio(group,'medium',labels[1],current,key,suffix)}${radio(group,'large',labels[2],current,key,suffix)}</div>`; }




    function renderContact() { return `${kicker('Reveal your quote')}<p class="step-help">Enter a first name and phone number to reveal the preliminary quote.</p><div class="field"><label for="firstName">First name</label><input id="firstName" autocomplete="given-name" placeholder="e.g. Jamie" value="${esc(state.firstName)}"></div><div class="field"><label for="phone">Phone number</label><input id="phone" autocomplete="tel" inputmode="tel" placeholder="(555) 123-4567" value="${esc(state.phone)}"><p class="helper-line">The contractor can use this to follow up on the project.</p></div><p class="error-line" id="stepError">Please enter a first name and a valid phone number.</p>`; }

    function addItem(items, name, qty, unit, price, source, included = true) { const value = Number(qty || 0) * Number(price || 0); if (value > 0) items.push({ name, qty: Number(qty || 0), unit, price: Number(price || 0), value, source, included }); return value; }
    function calculateKitchenMatrix(items) {
      const pricing = OWNER_CONFIG.kitchenPricing;
      const size = ['small', 'medium', 'large'].includes(state.kitchenSize) ? state.kitchenSize : 'medium';
      const scope = pricing.baseline[size][state.kitchenScope] || 0;
      const cabinetGrade = ({ premade: 'standard', 'semi-custom': 'semi-custom', custom: 'custom' })[state.kitchenCabinetReplaceType] || 'semi-custom';
      const cabinetMultiplier = pricing.cabinetMaterialMultipliers[cabinetGrade] || pricing.cabinetMaterialMultipliers.standard;
      const materialMultiplier = pricing.materialGradeMultipliers[state.kitchenMaterialGrade] || pricing.materialGradeMultipliers.standard;
      let total = addItem(items, `Kitchen baseline · ${pretty(state.kitchenScope)} · ${pretty(size)}`, 1, 'project', scope, 'Kitchen pricing matrix');
      const touches = state.kitchenScopeTouches;
      const fullGut = state.kitchenScope === 'full-gut';
      if (fullGut) total += addItem(items, 'Kitchen utility renewal · water, electrical and gas lines', 1, 'project', OWNER_CONFIG.fullGutUtilities.kitchen[size], 'Full Gut · bundled utility renewal by kitchen size');
      if (fullGut) total += addItem(items, 'Kitchen sink · Replace', 1, 'project', pricing.sink.replace, 'Full Gut · automatic sink replacement price');
      const includesFlooring = touches.includes('flooring') || fullGut;
      const includesPainting = touches.includes('painting') || fullGut;
      if (touches.includes('cabinets')) {
        if (state.kitchenCabinetAction === 'keep' && state.kitchenCabinetKeepType === 'refinish') total += addItem(items, 'Cabinet refinishing / painting', 1, 'project', pricing.cabinets.refinish[size] * cabinetMultiplier, 'Kitchen pricing matrix · cabinet multiplier');
        if (state.kitchenCabinetAction === 'keep' && state.kitchenCabinetKeepType === 'change-doors-drawers') total += addItem(items, 'Cabinet refacing', 1, 'project', pricing.cabinets['change-doors-drawers'][size] * cabinetMultiplier, 'Kitchen pricing matrix · cabinet multiplier');
        if (state.kitchenCabinetAction === 'replace') {
          const type = pricing.cabinets.replace[state.kitchenCabinetReplaceType] ? state.kitchenCabinetReplaceType : 'semi-custom';
          total += addItem(items, `${pretty(type)} cabinet replacement`, 1, 'project', pricing.cabinets.replace[type][size] * cabinetMultiplier, `Kitchen pricing matrix · cabinet replacement multiplier`);
        }
      }
      if (touches.includes('countertops')) {
        const countertopAction = state.kitchenCountertopAction === 'restore-polish' ? 'restore-polish' : 'remove-replace';
        const countertopPrices = pricing.countertops[countertopAction] || pricing.countertops.base || {};
        total += addItem(items, `Kitchen countertops · ${countertopLabel(countertopAction)}`, 1, 'project', (countertopPrices[size] || 0) * materialMultiplier, `Kitchen pricing matrix · ${countertopLabel(countertopAction)} · ${otherMaterialGradeLabel(state.kitchenMaterialGrade)} other-material multiplier`);
        if (state.kitchenHiddenDetails.includes('matching-backsplash')) total += addItem(items, 'Matching backsplash', 1, 'project', pricing.countertops.backsplash[size], 'Kitchen pricing matrix · no grade multiplier');
      }
      if (includesFlooring) {
        const flooringAction = fullGut ? 'replace' : state.kitchenFlooringAction;
        if (flooringAction === 'repair') { const repairType = state.kitchenFlooringRepairType || 'superficial'; const repairPrices = pricing.flooring.repair[repairType] || pricing.flooring.repair.superficial || {}; total += addItem(items, `Kitchen flooring · ${pretty(repairType)} repair · ${pretty(size)}`, 1, 'project', (repairPrices[size] || 0) * materialMultiplier, `Flooring repair pricing · ${pretty(repairType)} · ${otherMaterialGradeLabel(state.kitchenMaterialGrade)} material multiplier`); }
        else if (flooringAction === 'overlay') total += addItem(items, 'Kitchen flooring · overlay installation', 1, 'project', (pricing.flooring.overlay[size] || pricing.flooring.base[size]) * materialMultiplier, `Kitchen flooring overlay · ${otherMaterialGradeLabel(state.kitchenMaterialGrade)} material multiplier · no demolition or disposal`);
        else total += addItem(items, 'Kitchen flooring · replacement', 1, 'project', pricing.flooring.base[size] * materialMultiplier, `Kitchen replacement pricing · ${otherMaterialGradeLabel(state.kitchenMaterialGrade)} material multiplier`);
      }
      if (!fullGut && touches.includes('sink')) {
        const sinkAction = ['cosmetic-refresh', 'hybrid-refresh'].includes(state.kitchenScope) ? 'replace' : state.kitchenSinkAction;
        if (sinkAction === 'replace') total += addItem(items, 'Kitchen sink · replace', 1, 'project', pricing.sink.replace, 'Kitchen pricing matrix · sink replacement price');
      }
      if (touches.includes('windows') && state.kitchenWindowAction && Number(state.kitchenWindowCount) > 0) {
        const replacementType = ['glass-only', 'retrofit', 'full-frame'].includes(state.kitchenWindowReplacementType) ? state.kitchenWindowReplacementType : 'retrofit';
        const windowPrice = state.kitchenWindowAction === 'replace' ? pricing.windows.replace[replacementType] : pricing.windows[`${state.kitchenWindowAction}PerWindow`];
        const windowDetail = state.kitchenWindowAction === 'replace' ? `${windowActionLabel(state.kitchenWindowAction)} · ${windowReplacementLabel(replacementType)}` : windowActionLabel(state.kitchenWindowAction);
        total += addItem(items, `Kitchen windows · ${windowDetail}`, Number(state.kitchenWindowCount), 'window', windowPrice, `Kitchen pricing matrix · ${windowDetail} · per-window pricing`);
      }
      if (touches.includes('wall') && state.kitchenWallRemovalType) total += addItem(items, `${pretty(state.kitchenWallRemovalType)} wall removal`, 1, 'project', pricing.wall[state.kitchenWallRemovalType], 'Kitchen pricing matrix · flat fee');
      const kitchenPaintType = fullGut ? 'full' : state.kitchenPaintType;
      if (includesPainting && kitchenPaintType) total += addItem(items, `Kitchen painting · ${paintingLabel(kitchenPaintType)}`, 1, 'project', pricing.painting[kitchenPaintType][size], 'Kitchen pricing matrix · no grade multiplier');
      const kitchenMajorAddOnLabels = { 'center-island-utilities': 'Adding a Center Island with Utilities', 'move-water': 'Sink / Dishwasher Move', 'move-electricity': 'Moving electricity', 'move-gas-appliances': 'Moving gas appliances', 'upgrade-main-panel-200a': 'Upgrade main electrical panel to 200 amps' };
      state.kitchenMajorAddOns.forEach(addOn => { if (pricing.majorAddOns[addOn]) total += addItem(items, kitchenMajorAddOnLabels[addOn] || pretty(addOn), 1, 'project', pricing.majorAddOns[addOn], 'Kitchen pricing matrix · flat fee'); });
      return total;
    }
    function calculateBathroomMatrix(items) {
      const pricing = OWNER_CONFIG.bathroomPricing;
      const size = ['small', 'medium', 'large'].includes(state.bathroomSize) ? state.bathroomSize : 'medium';
      const scope = pricing.baseline[size][state.bathroomScope] || 0;
      const cabinetGrade = ({ premade: 'standard', 'semi-custom': 'semi-custom', custom: 'custom' })[state.bathroomVanityReplaceType] || 'semi-custom';
      const cabinetMultiplier = pricing.cabinetMaterialMultipliers[cabinetGrade] || pricing.cabinetMaterialMultipliers.standard;
      const materialMultiplier = pricing.materialGradeMultipliers[state.bathroomMaterialGrade] || pricing.materialGradeMultipliers.standard;
      const fullGut = state.bathroomScope === 'full-gut';
      const touches = state.bathroomScopeTouches;
      let total = addItem(items, `Bath baseline · ${pretty(state.bathroomScope)} · ${pretty(size)}`, 1, 'project', scope, 'Bath pricing matrix');
      if (fullGut) total += addItem(items, 'Bathroom utility renewal · water, electrical and gas lines', 1, 'project', OWNER_CONFIG.fullGutUtilities.bathroom[size], 'Full Gut · bundled utility renewal by room size');
      if (fullGut) total += addItem(items, 'Bathroom sink · Replace', 1, 'project', pricing.sink.replace, 'Full Gut · automatic sink replacement price');
      if (touches.includes('vanity-cabinets')) {
        if (state.bathroomVanityAction === 'keep' && state.bathroomVanityKeepType === 'refinish') total += addItem(items, 'Vanity refinishing / painting', 1, 'project', pricing.vanity.refinish[size] * cabinetMultiplier, 'Bath pricing matrix · vanity multiplier');
        if (state.bathroomVanityAction === 'keep' && state.bathroomVanityKeepType === 'change-doors-drawers') total += addItem(items, 'Vanity refacing', 1, 'project', pricing.vanity['change-doors-drawers'][size] * cabinetMultiplier, 'Bath pricing matrix · vanity multiplier');
        if (state.bathroomVanityAction === 'replace') {
          const type = pricing.vanity.replace[state.bathroomVanityReplaceType] ? state.bathroomVanityReplaceType : 'semi-custom';
          total += addItem(items, `${pretty(type)} vanity replacement`, 1, 'project', pricing.vanity.replace[type][size] * cabinetMultiplier, `Bath pricing matrix · vanity replacement multiplier`);
        }
      }
      if (touches.includes('countertops')) {
        const countertopAction = state.bathroomCountertopAction === 'restore-polish' ? 'restore-polish' : 'remove-replace';
        const countertopPrices = pricing.countertops[countertopAction] || pricing.countertops.base || {};
        total += addItem(items, `Bath countertops · ${countertopLabel(countertopAction)}`, 1, 'project', (countertopPrices[size] || 0) * materialMultiplier, `Bath pricing matrix · ${countertopLabel(countertopAction)} · ${otherMaterialGradeLabel(state.bathroomMaterialGrade)} other-material multiplier`);
        if (state.bathroomHiddenDetails.includes('matching-backsplash')) total += addItem(items, 'Bath matching backsplash', 1, 'project', pricing.countertops.backsplash, 'Bath pricing matrix · flat fee');
      }
      if (!fullGut && touches.includes('sink') && ['replace', 'move'].includes(state.bathroomSinkAction)) total += addItem(items, `Bath sink · ${state.bathroomSinkAction}`, 1, 'project', pricing.sink[state.bathroomSinkAction], 'Bath pricing matrix · sink action price');
      if (touches.includes('flooring') || fullGut) {
        const flooringAction = fullGut ? 'replace' : state.bathroomFlooringAction;
        if (flooringAction === 'repair') { const repairType = state.bathroomFlooringRepairType || 'superficial'; const repairPrices = pricing.flooring.repair[repairType] || pricing.flooring.repair.superficial || {}; total += addItem(items, `Bath flooring · ${pretty(repairType)} repair · ${pretty(size)}`, 1, 'project', (repairPrices[size] || 0) * materialMultiplier, `Flooring repair pricing · ${pretty(repairType)} · ${otherMaterialGradeLabel(state.bathroomMaterialGrade)} material multiplier`); }
        else if (flooringAction === 'overlay') total += addItem(items, 'Bath flooring · overlay installation', 1, 'project', (pricing.flooring.overlay[size] || pricing.flooring.base[size]) * materialMultiplier, `Bath flooring overlay · ${otherMaterialGradeLabel(state.bathroomMaterialGrade)} material multiplier · no demolition or disposal`);
        else total += addItem(items, 'Bath flooring · replacement', 1, 'project', pricing.flooring.base[size] * materialMultiplier, `Bath replacement pricing · ${otherMaterialGradeLabel(state.bathroomMaterialGrade)} material multiplier`);
      }
      if (touches.includes('windows') && state.bathroomWindowAction && Number(state.bathroomWindowCount) > 0) {
        const replacementType = ['glass-only', 'retrofit', 'full-frame'].includes(state.bathroomWindowReplacementType) ? state.bathroomWindowReplacementType : 'retrofit';
        const windowPrice = state.bathroomWindowAction === 'replace' ? pricing.windows.replace[replacementType] : pricing.windows[`${state.bathroomWindowAction}PerWindow`];
        const windowDetail = state.bathroomWindowAction === 'replace' ? `${windowActionLabel(state.bathroomWindowAction)} · ${windowReplacementLabel(replacementType)}` : windowActionLabel(state.bathroomWindowAction);
        total += addItem(items, `Bath windows · ${windowDetail}`, Number(state.bathroomWindowCount), 'window', windowPrice, `Bath pricing matrix · ${windowDetail} · per-window pricing`);
      }
      if (touches.includes('wall') && state.bathroomWallRemovalType) total += addItem(items, `${pretty(state.bathroomWallRemovalType)} wall removal`, 1, 'project', pricing.wall[state.bathroomWallRemovalType], 'Bath pricing matrix · flat fee');
      const paintType = fullGut ? 'full' : state.bathroomPaintType;
      if (touches.includes('painting') || fullGut) total += addItem(items, `Bath painting · ${paintingLabel(paintType)}`, 1, 'project', pricing.painting[paintType || 'full'][size], 'Bath pricing matrix · no grade multiplier');
      if (state.bathroomShowerBase) {
        const baseFee = pricing.shower[state.bathroomShowerBase] || 0;
        const baseLabel = state.bathroomShowerBase === 'tub-to-shower' ? 'Tub-to-Shower Conversion' : 'Standard Acrylic Tub/Shower Insert';
        total += addItem(items, baseLabel, 1, 'each', baseFee, 'Bath pricing matrix · shower / tub base option');
      }
      state.bathroomShowerDetails.forEach(detail => {
        const fee = pricing.shower[detail] || 0;
        const adjustedFee = detail === 'custom-tiled-shower' ? fee * materialMultiplier : fee;
        total += addItem(items, pretty(detail), 1, detail === 'tiled-niche' ? 'niche' : 'each', adjustedFee, detail === 'custom-tiled-shower' ? `Bath pricing matrix · ${otherMaterialGradeLabel(state.bathroomMaterialGrade)} other-material multiplier` : 'Bath pricing matrix · flat fee');
      });
      const waterMoveLabels = { 'same-wall': 'Same Wall', 'new-wall': 'New Wall', 'short-nudge': 'Short Nudge', 'across-room': 'Across Room', 'move-drain': 'Valve Only', 'move-full-valve-drain': 'Full' };
      if (touches.includes('water-move')) {
        if (state.bathroomWaterMoveDetails.includes('move-sink') && state.bathroomWaterMoveSinkType) total += addItem(items, `Bath water move · Sink — ${waterMoveLabels[state.bathroomWaterMoveSinkType] || pretty(state.bathroomWaterMoveSinkType)}`, 1, 'fixture', pricing.waterMove.sink[state.bathroomWaterMoveSinkType], 'Bath pricing matrix · water move · sink detail');
        if (state.bathroomWaterMoveDetails.includes('move-toilet') && state.bathroomWaterMoveToiletType) total += addItem(items, `Bath water move · Toilet — ${waterMoveLabels[state.bathroomWaterMoveToiletType] || pretty(state.bathroomWaterMoveToiletType)}`, 1, 'fixture', pricing.waterMove.toilet[state.bathroomWaterMoveToiletType], 'Bath pricing matrix · water move · toilet detail');
        if (state.bathroomWaterMoveDetails.includes('move-shower') && state.bathroomWaterMoveShowerType) total += addItem(items, `Bath water move · Shower — ${waterMoveLabels[state.bathroomWaterMoveShowerType] || pretty(state.bathroomWaterMoveShowerType)}`, 1, 'fixture', pricing.waterMove.shower[state.bathroomWaterMoveShowerType], 'Bath pricing matrix · water move · shower detail');
      }
      state.bathroomMajorAddOns.filter(addOn => addOn !== 'move-toilet-sink-shower').forEach(addOn => { if (pricing.majorAddOns[addOn]) total += addItem(items, pretty(addOn), 1, 'project', pricing.majorAddOns[addOn], 'Bath pricing matrix · flat fee'); });
      return total;
    }
    function selectedBasedOnDetails() {
      const details = [];
      const kitchenTouchNames = { cabinets: 'Cabinets', countertops: 'Countertops', flooring: 'Flooring', painting: 'Painting', wall: 'Remove a wall' };
      const bathroomTouchNames = { 'vanity-cabinets': 'Vanity & Cabinets', countertops: 'Countertops', flooring: 'Flooring', 'shower-tub': 'Shower / Tub Area', 'water-move': 'Water Move', painting: 'Painting', wall: 'Remove a wall' };
      const kitchenAddOnNames = { 'center-island-utilities': 'Center island with utilities', 'move-water': 'Sink / Dishwasher Move', 'move-electricity': 'Move electricity', 'move-gas-appliances': 'Move gas appliances', 'upgrade-main-panel-200a': 'Upgrade main electrical panel to 200 amps' };
      const bathroomAddOnNames = { 'move-electricity': 'Move electricity', 'exhaust-fan': 'Exhaust fan' };
      if (state.interiorProjects.includes('kitchen')) {
        const touches = state.kitchenScopeTouches.map(touch => kitchenTouchNames[touch] || pretty(touch));
        details.push(`Kitchen: ${state.kitchenScope ? pretty(state.kitchenScope) : 'Selected'}${touches.length ? ` · ${touches.join(', ')}` : ''}`);
        const kitchenChoices = [];
        if (state.kitchenScopeTouches.includes('cabinets')) {
          const cabinetDetail = state.kitchenCabinetAction === 'keep' ? `Cabinets kept — ${cabinetKeepLabel(state.kitchenCabinetKeepType)}` : state.kitchenCabinetAction === 'replace' ? `Cabinets replaced — ${pretty(state.kitchenCabinetReplaceType)}` : '';
          if (cabinetDetail) kitchenChoices.push(cabinetDetail);
        }
        if (state.kitchenScopeTouches.includes('countertops') && state.kitchenCountertopAction) kitchenChoices.push(`Countertops — ${countertopLabel(state.kitchenCountertopAction)}`);
        if (state.kitchenScopeTouches.includes('countertops') && state.kitchenHiddenDetails.includes('matching-backsplash')) kitchenChoices.push('Matching backsplash');
        if (state.kitchenScopeTouches.includes('painting') && state.kitchenPaintType) kitchenChoices.push(`Painting — ${paintingLabel(state.kitchenPaintType)}`);
        if (state.kitchenScopeTouches.includes('flooring') && state.kitchenFlooringAction) kitchenChoices.push(`Flooring — ${state.kitchenFlooringAction === 'replace' ? 'Replacement' : state.kitchenFlooringAction === 'overlay' ? 'Overlay' : `Repair${state.kitchenFlooringRepairType ? ` — ${pretty(state.kitchenFlooringRepairType)}` : ''}`}`);
        if (state.kitchenScope === 'full-gut') kitchenChoices.push('Sink — Replace (automatic)'); else if (state.kitchenScopeTouches.includes('sink')) kitchenChoices.push(`Sink — ${['cosmetic-refresh', 'hybrid-refresh'].includes(state.kitchenScope) ? 'Replace' : state.kitchenSinkAction || 'Not selected'}`);
        if (state.kitchenScopeTouches.includes('windows') && state.kitchenWindowAction) kitchenChoices.push(`Windows — ${windowSelectionLabel(state.kitchenWindowAction, state.kitchenWindowReplacementType)} · ${state.kitchenWindowCount} window${Number(state.kitchenWindowCount) === 1 ? '' : 's'}`);
        if (state.kitchenScope === 'full-gut') kitchenChoices.push('Flooring — Replacement; Painting — Full');
        if (state.kitchenScopeTouches.includes('wall') && state.kitchenWallRemovalType) kitchenChoices.push(`Wall — ${pretty(state.kitchenWallRemovalType)}`);
        if (state.kitchenScope === 'full-gut') kitchenChoices.push('Utilities — Water, electrical and gas line renewal (automatic)');
        if (kitchenChoices.length) details.push(`Kitchen actions: ${kitchenChoices.join('; ')}`);
        const kitchenAddOns = state.kitchenMajorAddOns.map(addOn => kitchenAddOnNames[addOn] || pretty(addOn));
        if (kitchenAddOns.length) details.push(`Kitchen add-ons: ${kitchenAddOns.join(', ')}`);
        if (state.kitchenMaterialGrade || state.kitchenSize) details.push(`Kitchen other-material grade / size: ${[state.kitchenMaterialGrade ? otherMaterialGradeLabel(state.kitchenMaterialGrade) : '', state.kitchenSize ? pretty(state.kitchenSize) : ''].filter(Boolean).join(' · ')}`);
      }
      if (state.interiorProjects.includes('bathroom')) {
        const touches = state.bathroomScopeTouches.map(touch => bathroomTouchNames[touch] || pretty(touch));
        details.push(`Bath: ${state.bathroomScope ? pretty(state.bathroomScope) : 'Selected'}${touches.length ? ` · ${touches.join(', ')}` : ''}`);
        const bathChoices = [];
        if (state.bathroomScopeTouches.includes('vanity-cabinets')) {
          const vanityDetail = state.bathroomVanityAction === 'keep' ? `Vanity kept — ${cabinetKeepLabel(state.bathroomVanityKeepType)}` : state.bathroomVanityAction === 'replace' ? `Vanity replaced — ${pretty(state.bathroomVanityReplaceType)}` : '';
          if (vanityDetail) bathChoices.push(vanityDetail);
        }
        if (state.bathroomScopeTouches.includes('countertops') && state.bathroomCountertopAction) bathChoices.push(`Countertops — ${countertopLabel(state.bathroomCountertopAction)}`);
        if (state.bathroomScopeTouches.includes('countertops') && state.bathroomHiddenDetails.includes('matching-backsplash')) bathChoices.push('Matching backsplash');
        const showerNames = { 'tub-to-shower': 'Tub-to-shower conversion', 'acrylic-insert': 'Standard acrylic tub/shower insert', 'custom-tiled-shower': 'Custom tiled shower with waterproofing system', 'frameless-glass': 'Frameless glass enclosure', 'tiled-niche': 'Built-in tiled niche' };
        if (state.bathroomShowerBase) bathChoices.push(showerNames[state.bathroomShowerBase]);
        state.bathroomShowerDetails.forEach(item => bathChoices.push(showerNames[item] || pretty(item)));
        const waterMoveNames = { 'same-wall': 'Same Wall', 'new-wall': 'New Wall', 'short-nudge': 'Short Nudge', 'across-room': 'Across Room', 'move-drain': 'Valve Only', 'move-full-valve-drain': 'Full' };
        if (state.bathroomScopeTouches.includes('water-move')) {
          if (state.bathroomWaterMoveDetails.includes('move-sink') && state.bathroomWaterMoveSinkType) bathChoices.push(`Water move · Sink — ${waterMoveNames[state.bathroomWaterMoveSinkType] || pretty(state.bathroomWaterMoveSinkType)}`);
          if (state.bathroomWaterMoveDetails.includes('move-toilet') && state.bathroomWaterMoveToiletType) bathChoices.push(`Water move · Toilet — ${waterMoveNames[state.bathroomWaterMoveToiletType] || pretty(state.bathroomWaterMoveToiletType)}`);
          if (state.bathroomWaterMoveDetails.includes('move-shower') && state.bathroomWaterMoveShowerType) bathChoices.push(`Water move · Shower — ${waterMoveNames[state.bathroomWaterMoveShowerType] || pretty(state.bathroomWaterMoveShowerType)}`);
        }
        if (state.bathroomScope !== 'full-gut' && state.bathroomScopeTouches.includes('sink') && state.bathroomSinkAction) bathChoices.push(`Sink — ${state.bathroomSinkAction === 'move' ? 'Move' : 'Replace'}`);
        if (state.bathroomScopeTouches.includes('painting') && state.bathroomPaintType) bathChoices.push(`Painting — ${paintingLabel(state.bathroomPaintType)}`);
        if (state.bathroomScopeTouches.includes('flooring') && state.bathroomFlooringAction) bathChoices.push(`Flooring — ${state.bathroomFlooringAction === 'replace' ? 'Replacement' : state.bathroomFlooringAction === 'overlay' ? 'Overlay' : `Repair${state.bathroomFlooringRepairType ? ` — ${pretty(state.bathroomFlooringRepairType)}` : ''}`}`);
        if (state.bathroomScopeTouches.includes('windows') && state.bathroomWindowAction) bathChoices.push(`Windows — ${windowSelectionLabel(state.bathroomWindowAction, state.bathroomWindowReplacementType)} · ${state.bathroomWindowCount} window${Number(state.bathroomWindowCount) === 1 ? '' : 's'}`);
        if (state.bathroomScope === 'full-gut') bathChoices.push('Flooring — Replacement; Painting — Full; Sink — Replace (automatic)');
        if (state.bathroomScopeTouches.includes('wall') && state.bathroomWallRemovalType) bathChoices.push(`Wall — ${pretty(state.bathroomWallRemovalType)}`);
        if (state.bathroomScope === 'full-gut') bathChoices.push('Utilities — Water, electrical and gas line renewal (automatic)');
        if (bathChoices.length) details.push(`Bath actions: ${bathChoices.join('; ')}`);
        const bathAddOns = state.bathroomMajorAddOns.filter(addOn => !['remove-wall', 'move-toilet-sink-shower'].includes(addOn)).map(addOn => bathroomAddOnNames[addOn] || pretty(addOn));
        if (bathAddOns.length) details.push(`Bath add-ons: ${bathAddOns.join(', ')}`);
        if (state.bathroomMaterialGrade || state.bathroomSize) details.push(`Bath other-material grade / size: ${[state.bathroomMaterialGrade ? otherMaterialGradeLabel(state.bathroomMaterialGrade) : '', state.bathroomSize ? pretty(state.bathroomSize) : ''].filter(Boolean).join(' · ')}`);
      }
      return details;
    }

    function calculateEstimate() {
      const items = []; let base = 0;
      if (state.project === 'kitchen') base = calculateKitchenMatrix(items);
      if (state.project === 'bathroom') base = calculateBathroomMatrix(items);
      if (state.project === 'kitchenbath') {
        if (state.interiorProjects.includes('kitchen')) base += calculateKitchenMatrix(items);
        if (state.interiorProjects.includes('bathroom')) base += calculateBathroomMatrix(items);
      }
      if (OWNER_CONFIG.locationAdjustment) base += addItem(items,'Location adjustment',1,'project',base * Number(OWNER_CONFIG.locationAdjustment),'Owner rule');
      const costPlus = OWNER_CONFIG.pricingMethod === 'cost-plus' ? addItem(items,'Markup',1,'project',base * OWNER_CONFIG.markupPercent,'Owner markup rule') : 0;
      const serviceMinimum = state.project === 'kitchen' ? OWNER_CONFIG.serviceMinimums.kitchen : state.project === 'bathroom' ? OWNER_CONFIG.serviceMinimums.bathroom : state.project === 'kitchenbath' ? (state.interiorProjects.includes('kitchen') ? OWNER_CONFIG.serviceMinimums.kitchen : 0) + (state.interiorProjects.includes('bathroom') ? OWNER_CONFIG.serviceMinimums.bathroom : 0) : 0;
      const projectMinimum = Math.max(0, serviceMinimum);
      const preContingency = Math.max(base + costPlus, projectMinimum);
      const contingency = addItem(items,'Contingency',1,'project',preContingency * OWNER_CONFIG.contingency,'Owner contingency rule');
      const finalBase = Math.max(preContingency + contingency, projectMinimum);
      const low = finalBase; const high = finalBase * (1 + OWNER_CONFIG.rangeAdjustment);
      const display = OWNER_CONFIG.estimateFormat === 'fixed' ? money(finalBase) : OWNER_CONFIG.estimateFormat === 'starting' ? `Starting at ${money(finalBase)}` : `${money(low)} – ${money(high)}`;
      const basedOn = [projectNames[state.project], state.propertyType ? pretty(state.propertyType) : '', state.zip ? `ZIP ${state.zip}` : '', ...selectedBasedOnDetails()].filter(Boolean);
      return { display, low, high, items, finalBase, basedOn, reviewReasons: [], needsReview: false, included: OWNER_CONFIG.included, excluded: OWNER_CONFIG.excluded };
    }

    function renderQuote() {
      const r = state.result || calculateEstimate();
      return `<div class="estimate-result"><div class="result-icon">${ICONS.check}</div><h2>Estimated project cost</h2><div class="estimate-range">${r.display}</div><p class="estimate-note">Based on the information provided. Final pricing can change if site conditions or scope differ.</p><div class="result-card"><h3>Based on</h3><div class="based-on">${r.basedOn.map(x => `<span class="pill">${esc(x)}</span>`).join('')}</div></div><div class="include-columns"><div><h4>Included</h4><ul>${r.included.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div><div class="not-included"><h4>Not included</h4><ul>${r.excluded.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div></div>${ownerPreviewAccess() ? `<div class="owner-preview-tools"><button type="button" id="ownerPreviewToggle" class="owner-preview-toggle" onclick="toggleOwnerPreview()">${ownerPreviewActive() ? 'Hide remodeler calculation' : 'Show remodeler calculation'}</button></div>` : ''}<details class="calc-breakdown owner-only" aria-hidden="true"><summary>Calculation source for owner</summary>${r.items.map(item => `<div class="calc-line"><span>${esc(item.name)}<br><small>${esc(item.qty)} ${esc(item.unit)} · ${esc(item.source)}</small></span><strong>${money(item.value)}</strong></div>`).join('')}</details><p class="fine-print">Preliminary quote based on the information provided. Final price may change if the project scope or site conditions differ.</p><button class="primary-btn" style="width:100%;margin-top:16px;" onclick="resetCalculator()">Start another calculator</button></div>`;
    }

    function clearScopeTouchState(service, touch) {
      if (service === 'kitchen') {
        if (touch === 'countertops') { state.kitchenCountertopAction = ''; state.kitchenHiddenDetails = []; }
        if (touch === 'windows') { state.kitchenWindowAction = ''; state.kitchenWindowReplacementType = ''; state.kitchenWindowCount = ''; }
        if (touch === 'cabinets') { state.kitchenCabinetAction = ''; state.kitchenCabinetKeepType = ''; state.kitchenCabinetReplaceType = ''; }
        if (touch === 'flooring') { state.kitchenFlooringAction = ''; state.kitchenFlooringRepairType = ''; }
        if (touch === 'painting') state.kitchenPaintType = '';
        if (touch === 'wall') state.kitchenWallRemovalType = '';
        if (touch === 'sink') state.kitchenSinkAction = '';
        return;
      }
      if (touch === 'countertops') { state.bathroomCountertopAction = ''; state.bathroomHiddenDetails = []; }
      if (touch === 'windows') { state.bathroomWindowAction = ''; state.bathroomWindowReplacementType = ''; state.bathroomWindowCount = ''; }
      if (touch === 'vanity-cabinets') { state.bathroomVanityAction = ''; state.bathroomVanityKeepType = ''; state.bathroomVanityReplaceType = ''; }
      if (touch === 'flooring') { state.bathroomFlooringAction = ''; state.bathroomFlooringRepairType = ''; }
      if (touch === 'shower-tub') { state.bathroomShowerBase = ''; state.bathroomShowerDetails = []; }
      if (touch === 'water-move') { state.bathroomWaterMoveDetails = []; state.bathroomWaterMoveSinkType = ''; state.bathroomWaterMoveToiletType = ''; state.bathroomWaterMoveShowerType = ''; }
      if (touch === 'sink') state.bathroomSinkAction = '';
      if (touch === 'painting') state.bathroomPaintType = '';
      if (touch === 'wall') state.bathroomWallRemovalType = '';
    }
    function bindStep() {
      body.querySelectorAll('[data-remove-detail]').forEach(button => button.addEventListener('click', () => {
        const service = state.step === 'kitchen-details' ? 'kitchen' : 'bathroom';
        const touchArray = service === 'kitchen' ? 'kitchenScopeTouches' : 'bathroomScopeTouches';
        state[touchArray] = state[touchArray].filter(touch => touch !== button.dataset.removeDetail);
        clearScopeTouchState(service, button.dataset.removeDetail);
        render();
      }));
      body.querySelectorAll('input[type="radio"]').forEach(input => input.addEventListener('change', () => {
        const stateKey = input.dataset.state;
        if (stateKey === 'kitchenScope') {
          saveScopeDetails('kitchen', state.kitchenScope);
          state.kitchenScope = input.value;
          const restored = restoreScopeDetails('kitchen', input.value);
          if (!restored && input.value === 'full-gut') {
            state.kitchenScopeTouches = state.kitchenScopeTouches.filter(touch => !['flooring', 'painting', 'sink'].includes(touch));
            state.kitchenPaintType = '';
            state.kitchenSinkAction = '';
            state.kitchenCabinetAction = 'replace';
            state.kitchenCabinetKeepType = '';
            state.kitchenCabinetReplaceType = '';
          }
        } else if (stateKey === 'bathroomScope') {
          saveScopeDetails('bathroom', state.bathroomScope);
          state.bathroomScope = input.value;
          const restored = restoreScopeDetails('bathroom', input.value);
          if (!restored && input.value === 'full-gut') {
            state.bathroomScopeTouches = state.bathroomScopeTouches.filter(touch => !['flooring', 'painting', 'sink'].includes(touch));
            state.bathroomPaintType = 'full';
            state.bathroomVanityAction = 'replace';
            state.bathroomVanityKeepType = '';
            state.bathroomVanityReplaceType = '';
          }
        } else {
          state[stateKey] = input.value;
        }
        if (stateKey === 'kitchenCabinetAction') {
          if (input.value === 'keep') state.kitchenCabinetReplaceType = '';
          if (input.value === 'replace') state.kitchenCabinetKeepType = '';
        }
        if (stateKey === 'kitchenFlooringAction' && input.value !== 'repair') state.kitchenFlooringRepairType = '';
        if (stateKey === 'bathroomFlooringAction' && input.value !== 'repair') state.bathroomFlooringRepairType = '';
        if (stateKey === 'kitchenWindowAction' && input.value !== 'replace') state.kitchenWindowReplacementType = '';
        if (stateKey === 'bathroomWindowAction' && input.value !== 'replace') state.bathroomWindowReplacementType = '';
        if (stateKey === 'bathroomShowerBase' && input.value === 'acrylic-insert') state.bathroomShowerDetails = state.bathroomShowerDetails.filter(detail => detail === 'frameless-glass');
        if (stateKey === 'bathroomShowerBase' && input.value === 'tub-to-shower') state.bathroomShowerDetails = state.bathroomShowerDetails.filter(detail => ['custom-tiled-shower', 'frameless-glass', 'tiled-niche'].includes(detail));
        if (stateKey === 'bathroomVanityAction') {
          if (input.value === 'keep') state.bathroomVanityReplaceType = '';
          if (input.value === 'replace') state.bathroomVanityKeepType = '';
        }
        render();
      }));
      body.querySelectorAll('input[data-array]').forEach(input => input.addEventListener('change', () => {
        const domValues = selectedValues(input.dataset.array);
        const orderedTouchArrays = ['kitchenScopeTouches', 'bathroomScopeTouches', 'bathroomWaterMoveDetails'];
        const priorValues = state[input.dataset.array] || [];
        const values = orderedTouchArrays.includes(input.dataset.array)
          ? [...priorValues.filter(value => domValues.includes(value)), ...domValues.filter(value => !priorValues.includes(value))]
          : domValues;
        if (input.dataset.array === 'interiorProjects') {
          state.interiorProjects = values.filter(value => ['kitchen', 'bathroom'].includes(value));
          syncProjectSelection();
          render();
          return;
        }
        state[input.dataset.array] = values;
        if (input.dataset.array === 'kitchenScopeTouches' && !values.includes('countertops')) {
          state.kitchenCountertopAction = '';
          state.kitchenHiddenDetails = state.kitchenHiddenDetails.filter(detail => detail !== 'matching-backsplash');
        }
        if (input.dataset.array === 'kitchenScopeTouches' && !values.includes('windows')) {
          state.kitchenWindowAction = '';
          state.kitchenWindowReplacementType = '';
          state.kitchenWindowCount = '';
        }
        if (input.dataset.array === 'kitchenScopeTouches' && !values.includes('cabinets')) {
          state.kitchenCabinetAction = '';
          state.kitchenCabinetKeepType = '';
          state.kitchenCabinetReplaceType = '';
        }
        if (input.dataset.array === 'kitchenScopeTouches' && values.includes('cabinets') && !state.kitchenCabinetAction) state.kitchenCabinetAction = state.kitchenScope === 'full-gut' ? 'replace' : '';
        if (input.dataset.array === 'bathroomScopeTouches' && !values.includes('countertops')) {
          state.bathroomCountertopAction = '';
          state.bathroomHiddenDetails = state.bathroomHiddenDetails.filter(detail => detail !== 'matching-backsplash');
        }
        if (input.dataset.array === 'bathroomScopeTouches' && !values.includes('windows')) {
          state.bathroomWindowAction = '';
          state.bathroomWindowReplacementType = '';
          state.bathroomWindowCount = '';
        }
        if (input.dataset.array === 'bathroomScopeTouches' && !values.includes('vanity-cabinets')) {
          state.bathroomVanityAction = '';
          state.bathroomVanityKeepType = '';
          state.bathroomVanityReplaceType = '';
        }
        if (input.dataset.array === 'bathroomScopeTouches' && values.includes('vanity-cabinets') && !state.bathroomVanityAction) state.bathroomVanityAction = state.bathroomScope === 'full-gut' ? 'replace' : '';
        if (input.dataset.array === 'bathroomScopeTouches' && !values.includes('sink')) state.bathroomSinkAction = '';
        if (input.dataset.array === 'bathroomScopeTouches' && values.includes('sink') && !state.bathroomSinkAction) state.bathroomSinkAction = 'replace';
        if (input.dataset.array === 'bathroomScopeTouches' && !values.includes('water-move')) {
          state.bathroomWaterMoveDetails = [];
          state.bathroomWaterMoveSinkType = '';
          state.bathroomWaterMoveToiletType = '';
          state.bathroomWaterMoveShowerType = '';
        }
        if (input.dataset.array === 'bathroomWaterMoveDetails') {
          if (!values.includes('move-sink')) state.bathroomWaterMoveSinkType = '';
          if (!values.includes('move-toilet')) state.bathroomWaterMoveToiletType = '';
          if (!values.includes('move-shower')) state.bathroomWaterMoveShowerType = '';
        }
        if (['bathroomScopeTouches', 'bathroomHiddenDetails', 'bathroomShowerDetails', 'bathroomWaterMoveDetails', 'bathroomMajorAddOns', 'kitchenScopeTouches', 'kitchenMajorAddOns', 'kitchenHiddenDetails'].includes(input.dataset.array)) render();
      }));
      ['zip', 'kitchenWindowCount', 'bathroomWindowCount', 'firstName', 'phone'].forEach(id => val(id, id));
      body.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => { state.step = button.dataset.go; render(); }));
    }

    function requiredFieldsMessage() {
      const missing = [];
      const add = (condition, label) => { if (condition) missing.push(label); };
      if (state.step === 'property') {
        add(!state.propertyType, 'Property type');
        add(!/^\d{5}$/.test(state.zip), '5-digit ZIP code');
      } else if (state.step === 'project') {
        add(!state.interiorProjects.length, 'Kitchen or Bath selection');
      } else if (state.step === 'route') {
        add(state.interiorProjects.includes('kitchen') && !state.kitchenScope, 'Kitchen scope');
        add(!state.interiorProjects.includes('kitchen') && state.interiorProjects.includes('bathroom') && !state.bathroomScope, 'Bath scope');
      } else if (state.step === 'kitchen-details') {
        add(!state.kitchenScopeTouches.length, 'What are we actually touching');
        add(state.kitchenScopeTouches.includes('countertops') && !state.kitchenCountertopAction, 'Countertop action');
        add(state.kitchenScopeTouches.includes('windows') && !state.kitchenWindowAction, 'Window action');
        add(state.kitchenScopeTouches.includes('windows') && state.kitchenWindowAction === 'replace' && !state.kitchenWindowReplacementType, 'Window replacement option');
        add(!state.kitchenMaterialGrade, 'Kitchen Material Grade');
        add(!state.kitchenSize, 'Kitchen size');
      } else if (state.step === 'bathroom-scope') {
        add(!state.bathroomScope, 'Bath scope');
      } else if (state.step === 'bathroom-details') {
        add(!state.bathroomScopeTouches.length, 'What are we actually touching');
        add(state.bathroomScopeTouches.includes('countertops') && !state.bathroomCountertopAction, 'Countertop action');
        add(state.bathroomScopeTouches.includes('windows') && !state.bathroomWindowAction, 'Window action');
        add(state.bathroomScopeTouches.includes('windows') && state.bathroomWindowAction === 'replace' && !state.bathroomWindowReplacementType, 'Window replacement option');
        add(state.bathroomScopeTouches.includes('water-move') && (state.bathroomWaterMoveDetails.length === 0 || state.bathroomWaterMoveDetails.includes('move-sink') && !state.bathroomWaterMoveSinkType || state.bathroomWaterMoveDetails.includes('move-toilet') && !state.bathroomWaterMoveToiletType || state.bathroomWaterMoveDetails.includes('move-shower') && !state.bathroomWaterMoveShowerType), 'Water move details');
        add(!state.bathroomMaterialGrade, 'Bath Material Grade');
        add(!state.bathroomSize, 'Bath size');
      } else if (state.step === 'contact') {
        add(state.firstName.trim().length <= 1, 'First name');
        add(state.phone.replace(/\D/g, '').length < 10, 'Phone number');
      }
      return missing.length ? `Required: ${missing.join('; ')}.` : 'Complete the required fields to continue.';
    }

    function firstMissingFieldTarget() {
      const find = selector => body.querySelector(selector);
      const radio = key => find(`input[type="radio"][data-state="${key}"]`);
      const check = key => find(`input[type="checkbox"][data-array="${key}"]:not(:checked)`) || find(`input[type="checkbox"][data-array="${key}"]`);
      const field = id => find(`#${id}`);
      if (state.step === 'property') return !state.propertyType ? radio('propertyType') : field('zip');
      if (state.step === 'project') return check('interiorProjects');
      if (state.step === 'route') return state.interiorProjects.includes('kitchen') ? radio('kitchenScope') : radio('bathroomScope');
      if (state.step === 'kitchen-details') {
        if (!state.kitchenScope) return radio('kitchenScope');
        if (!state.kitchenScopeTouches.length) return check('kitchenScopeTouches');
        if (state.kitchenScopeTouches.includes('countertops') && !state.kitchenCountertopAction) return radio('kitchenCountertopAction');
        if (state.kitchenScopeTouches.includes('cabinets')) {
          if (!state.kitchenCabinetAction) return radio('kitchenCabinetAction');
          if (state.kitchenCabinetAction === 'keep' && !state.kitchenCabinetKeepType) return radio('kitchenCabinetKeepType');
          if (state.kitchenCabinetAction === 'replace' && !state.kitchenCabinetReplaceType) return radio('kitchenCabinetReplaceType');
        }
        if (state.kitchenScopeTouches.includes('flooring')) {
          if (!state.kitchenFlooringAction) return radio('kitchenFlooringAction');
          if (state.kitchenFlooringAction === 'repair' && !state.kitchenFlooringRepairType) return radio('kitchenFlooringRepairType');
        }
        if (state.kitchenScopeTouches.includes('windows')) {
          const allowed = ['resize', 'move', 'replace'];
          if (!allowed.includes(state.kitchenWindowAction)) return radio('kitchenWindowAction');
          if (state.kitchenWindowAction === 'replace' && !['glass-only', 'retrofit', 'full-frame'].includes(state.kitchenWindowReplacementType)) return radio('kitchenWindowReplacementType');
          if (Number(state.kitchenWindowCount) < 1) return field('kitchenWindowCount');
        }
        if (state.kitchenScopeTouches.includes('painting') && !state.kitchenPaintType) return radio('kitchenPaintType');
        if (state.kitchenScopeTouches.includes('wall') && !state.kitchenWallRemovalType) return radio('kitchenWallRemovalType');
        if (!state.kitchenMaterialGrade) return radio('kitchenMaterialGrade');
        return !state.kitchenSize ? radio('kitchenSize') : null;
      }
      if (state.step === 'bathroom-scope') return radio('bathroomScope');
      if (state.step === 'bathroom-details') {
        if (!state.bathroomScopeTouches.length) return check('bathroomScopeTouches');
        if (state.bathroomScopeTouches.includes('countertops') && !state.bathroomCountertopAction) return radio('bathroomCountertopAction');
        if (state.bathroomScopeTouches.includes('vanity-cabinets')) {
          if (!state.bathroomVanityAction) return radio('bathroomVanityAction');
          const complete = state.bathroomVanityAction === 'keep' && !!state.bathroomVanityKeepType || state.bathroomVanityAction === 'replace' && !!state.bathroomVanityReplaceType;
          if (!complete) return state.bathroomVanityAction === 'keep' ? radio('bathroomVanityKeepType') : radio('bathroomVanityReplaceType');
        }
        if (state.bathroomScopeTouches.includes('flooring')) {
          if (!state.bathroomFlooringAction) return radio('bathroomFlooringAction');
          if (state.bathroomFlooringAction === 'repair' && !state.bathroomFlooringRepairType) return radio('bathroomFlooringRepairType');
        }
        if (state.bathroomScopeTouches.includes('windows')) {
          const allowed = ['resize', 'move', 'replace'];
          if (!allowed.includes(state.bathroomWindowAction)) return radio('bathroomWindowAction');
          if (state.bathroomWindowAction === 'replace' && !['glass-only', 'retrofit', 'full-frame'].includes(state.bathroomWindowReplacementType)) return radio('bathroomWindowReplacementType');
          if (Number(state.bathroomWindowCount) < 1) return field('bathroomWindowCount');
        }
        if (state.bathroomScopeTouches.includes('sink') && !state.bathroomSinkAction) return radio('bathroomSinkAction');
        if (state.bathroomScopeTouches.includes('water-move')) {
          if (!state.bathroomWaterMoveDetails.length) return check('bathroomWaterMoveDetails');
          if (state.bathroomWaterMoveDetails.includes('move-sink') && !state.bathroomWaterMoveSinkType) return radio('bathroomWaterMoveSinkType');
          if (state.bathroomWaterMoveDetails.includes('move-toilet') && !state.bathroomWaterMoveToiletType) return radio('bathroomWaterMoveToiletType');
          if (state.bathroomWaterMoveDetails.includes('move-shower') && !state.bathroomWaterMoveShowerType) return radio('bathroomWaterMoveShowerType');
        }
        if (state.bathroomScopeTouches.includes('painting') && !state.bathroomPaintType) return radio('bathroomPaintType');
        if (state.bathroomScopeTouches.includes('wall') && !state.bathroomWallRemovalType) return radio('bathroomWallRemovalType');
        if (!state.bathroomMaterialGrade) return radio('bathroomMaterialGrade');
        return !state.bathroomSize ? radio('bathroomSize') : null;
      }
      if (state.step === 'contact') return state.firstName.trim().length <= 1 ? field('firstName') : field('phone');
      return null;
    }

    function validStep() {
      let valid = true;
      if (state.step === 'property') valid = !!state.propertyType && /^\d{5}$/.test(state.zip);
      else if (state.step === 'project') valid = state.interiorProjects.some(project => ['kitchen', 'bathroom'].includes(project) && OWNER_CONFIG.activeServices[project]);
      else if (state.step === 'route') valid = state.interiorProjects.includes('kitchen') ? !!state.kitchenScope : state.interiorProjects.includes('bathroom') ? !!state.bathroomScope : false;
      else if (state.step === 'kitchen-details') valid = kitchenDetailsStepValid();
      else if (state.step === 'bathroom-scope') valid = !!state.bathroomScope;
      else if (state.step === 'bathroom-details') valid = bathroomDetailsStepValid();
      else if (state.step === 'contact') valid = state.firstName.trim().length > 1 && state.phone.replace(/\D/g, '').length >= 10;
      const error = document.getElementById('stepError');
      if (error) {
        error.textContent = valid ? '' : requiredFieldsMessage();
        error.classList.toggle('show', !valid);
        if (!valid) {
          error.setAttribute('role', 'alert');
          error.setAttribute('aria-live', 'assertive');
          body.prepend(error);
          const target = firstMissingFieldTarget();
          const scrollTarget = target && target.matches('input[type="radio"], input[type="checkbox"]') ? target.closest('.radio-item, .check-item') || target : target;
          const missingElement = target && target.matches('input[type="radio"], input[type="checkbox"]') ? target.closest('.radio-list, .check-list') || scrollTarget : target;
          if (missingElement) {
            missingElement.classList.add('validation-missing');
            missingElement.setAttribute('aria-invalid', 'true');
          }
          requestAnimationFrame(() => (scrollTarget || error).scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' }));
        }
      }
      return valid;
    }

    function next() {
      if (!validStep()) return;
      const flow = activeFlow();
      const index = flow.indexOf(state.step);
      if (state.step === 'contact') {
        state.result = calculateEstimate();
        if (!state.leadCreated) { addCalculatorLead(state.result); state.leadCreated = true; }
        state.step = 'quote';
      } else if (state.step !== 'quote') {
        state.step = flow[index + 1];
      }
      render();
    }
    function previous() {
      const flow = activeFlow();
      const index = flow.indexOf(state.step);
      if (index > 0) state.step = flow[index - 1];
      render();
    }
    nextButton.addEventListener('click', next);
    backButton.addEventListener('click', previous);
    function resetCalculator() { state = freshState(); openWidget(); }
    
    setInterval(refreshLeadCreatedTimes, 60000);
  
      root.__lifkiActions = { resetCalculator: resetCalculator, toggleOwnerPreview: toggleOwnerPreview };
    })(window, scopedDocument, root);
    root.querySelectorAll("[onclick]").forEach(function (element) {
      var expression = element.getAttribute("onclick") || "";
      var match = expression.match(/^([A-Za-z_$][\w$]*)\s*\(/);
      element.removeAttribute("onclick");
      if (match && root.__lifkiActions[match[1]]) element.addEventListener("click", function () { root.__lifkiActions[match[1]](); });
    });
  }

  function check() {
    if (cached()) return mount();
    if (!/^https:\/\/[^/]+\.supabase\.co$/i.test(SUPABASE_URL)) return;
    var url = SUPABASE_URL + "/rest/v1/subscriptions?id=eq." + encodeURIComponent(appId) + "&select=subscription_status";
    fetch(url, {
      method: "GET", cache: "force-cache",
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: "Bearer " + SUPABASE_ANON_KEY, "Cache-Control": "public, max-age=300" }
    }).then(function (response) {
      if (!response.ok) throw new Error("status unavailable");
      return response.json();
    }).then(function (rows) {
      if (!Array.isArray(rows) || !rows.some(function (row) { return row && row.subscription_status === "active"; })) return;
      cacheActive(); mount();
    }).catch(function () { /* Fail closed. */ });
  }
  check();
})();
