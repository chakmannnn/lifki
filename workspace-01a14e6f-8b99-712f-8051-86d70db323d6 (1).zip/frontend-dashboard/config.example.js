// Copy to config.js and replace public values only.
// Never place a service-role key or Whop webhook secret in this file.
window.LifkiDashboardConfig = {
  SUPABASE_URL: "https://YOUR_PROJECT_REF.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
  WHOP_CHECKOUT_URL: "https://whop.com/checkout/YOUR_PLAN_ID",
  WIDGET_URL: "https://YOUR_PROJECT_REF.supabase.co/storage/v1/object/public/widgets/widget.js",
  AUTO_OPEN_AUTH: true
};
