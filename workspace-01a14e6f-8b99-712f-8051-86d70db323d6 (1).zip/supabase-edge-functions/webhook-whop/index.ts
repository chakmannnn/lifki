// Supabase Edge Function: webhook-whop
// Deploy as webhook-whop. Configure /webhook/whop as a rewrite if needed.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

declare const EdgeRuntime: { waitUntil(promise: Promise<unknown>): void };

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const WHOP_WEBHOOK_SECRET = Deno.env.get("WHOP_WEBHOOK_SECRET") ?? "";
const REPLAY_TOLERANCE_SECONDS = 300;
const encoder = new TextEncoder();
type JsonRecord = Record<string, unknown>;

type MembershipEvent = {
  eventType: string;
  membershipId: string | null;
  userId: string | null;
  currentPeriodEnd: string | null;
};

function record(value: unknown): JsonRecord {
  return value && typeof value === "object" && !Array.isArray(value)
    ? value as JsonRecord
    : {};
}

function stringValue(source: JsonRecord, ...keys: string[]): string | null {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return null;
}

function decodeBase64(value: string): Uint8Array | null {
  try {
    const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const binary = atob(padded);
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  } catch {
    return null;
  }
}

function secretBytes(secret: string): Uint8Array {
  const value = secret.startsWith("whsec_") ? secret.slice(6) : secret;
  return decodeBase64(value) ?? encoder.encode(value);
}

function hexBytes(value: string): Uint8Array | null {
  if (!/^[a-f0-9]+$/i.test(value) || value.length % 2) return null;
  const result = new Uint8Array(value.length / 2);
  for (let i = 0; i < result.length; i += 1) {
    result[i] = Number.parseInt(value.slice(i * 2, i * 2 + 2), 16);
  }
  return result;
}

function signatureBytes(value: string): Uint8Array | null {
  const cleaned = value.trim()
    .replace(/^v\d+[=:]/i, "")
    .replace(/^sha256[=:]/i, "");
  return hexBytes(cleaned) ?? decodeBase64(cleaned);
}

function equalBytes(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let i = 0; i < left.length; i += 1) difference |= left[i] ^ right[i];
  return difference === 0;
}

async function sign(message: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    secretBytes(WHOP_WEBHOOK_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(message)));
}

function signatures(header: string | null): string[] {
  if (!header) return [];
  return header.split(/\s+/).flatMap((part) => {
    const comma = part.indexOf(",");
    if (comma >= 0) return [part.slice(comma + 1)];
    const equals = part.indexOf("=");
    return [equals >= 0 ? part.slice(equals + 1) : part];
  }).map((value) => value.trim()).filter(Boolean);
}

function fresh(timestamp: string | null): boolean {
  if (!timestamp) return false;
  const seconds = Number(timestamp);
  return Number.isFinite(seconds) &&
    Math.abs(Math.floor(Date.now() / 1000) - seconds) <= REPLAY_TOLERANCE_SECONDS;
}

async function verify(request: Request, rawBody: string): Promise<boolean> {
  if (!WHOP_WEBHOOK_SECRET) return false;
  const legacyHeader = request.headers.get("whop-signature");
  const standardHeader = request.headers.get("webhook-signature");
  const webhookId = request.headers.get("webhook-id");
  const timestamp = request.headers.get("webhook-timestamp") ?? request.headers.get("whop-timestamp");
  if (!fresh(timestamp)) return false;

  const messages: string[] = [];
  if (legacyHeader) {
    messages.push(rawBody, `${timestamp}.${rawBody}`);
    if (webhookId) messages.push(`${webhookId}.${timestamp}.${rawBody}`);
  }
  if (standardHeader && webhookId) messages.push(`${webhookId}.${timestamp}.${rawBody}`);

  const supplied = [...signatures(legacyHeader), ...signatures(standardHeader)]
    .map(signatureBytes)
    .filter((value): value is Uint8Array => value !== null);
  if (!messages.length || !supplied.length) return false;
  const expected = await Promise.all(messages.map(sign));
  return expected.some((candidate) => supplied.some((value) => equalBytes(candidate, value)));
}

function metadata(value: unknown): JsonRecord {
  if (value && typeof value === "object") return record(value);
  if (typeof value === "string") {
    try { return record(JSON.parse(value)); } catch { return {}; }
  }
  return {};
}

function extractEvent(payload: JsonRecord): MembershipEvent {
  const data = record(payload.data);
  const nested = record(data.membership);
  const direct = record(payload.membership);
  const membership = Object.keys(nested).length ? nested : direct;
  const sources = [membership, data, payload];
  const eventType = stringValue(payload, "type", "event_type", "event") ?? "";
  const meta = sources.map((source) => metadata(source.metadata))
    .find((value) => Object.keys(value).length) ?? {};
  const membershipId = sources
    .map((source) => stringValue(source, "id", "membership_id", "whop_membership_id"))
    .find((value): value is string => Boolean(value)) ?? null;
  const userId = stringValue(meta, "user_id", "supabase_user_id");
  const periodEnd = sources
    .map((source) => stringValue(source, "current_period_end", "period_end", "renewal_period_end", "expires_at"))
    .find((value): value is string => Boolean(value)) ?? null;
  return { eventType, membershipId, userId, currentPeriodEnd: periodEnd };
}

function uuid(value: string | null): value is string {
  return Boolean(value && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value));
}

async function supabase(path: string, init: RequestInit): Promise<void> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) throw new Error("Backend secrets are not configured");
  const response = await fetch(`${SUPABASE_URL}${path}`, {
    ...init,
    headers: {
      apikey: SERVICE_ROLE_KEY,
      Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  if (!response.ok) throw new Error(`Supabase ${response.status}: ${(await response.text()).slice(0, 500)}`);
}

async function processEvent(payload: JsonRecord): Promise<void> {
  const event = extractEvent(payload);
  const active = new Set(["membership.created", "membership.renewed", "membership.activated", "membership.active"]);
  const cancelled = new Set(["membership.cancelled", "membership.canceled", "membership.deactivated"]);

  if (active.has(event.eventType)) {
    if (!uuid(event.userId) || !event.membershipId) {
      throw new Error("Active event is missing metadata.user_id or membership id");
    }
    await supabase("/rest/v1/subscriptions?on_conflict=user_id", {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify({
        user_id: event.userId,
        whop_membership_id: event.membershipId,
        subscription_status: "active",
        current_period_end: event.currentPeriodEnd,
      }),
    });
    console.info("Subscription activated", { userId: event.userId, membershipId: event.membershipId });
    return;
  }

  if (cancelled.has(event.eventType)) {
    if (!event.membershipId) throw new Error("Cancellation event is missing membership id");
    await supabase(`/rest/v1/subscriptions?whop_membership_id=eq.${encodeURIComponent(event.membershipId)}`, {
      method: "PATCH",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify({ subscription_status: "cancelled" }),
    });
    console.info("Subscription cancelled", { membershipId: event.membershipId });
    return;
  }
  console.info("Unsupported Whop event ignored", { eventType: event.eventType });
}

function routeMatches(path: string): boolean {
  return path.endsWith("/webhook/whop") || path.endsWith("/webhook-whop");
}

serve(async (request: Request): Promise<Response> => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204 });
  if (!routeMatches(new URL(request.url).pathname)) return new Response("Not found", { status: 404 });
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405, headers: { Allow: "POST" } });

  const rawBody = await request.text();
  if (!(await verify(request, rawBody))) return new Response("Invalid webhook signature", { status: 401 });

  let payload: JsonRecord;
  try { payload = record(JSON.parse(rawBody)); }
  catch { return new Response("Invalid JSON", { status: 400 }); }

  EdgeRuntime.waitUntil(processEvent(payload).catch((error) => console.error("Webhook processing failed", error)));
  return Response.json({ received: true }, { status: 200 });
});
