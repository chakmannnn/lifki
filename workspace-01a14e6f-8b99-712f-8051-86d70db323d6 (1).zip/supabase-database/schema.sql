-- Lifki subscription database.
-- Run in the target Supabase SQL Editor.
-- public.subscriptions.id is the public widget appId.

begin;

create extension if not exists pgcrypto;

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users (id) on delete cascade,
  whop_membership_id text unique,
  subscription_status text not null default 'inactive',
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);

create index if not exists subscriptions_whop_membership_id_idx
  on public.subscriptions (whop_membership_id);
create index if not exists subscriptions_status_idx
  on public.subscriptions (subscription_status);
create index if not exists subscriptions_user_status_idx
  on public.subscriptions (user_id, subscription_status);

create or replace function public.set_subscriptions_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists subscriptions_set_updated_at on public.subscriptions;
create trigger subscriptions_set_updated_at
before update on public.subscriptions
for each row execute function public.set_subscriptions_updated_at();

alter table public.subscriptions enable row level security;
revoke all on table public.subscriptions from anon, authenticated;

-- The public widget only receives id and subscription_status. The REST request
-- should also filter by id: ?id=eq.<appId>&select=subscription_status.
grant select (id, subscription_status) on table public.subscriptions to anon;
create policy subscriptions_anon_status_read
  on public.subscriptions for select to anon using (true);

-- The dashboard can read only the signed-in user's complete row.
grant select on table public.subscriptions to authenticated;
create policy subscriptions_authenticated_own_read
  on public.subscriptions for select to authenticated
  using (auth.uid() = user_id);

-- Backend writes use the service role only.
grant all on table public.subscriptions to service_role;
grant usage on schema public to anon, authenticated, service_role;

commit;
